package ca.servicecanada.daisi.ws.service;

import ca.servicecanada.daisi.ws.client.DAISISoapClient;
import ca.servicecanada.daisi.ws.handler.ClientWSSecuritySOAPHandler;
import ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler;

import org.junit.Assert;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

public class BankAccountSyncServiceTestCase extends junit.framework.TestCase
{
  private final String user = "ISPWS";

  private final String password = "NOTUSED";

  public BankAccountSyncServiceTestCase(final java.lang.String name)
  {
    super(name);
  }

  //  public void test1RetrieveBankAccount() throws Exception
  //  {
  //    final ca.servicecanada.daisi.ws.client.generated.BankAccountSync binding = getBinding();
  //
  //    // final MessageManifestTransactionalCT msg = new MessageManifestTransactionalCT();
  //    final RetrieveBankAccountBySINRequestDataAreaType data =
  //        new RetrieveBankAccountBySINRequestDataAreaType();
  //    // GregorianCalendar c = new GregorianCalendar();
  //    // c.setTime(new Date());
  //    //XMLGregorianCalendar date1 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
  //    // msg.setBusinessTransactionDateTime(date1);
  //    // msg.setSystemID(SystemIDCT);
  //    data.setBirthDate("2017-02-12");
  //    data.setChannel("ONL");
  //    data.setProgram("CPP");
  //    data.setSharingAgreementID("ESS1701");
  //    data.setSocialInsuranceNumber("800000002");
  //    data.setSurname("BEACO");
  //    final String value = binding.retrieveBankAccount(data);
  //    System.out.print("Business Transaction Id: " + value);
  //
  //  }

  public void test2RetrieveBankAccount() throws Exception
  {
    final DAISISoapClient client = new DAISISoapClient();
    final String value = client.retrieveDirectDepositRequest("800000002", "BEACO", "2017-02-12",
        "ONL", "ESS1701", "CPP");
    System.out.print("Business Transaction Id: " + value);

  }

  private ca.servicecanada.daisi.ws.client.generated.BankAccountSync getBinding() throws Exception
  {

    ca.servicecanada.daisi.ws.client.generated.BankAccountSync port;
    Map<String, Object> reqContext;
    //1st argument service URI
    //2nd argument is service name
    final QName qname =
        new QName("http://servicecanada.ca/daisi/ws/service", "BankAccountSyncServicesService");
    final Service service = Service.create(BankAccountSyncServiceTestCase.getWsdlURL(), qname);

    //---[ Add the WS-Security token handler
    service.setHandlerResolver(new HandlerResolver()
    {
      @SuppressWarnings("rawtypes")
      @Override
      public List<Handler> getHandlerChain(final PortInfo portInfo)
      {
        final ArrayList<Handler> handlers = new ArrayList<>();
        handlers.add(new SOAPLoggingHandler());
        handlers.add(new ClientWSSecuritySOAPHandler("ISPWS", "NOTUSED", "EN"));// make sure user id is available and set password in this token handler
        // handlers.add(new SOAPLoggingHandler());
        return handlers;
      }
    });

    port = service.getPort(ca.servicecanada.daisi.ws.client.generated.BankAccountSync.class);
    Assert.assertNotNull("port is null", port);

    reqContext = ((BindingProvider) port).getRequestContext();

    //reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
    //EndPointUtil.getEndPointWebLogicURL(service).toString()); //TODO:PL: Adapt this so it works

    reqContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
        "http://localhost:7001/DAISI/BankAccountSyncServicesService");

    //reqContext.put(JAXWSProperties.REQUEST_TIMEOUT, EndPointUtil.getBindingTimeout());

    return port;

  }

  private static URL getWsdlURL()
  {
    URL url = null;
    try
    {
      url = new URL("http://localhost:7001/DAISI/BankAccountSyncServicesService?wsdl");
    }
    catch (final MalformedURLException e)
    {
      //logger.warning("Failed to create URL for the wsdl Location: '/ITR_WS_RD/ITRWS-WsdlsFixedForJAXWSImport/VanillaClientProfile.wsdl', retrying as a local file");
      System.out.println(
          "Failed to create URL for the wsdl Location: 'BankAccountSyncServicesService?wsdl', retrying as a local file");
      //logger.warning(e.getMessage());
    }
    return url;
  }

}
