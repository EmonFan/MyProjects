package ca.servicecanada.daisi.ws.service;

import static org.junit.Assert.*;

import org.junit.Test;

import ca.servicecanada.daisi.ws.endpoint.generated.*;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINRequestDataAreaType.BankAccount;

public class DaisiQueueAdapterTest {

	DaisiQueueAdapter queueAdapter = new DaisiQueueAdapter();

	// PULL
	@Test
	public void testOnMessageRetrieveBankAccountBySIN() {

		RetrieveBankAccountBySINRequestType data = buildPullRequest();
		queueAdapter.onMessageRetrieveBankAccountBySIN(data);
	}

	// PUSH
	//@Test
	public void testOnMessageSetBankAccountBySIN() {
		SetBankAccountBySINRequestType setBankAccountBySIN = buildPushRequest();

		queueAdapter.onMessageSetBankAccountBySIN(setBankAccountBySIN);
	}

	// ---------------------------------

	SetBankAccountBySINRequestType buildPushRequest() {
		SetBankAccountBySINRequestType setBankAccountBySIN = new SetBankAccountBySINRequestType();
		return setBankAccountBySIN;
	}

	RetrieveBankAccountBySINRequestType buildPullRequest() {
		RetrieveBankAccountBySINRequestType data = new RetrieveBankAccountBySINRequestType();

		NotificationIDCT value = new NotificationIDCT();

		MessageManifestTransactionalCT messageManifest = new MessageManifestTransactionalCT();
		value.setValue("ID_FROM_CRA_111");
		messageManifest.setBusinessTransactionID(value);
		// .setBusinessTransactionID("ID:<717546.1499439637415.0>");

		RetrieveBankAccountBySINRequestDataAreaType dataArea = new RetrieveBankAccountBySINRequestDataAreaType();

		// BankAccount account = new BankAccount();
		dataArea.setBirthDate("1011");
		dataArea.setChannel("PHONE");
		dataArea.setProgram("CRA");

		data.setMessageManifest(messageManifest);
		data.setDataArea(dataArea);
		return data;

	}

}
