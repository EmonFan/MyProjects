package ca.servicecanada.daisi.ws.client;

import ca.servicecanada.daisi.ws.client.generated.BankAccountSync;
import ca.servicecanada.daisi.ws.client.generated.BankAccountSyncServices_Service;
import ca.servicecanada.daisi.ws.client.generated.RetrieveBankAccountBySINRequestDataAreaType;
import ca.servicecanada.daisi.ws.client.generated.SetBankAccountBySINRequestDataAreaType;
import ca.servicecanada.daisi.ws.handler.ClientWSSecuritySOAPHandler;
import ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

@Component
public class DAISISoapClient
{
  private final Logger LOGGER = LogManager.getLogger();

  // @Value("${itrds.ws.pull-dd.url}")
  protected String endpointBankAccount =
      "http://localhost:7001/DAISI/BankAccountSyncServicesService";

  // @Value("${itrds.ws.user}")
  protected String user = "ISPWS";

  // @Value("${itrds.ws.password}")
  protected String password = "NOTUSED";

  protected HandlerResolver portBankAccountHandlerResolver;

  private BankAccountSync portBankAccount;

  public DAISISoapClient()
  {
    initBankAccountDDEndpoint();
  }

  public String retrieveDirectDepositRequest(final String sin, final String surname,
      final String birthDate, final String channelType, final String consentCode,
      final String program)
  {

    final RetrieveBankAccountBySINRequestDataAreaType req = DAISISoapClient
        .buildDaisiDDInfoPullRequest(sin, surname, birthDate, channelType, consentCode, program);

    String response = "";

    try
    {
      response = portBankAccount.retrieveBankAccount(req);

    }
    catch (final Exception x)
    {
      LOGGER.error(x.getMessage());
      throw new RuntimeException(x.getMessage());
    }

    return response;
  }

  private static RetrieveBankAccountBySINRequestDataAreaType buildDaisiDDInfoPullRequest(
      final String sin, final String surname, final String birthDate, final String channelType,
      final String consentCode, final String program)
  {
    final RetrieveBankAccountBySINRequestDataAreaType data =
        new RetrieveBankAccountBySINRequestDataAreaType();
    data.setBirthDate(birthDate);
    data.setChannel(channelType);
    data.setProgram(program);
    data.setSharingAgreementID(consentCode);
    data.setSocialInsuranceNumber(sin);
    data.setSurname(surname);
    return data;
  }

  public String setDirectDepositRequest(final String sin, final String surname,
      final String birthDate, final String channelType, final String consentCode,
      final String program, final String branch, final String accountNumber,
      final String institution)
  {

    final SetBankAccountBySINRequestDataAreaType req =
        DAISISoapClient.buildDaisiDDInfoPushRequest(sin, surname, birthDate, channelType,
            consentCode, program, branch, accountNumber, institution);

    String response = "";

    try
    {
      response = portBankAccount.setBankAccount(req);
    }
    catch (final Exception x)
    {
      LOGGER.error(x.getMessage());
      throw new RuntimeException(x.getMessage());
    }

    return response;
  }

  private static SetBankAccountBySINRequestDataAreaType buildDaisiDDInfoPushRequest(
      final String sin, final String surname, final String birthDate, final String channelType,
      final String consentCode, final String program, final String branch,
      final String accountNumber, final String insititution)
  {
    final SetBankAccountBySINRequestDataAreaType data =
        new SetBankAccountBySINRequestDataAreaType();
    data.setBirthDate(birthDate);
    data.setChannel(channelType);
    data.setProgram(program);
    data.setSharingAgreementID(consentCode);
    data.setSocialInsuranceNumber(sin);
    data.setSurname(surname);
    final SetBankAccountBySINRequestDataAreaType.BankAccount bankAccount =
        new SetBankAccountBySINRequestDataAreaType.BankAccount();
    bankAccount.setAccountNumber(accountNumber);
    bankAccount.setInstitution(insititution);
    bankAccount.setTransit(branch);
    data.setBankAccount(bankAccount);
    return data;
  }

  void initBankAccountDDEndpoint()
  {
    initHandlerResolver();
    final BankAccountSyncServices_Service service = new BankAccountSyncServices_Service();
    service.setHandlerResolver(portBankAccountHandlerResolver);

    portBankAccount = service.getBankAccountSyncPort();

    DAISISoapClient.initEndpointAddress((BindingProvider) portBankAccount, endpointBankAccount);
  }

  static void initEndpointAddress(final BindingProvider bp, final String endpoint)
  {
    final Map<String, Object> context = bp.getRequestContext();
    context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
  }

  /* @Override
  public void afterPropertiesSet() throws Exception
  {
    initHandlerResolver();
    initEndpoints();
  
  }*/

  private void initHandlerResolver()
  {
    portBankAccountHandlerResolver = new HandlerResolver()
    {
      @SuppressWarnings("rawtypes")
      @Override
      public List<Handler> getHandlerChain(final PortInfo portInfo)
      {
        final ArrayList<Handler> handlerChain = new ArrayList<>();
        handlerChain.add(new SOAPLoggingHandler());
        handlerChain.add(new ClientWSSecuritySOAPHandler(user, password, null));
        return handlerChain;
      }
    };

  }

}
