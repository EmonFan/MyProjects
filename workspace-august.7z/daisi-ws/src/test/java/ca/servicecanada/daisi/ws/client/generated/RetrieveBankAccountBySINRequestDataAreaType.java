
package ca.servicecanada.daisi.ws.client.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for RetrieveBankAccountBySINRequestDataAreaType complex type.
 * <p>
 * The following schema fragment specifies the expected content contained within this class.
 *
 * <pre>
 * &lt;complexType name="RetrieveBankAccountBySINRequestDataAreaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SocialInsuranceNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="BirthDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Surname" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Channel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Program" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SharingAgreementID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveBankAccountBySINRequestDataAreaType", propOrder = {
    "socialInsuranceNumber", "birthDate", "surname", "channel", "program", "sharingAgreementID" })
public class RetrieveBankAccountBySINRequestDataAreaType
{

  @XmlElement(name = "SocialInsuranceNumber", required = true)
  protected String socialInsuranceNumber;

  @XmlElement(name = "BirthDate")
  protected String birthDate;

  @XmlElement(name = "Surname")
  protected String surname;

  @XmlElement(name = "Channel")
  protected String channel;

  @XmlElement(name = "Program")
  protected String program;

  @XmlElement(name = "SharingAgreementID")
  protected String sharingAgreementID;

  /**
   * Gets the value of the socialInsuranceNumber property.
   * 
   * @return possible object is {@link String }
   */
  public String getSocialInsuranceNumber()
  {
    return socialInsuranceNumber;
  }

  /**
   * Sets the value of the socialInsuranceNumber property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setSocialInsuranceNumber(final String value)
  {
    socialInsuranceNumber = value;
  }

  /**
   * Gets the value of the birthDate property.
   * 
   * @return possible object is {@link String }
   */
  public String getBirthDate()
  {
    return birthDate;
  }

  /**
   * Sets the value of the birthDate property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setBirthDate(final String value)
  {
    birthDate = value;
  }

  /**
   * Gets the value of the surname property.
   * 
   * @return possible object is {@link String }
   */
  public String getSurname()
  {
    return surname;
  }

  /**
   * Sets the value of the surname property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setSurname(final String value)
  {
    surname = value;
  }

  /**
   * Gets the value of the channel property.
   * 
   * @return possible object is {@link String }
   */
  public String getChannel()
  {
    return channel;
  }

  /**
   * Sets the value of the channel property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setChannel(final String value)
  {
    channel = value;
  }

  /**
   * Gets the value of the program property.
   * 
   * @return possible object is {@link String }
   */
  public String getProgram()
  {
    return program;
  }

  /**
   * Sets the value of the program property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setProgram(final String value)
  {
    program = value;
  }

  /**
   * Gets the value of the sharingAgreementID property.
   * 
   * @return possible object is {@link String }
   */
  public String getSharingAgreementID()
  {
    return sharingAgreementID;
  }

  /**
   * Sets the value of the sharingAgreementID property.
   * 
   * @param value allowed object is {@link String }
   */
  public void setSharingAgreementID(final String value)
  {
    sharingAgreementID = value;
  }

}
