package ca.servicecanada.daisi.ws;

import static org.junit.Assert.*;

import org.junit.Test;

public class OutboundWsCallsClientTest {
	
	OutboundWsCallsClient client = new OutboundWsCallsClient();

	@Test
	public void testRetrieveBankAccountBySINFromDSB() {
		String SIN = "111222333";
		//uncomment this 
		//client.retrieveBankAccountBySINFromDSB(SIN);
	}

}
