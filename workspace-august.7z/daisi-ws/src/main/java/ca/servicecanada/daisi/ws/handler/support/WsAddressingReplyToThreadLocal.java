package ca.servicecanada.daisi.ws.handler.support;

public class WsAddressingReplyToThreadLocal {

	public static final ThreadLocal replyToThreadLocal = new ThreadLocal();

	public static void set(WsAddressingReplyTo replyTo) {
		replyToThreadLocal.set(replyTo);
	}

	public static void unset() {
		replyToThreadLocal.remove();
	}

	public static WsAddressingReplyTo get() {
		return (WsAddressingReplyTo) replyToThreadLocal.get();
	}

}
