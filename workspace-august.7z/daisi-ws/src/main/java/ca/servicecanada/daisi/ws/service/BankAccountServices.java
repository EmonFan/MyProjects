package ca.servicecanada.daisi.ws.service;

import ca.servicecanada.daisi.dsb.OutboundCallbackWsClientWS;
import ca.servicecanada.daisi.ws.endpoint.generated.Fault;
import ca.servicecanada.daisi.ws.endpoint.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ws.endpoint.generated.ObjectFactory;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFault;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFaultThreadLocal;
import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyTo;
import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyToThreadLocal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.jws.HandlerChain;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPConstants;
import javax.xml.ws.soap.Addressing;

@Component
@Import({ org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class,
    ca.servicecanada.daisi.ws.handler.ServerWSSecuritySOAPHandler.class,
    ca.servicecanada.daisi.ws.handler.WSAddressingSOAPHandler.class,
    ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler.class })

@WebService(name = "BankAccountServices", targetNamespace = "http://interoperability.gc.ca/service/citizenprofile/1.0")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@Addressing(enabled = true, required = false)
@HandlerChain(file = "handler-chain.xml")
@XmlSeeAlso({ ObjectFactory.class })
public class BankAccountServices extends SpringBeanAutowiringSupport
{

  @Autowired
  private DaisiQueueAdapter adapter;

  @Autowired
  private OutboundCallbackWsClientWS callbackWsClient;

  private final Logger LOGGER = LogManager.getLogger(getClass());

  /**
   * WebLogic Server returns an HTTP 202 Accepted status to the client as soon as the request stream
   * has been consumed.
   */
  @WebMethod(operationName = "RetrieveBankAccountBySINInCPP", action = "RetrieveBankAccountBySINInCPP")
  @Oneway
  public void retrieveBankAccountBySIN(
      @WebParam(name = "RetrieveBankAccountBySINRequest", targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", partName = "RetrieveBankAccountBySINRequest") final RetrieveBankAccountBySINRequestType retrieveBankAccountBySINRequest)
  {

    LOGGER.debug("RetrieveBankAccountBySINInCPP \n");
    final String businessTransactionID =
        retrieveBankAccountBySINRequest.getMessageManifest().getBusinessTransactionID().getValue();
    LOGGER.debug("-- BusinessTransactionID -- " + businessTransactionID);

    if (hasWSSecurityFaults())
    {
      handleFaultRetrieveBankAccountBySIN(retrieveBankAccountBySINRequest.getMessageManifest(),
          "403", "HTTP 403 - error in username/password supplied");
    }
    else
    {
      try
      {
        adapter.onMessageRetrieveBankAccountBySIN(retrieveBankAccountBySINRequest);
      }
      catch (final Exception e)
      {
        e.printStackTrace();
        LOGGER.error(
            "Error while parsing incoming RetrieveBankAccountBySINRequest businessTransactionID="
                + businessTransactionID);
        handleFaultRetrieveBankAccountBySIN(retrieveBankAccountBySINRequest.getMessageManifest(),
            "500", e.getMessage());
      }

    }

  }

  @WebMethod(operationName = "SetBankAccountBySINInCPP", action = "SetBankAccountBySINInCPP")
  @Oneway
  public void setBankAccountBySIN(
      @WebParam(name = "SetBankAccountBySINRequest", targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", partName = "SetBankAccountBySIN") final SetBankAccountBySINRequestType request)
  {

    LOGGER.debug("SetBankAccountBySINInCPP\n");

    final String businessTransactionID =
        request.getMessageManifest().getBusinessTransactionID().getValue();
    LOGGER.debug("-- BusinessTransactionID -- " + businessTransactionID);

    if (hasWSSecurityFaults())
    {
      handleFaultSetBankAccountBySIN(request.getMessageManifest(), "403",
          "HTTP 403 - error in username/password supplied");
    }
    else
    {
      try
      {
        adapter.onMessageSetBankAccountBySIN(request);
      }
      catch (final Exception e)
      {
        e.printStackTrace();
        LOGGER.error("Error while parsing incoming SetBankAccountBySINInCPP "
            + businessTransactionID + "\n" + e.getMessage());

        handleFaultSetBankAccountBySIN(request.getMessageManifest(), "500", e.getMessage());
      }

    }
  }

  // ---------------------------------------

  private boolean hasWSSecurityFaults()
  {
    final WSSecurityFault fault = WSSecurityFaultThreadLocal.get();
    if (StringUtils.isEmpty(fault))
    {
      return false;
    }
    else
    {
      return true;
    }
  }

  private void handleFaultSetBankAccountBySIN(final MessageManifestTransactionalCT mf,
      final String faultstring, final String detail)
  {

    final SetBankAccountBySINAsyncResponseType response =
        new SetBankAccountBySINAsyncResponseType();

    final Fault fault = buildFault(faultstring, detail);
    final String replyTo = buildReplyTo();

    response.setFault(fault);
    response.setMessageManifest(mf);

    final int httpResponseCode =
        callbackWsClient.callbackSetBankAccountBySINAsyncResponse(response, replyTo);
    LOGGER.debug("Sent Fault to DSB." + httpResponseCode);

  }

  private void handleFaultRetrieveBankAccountBySIN(final MessageManifestTransactionalCT mf,
      final String faultstring, final String detail)
  {

    final RetrieveBankAccountBySINAsyncResponseType response =
        new RetrieveBankAccountBySINAsyncResponseType();
    final Fault fault = buildFault(faultstring, detail);
    final String replyTo = buildReplyTo();

    response.setFault(fault);
    response.setMessageManifest(mf);

    final int httpResponseCode =
        callbackWsClient.callbackRetrieveBankAccountBySINAsyncResponse(response, replyTo);
    LOGGER.debug("Sent Fault to DSB." + httpResponseCode);

  }

  private Fault buildFault(final String faultstring, final String detail)
  {
    final Fault fault = new Fault();
    final QName faultName = new QName(SOAPConstants.URI_NS_SOAP_ENVELOPE, "Server");
    fault.setFaultcode(faultName);
    fault.setDetail(detail);
    fault.setFaultstring(faultstring);
    return fault;
  }

  private String buildReplyTo()
  {
    final WsAddressingReplyTo wsAddressingReplyTo = WsAddressingReplyToThreadLocal.get();
    final String replyTo = wsAddressingReplyTo.getReplyTo();
    return replyTo;
  }

}
