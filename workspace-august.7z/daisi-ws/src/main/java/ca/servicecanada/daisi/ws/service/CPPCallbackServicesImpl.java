package ca.servicecanada.daisi.ws.service;

import javax.jws.HandlerChain;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.soap.Addressing;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import ca.servicecanada.daisi.ws.endpoint.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ws.endpoint.generated.ObjectFactory;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINResponseDataAreaType;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINResponseDataAreaType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINResponseType;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFault;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFaultThreadLocal;

@Component
@Import(org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class)
@WebService(name = "CPPCallback", targetNamespace = "http://interoperability.gc.ca/service/citizenprofile/1.0")
@XmlSeeAlso({ ObjectFactory.class })
@Addressing(enabled = true, required = false)
@HandlerChain(file = "handler-chain.xml")
public class CPPCallbackServicesImpl extends SpringBeanAutowiringSupport {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Autowired
	private DaisiQueueAdapter adapter;

	@WebMethod(operationName = "RetrieveBankAccountBySINResponse", action = "RetrieveBankAccountBySINResponse")
	@Oneway
	@RequestWrapper(localName = "RetrieveBankAccountBySINResponse", 
					targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", 
					className = "ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINResponseType")
	public void retrieveBankAccountBySINResponse(
			@WebParam(name = "MessageManifest", targetNamespace = "http://interoperability.gc.ca/core/1.0") MessageManifestTransactionalCT messageManifest,
			@WebParam(name = "DataArea", targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0") RetrieveBankAccountBySINResponseDataAreaType dataArea) {

		LOGGER.debug("in callback.retrieveBankAccountBySIN ..BusinessTransactionID = "
				+ messageManifest.getBusinessTransactionID().getValue());

	    if (hasWSSecurityFaults())
	    {
	      LOGGER.debug("CPPCallbackServices/RetrieveBankAccountBySINResponse: error in username/password. Aborting.");
	      return;
	    }
	    
	    RetrieveBankAccountBySINResponseType data = new RetrieveBankAccountBySINResponseType();
		data.setDataArea(dataArea);
		data.setMessageManifest(messageManifest);
		adapter.onRetrieveBankAccountBySINResponse(data);
	}

	@WebMethod(operationName = "SetBankAccountBySINResponse", action = "SetBankAccountBySINResponse")
	@Oneway
	@RequestWrapper(localName = "SetBankAccountBySINResponse", 
					targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", 
					className = "ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINResponseType")
	public void setBankAccountBySINResponse(
			@WebParam(name = "MessageManifest", targetNamespace = "http://interoperability.gc.ca/core/1.0") MessageManifestTransactionalCT messageManifest,
			@WebParam(name = "DataArea", targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0") SetBankAccountBySINResponseDataAreaType dataArea) {

		LOGGER.debug("in callback.setBankAccountBySINResponse ..BusinessTransactionID = "
				+ messageManifest.getBusinessTransactionID().getValue());

	    if (hasWSSecurityFaults())
	    {
	      LOGGER.debug("CPPCallbackServices/RetrieveBankAccount: error in username/password. Aborting");
	      return;
	    }

	    SetBankAccountBySINResponseType data = new SetBankAccountBySINResponseType();

		data.setDataArea(dataArea);
		data.setMessageManifest(messageManifest);

		adapter.onSetBankAccountBySINResponse(data);
	}

	private boolean hasWSSecurityFaults() {
		WSSecurityFault fault = WSSecurityFaultThreadLocal.get();
		if (StringUtils.isEmpty(fault)) {
			return false;
		} else {
			return true;
		}
	}
}
