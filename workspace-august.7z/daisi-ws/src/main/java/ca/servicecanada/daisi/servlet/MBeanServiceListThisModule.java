package ca.servicecanada.daisi.servlet;

import java.util.Hashtable;
import javax.management.MBeanAttributeInfo;
import javax.management.ObjectName;

/**
 * PEN-199 - inspects the mbean hierarchy, building up a list of services as an html snippet,
 *          for the current application
 */
public class MBeanServiceListThisModule extends JMXMBeanAccess {

	  public String buildHtmlListOfServices(String servletContextPath)
	  {

		  String listContent = "<ul>";
		  
		  try
		  {
		    final ObjectName[] serverRT =
		        (ObjectName[]) connection.getAttribute(runtimeServiceBean, "ServerRuntimes");

		    final ObjectName[] apprt =
		        (ObjectName[]) connection.getAttribute(serverRT[0], "ApplicationRuntimes");
		    final int length2 = apprt.length;

		    for (int i_apprt = 0; i_apprt < length2; i_apprt++)
		    {
		      final String xx = apprt[i_apprt].getCanonicalName();
		      {
		        final ObjectName[] wseert =
		            (ObjectName[]) connection.getAttribute(apprt[i_apprt], "WseeRuntimes");
		        final int lengthj_WseeRt = wseert.length;

		        for (int j_WseeRt = 0; j_WseeRt < lengthj_WseeRt; j_WseeRt++)
		        {
		          final MBeanAttributeInfo[] WseeRtAttribs =
		              connection.getMBeanInfo(wseert[j_WseeRt]).getAttributes();

		          final Hashtable<String, String> ht1 = wseert[j_WseeRt].getKeyPropertyList();
		          for (int k_WseeRtAttribs = 0; k_WseeRtAttribs < WseeRtAttribs.length; k_WseeRtAttribs++)
		          {

		            final String attribName = WseeRtAttribs[k_WseeRtAttribs].getName();

		            if (attribName.equals("URI")) // pick one of the
		            // components of the
		            // link, any one will do
		            // - then reference the
		            // others
		            {

		              try {
						final String url = (String) connection.getAttribute(wseert[j_WseeRt], "URI");
						  // PEN-199
						  // itrjws is the context root for ITRDSWebServicesJWS,  itrws is the context root for ITRDSWebServicesEAR 
						  if (url.contains(servletContextPath)  )
						  {
						    final String webSvcDescName =
						        (String) connection.getAttribute(wseert[j_WseeRt], "WebserviceDescriptionName");

						    String sb = "";
						    listContent += "<br/><li>";
						    sb += webSvcDescName;
						    sb += "&nbsp;<a href=\"";
						    sb += "http://" + host + ":" + port.toString() + url;
						    sb += "?wsdl\"><i>(wsdl)</i></a>";
						    sb += "</li>";
						    listContent += sb;
						  }
					} catch (Exception e) {
						//Ouch. Didn't hurt that bad. Keep going.
//						e.printStackTrace();
					}
		            }
		          }
		        }
		      }
		    }

		    //Let's add one more to the list. We have a WADL available to list the REST services.
            String sb = "";
            listContent += "<br/><li>";
            sb += "REST Services";
            sb += "&nbsp;<a href=\"";
            sb += "http://" + host + ":" + port.toString() + "/DAISI/application";
            sb += ".wadl\"><i>(wadl)</i></a>";
            sb += "</li>";
            listContent += sb;
			listContent += "</ul>";
		  }
		  catch (Exception ex)
		  {
		  }
		  return listContent;
	  }

}
