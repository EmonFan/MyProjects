package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.io.StringWriter;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINResponseType;

@Component
public class DsbToDaisiCanonicalFormTranslator {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private DataAreaAdapter dataAreaAdapter;

	public DaisiExchangeRequest transformRetrieveBankAccountBySINAsyncResponse(
			RetrieveBankAccountBySINResponseType dsbResponse) {

		DaisiExchangeRequest request = new DaisiExchangeRequest();
		
		String resultCode = null;
		String businessTransactionID = null;
		String rejectedCode = null;
		try {
			resultCode = dsbResponse.getDataArea().getProcessingStatus().getResultCode();
			rejectedCode = dsbResponse.getDataArea().getProcessingStatus().getRejectedCode();
			businessTransactionID = dsbResponse.getMessageManifest().getBusinessTransactionID().getValue();
		} catch (Exception e) {
			LOGGER.debug("Problem getting dsbResponse values.");
		}
		
		String accountNumber = null;
		String institutionNumber = null;
		String transitNumber = null;
		
		if("Accepted".equalsIgnoreCase(resultCode)){
			accountNumber = dsbResponse.getDataArea().getBankAccount().getAccountNumber();
			institutionNumber = dsbResponse.getDataArea().getBankAccount().getInstitution();
			transitNumber = dsbResponse.getDataArea().getBankAccount().getTransit();
		} else {
			LOGGER.info("request is <probably> rejected.");
		}

		request.setAccountNumber(accountNumber);
		request.setInstitution(institutionNumber);
		request.setTransitNumber(transitNumber);
		request.setId(businessTransactionID);
		request.setResultCode(resultCode);
		request.setRejectedCode(rejectedCode);
		
		return request;
	}

	// PUSH
	public DaisiExchangeRequest transformRetrieveBankAccountBySINAsyncResponse(
			SetBankAccountBySINResponseType dsbResponse) {

		DaisiExchangeRequest request = new DaisiExchangeRequest();

		String resultCode = null;
		String businessTransactionID = null;
		String rejectedCode = null;
		try {
			resultCode = dsbResponse.getDataArea().getProcessingStatus().getResultCode();
			rejectedCode = dsbResponse.getDataArea().getProcessingStatus().getRejectedCode();
			businessTransactionID = dsbResponse.getMessageManifest().getBusinessTransactionID().getValue();
		} catch (Exception e) {
			LOGGER.debug("Problem getting dsbResponse values.");
		}

		request.setId(businessTransactionID);
		request.setResultCode(resultCode);
		request.setRejectedCode(rejectedCode);

		return request;
	}

	public DaisiExchangeRequest transformRetrieveBankAccountBySINRequest(
			RetrieveBankAccountBySINRequestType dsbRequest) {

		DaisiExchangeRequest request = new DaisiExchangeRequest();

		String birthDate = dsbRequest.getDataArea().getBirthDate();
		String sin = dsbRequest.getDataArea().getSocialInsuranceNumber();
		String surname = dsbRequest.getDataArea().getSurname();
		//

		String businessTransactionID = dsbRequest.getMessageManifest().getBusinessTransactionID().getValue();
		String channel = dsbRequest.getDataArea().getChannel();
		String channelType = null;
		try {
			channelType = dataAreaAdapter.toChannelType(channel);
		} catch (Exception e) {
			LOGGER.warn("channel is probably null.");
		}

		String program = dsbRequest.getDataArea().getProgram();
		String sharingAgreementID = dsbRequest.getDataArea().getSharingAgreementID();
		String consentStatementType = null;
		try {
			consentStatementType = dataAreaAdapter.toConsentStatementType(sharingAgreementID, channel);
		} catch (Exception e) {
			LOGGER.warn("sharing agreemen and/or channel is probably null.");
		}

		String systemID = dsbRequest.getMessageManifest().getSystemID().getValue();
		
		XMLGregorianCalendar businessTransactionDateTime = dsbRequest.getMessageManifest().getBusinessTransactionDateTime();

		// ---------------
		request.setBirthDate(birthDate);
		request.setSin(sin);
		request.setSurname(surname);

		request.setId(businessTransactionID);
		request.setChannelType(channelType);
		request.setConsentStatementType(consentStatementType);
		request.setConsentCode(sharingAgreementID);

		// TODO: confirm this:
		request.setOrganizationTypeSource(systemID);
		request.setProgramServiceTypeSource(program);
		
		request.setBusinessTransactionDateTime(businessTransactionDateTime);

		return request;
	}

	public DaisiExchangeRequest transformSetBankAccountBySINRequest(SetBankAccountBySINRequestType dsbRequest) {

		DaisiExchangeRequest request = new DaisiExchangeRequest();

		String birthDate = null;
		String sin = null;
		String surname = null;
		String accountNumber = null;
		String institutionNumber = null;
		String transitNumber = null;
		String businessTransactionID = null;
		String channelType = null;
		String program = null;
		String sharingAgreementID = null;
		String consentStatementType = null;
		String systemID = null;
		try {
			birthDate = dsbRequest.getDataArea().getBirthDate();
			sin = dsbRequest.getDataArea().getSocialInsuranceNumber();
			surname = dsbRequest.getDataArea().getSurname();

			accountNumber = dsbRequest.getDataArea().getBankAccount().getAccountNumber();
			institutionNumber = dsbRequest.getDataArea().getBankAccount().getInstitution();
			transitNumber = dsbRequest.getDataArea().getBankAccount().getTransit();

			String channel = dsbRequest.getDataArea().getChannel();
			channelType = dataAreaAdapter.toChannelType(channel);

			program = dsbRequest.getDataArea().getProgram();
			sharingAgreementID = dsbRequest.getDataArea().getSharingAgreementID();
			consentStatementType = dataAreaAdapter.toConsentStatementType(sharingAgreementID, channel);

			systemID = dsbRequest.getMessageManifest().getSystemID().getValue();
		} catch (Exception e) {
			LOGGER.debug("having an issue with values in transformSetBankAccountBySINRequest");
		}

		businessTransactionID = dsbRequest.getMessageManifest().getBusinessTransactionID().getValue();
		
		XMLGregorianCalendar businessTransactionDateTime = dsbRequest.getMessageManifest().getBusinessTransactionDateTime();
		
		request.setBusinessTransactionDateTime(businessTransactionDateTime);

		// ---------------
		request.setId(businessTransactionID);
		request.setBirthDate(birthDate);
		request.setSin(sin);
		request.setSurname(surname);

		request.setAccountNumber(accountNumber);
		request.setInstitution(institutionNumber);
		request.setTransitNumber(transitNumber);

		request.setId(businessTransactionID);
		request.setChannelType(channelType);
		request.setConsentStatementType(consentStatementType);
		request.setConsentCode(sharingAgreementID);

		request.setOrganizationTypeSource(systemID);
		request.setProgramServiceTypeSource(program);

		return request;

	}

	public String unmarshall(Object data) {
		return unmarshall(data, DaisiExchangeRequest.class);
	}

	public String unmarshall(Object data, Class clazz) {
		StringWriter tempHolder = new StringWriter();

		JAXBContext jxbClientContext = null;
		Marshaller jxbClientMarshaler = null;

		try {
			jxbClientContext = JAXBContext.newInstance(clazz);
			jxbClientMarshaler = jxbClientContext.createMarshaller();
			// Removes the <?xml ....?> tag
			jxbClientMarshaler.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			jxbClientMarshaler.marshal(data, tempHolder);

		} catch (JAXBException e) {
			e.printStackTrace();
		}
		String tmp = tempHolder.toString();
		LOGGER.debug(tmp);
		return tmp;

	}
}
