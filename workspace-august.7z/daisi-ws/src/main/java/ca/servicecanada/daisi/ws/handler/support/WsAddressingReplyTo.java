package ca.servicecanada.daisi.ws.handler.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.util.StringUtils;

/**
 * 
 * <wsa:Action>RetrieveBankAccountBySINFromCPPCallback</wsa:Action>
 * <wsa:MessageID>urn:d7c9593f-9759-11e7-aeea-bac5fd330506</wsa:MessageID>
 * <wsa:RelatesTo>urn:d7c9593f-9759-11e7-aeea-bac5fd330506</wsa:RelatesTo>
 *
 */
public class WsAddressingReplyTo {

	private Logger LOGGER = LogManager.getLogger(getClass());

	private String replyTo;
	private String relatesTo;
	private String messageID;

	public String getRelatesTo() {
		return relatesTo;
	}

	public String getMessageID() {
		return messageID;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String data) {
		if (StringUtils.isEmpty(data)) {
			LOGGER.error("replyTo is empty ..");
		} else {
			this.replyTo = StringUtils.trimAllWhitespace(data);
			LOGGER.debug("replyTo = " + replyTo);
		}
	}

	public void setRelatesTo(String data) {
		if (StringUtils.isEmpty(data)) {
			LOGGER.error("relatesTo is empty ..");
		} else {
			this.relatesTo = StringUtils.trimAllWhitespace(data);
			LOGGER.debug("relatesTo = " + relatesTo);
		}
	}

	public void setMessageID(String data) {
		if (StringUtils.isEmpty(data)) {
			LOGGER.error("messageID is empty ..");
		} else {
			this.messageID = StringUtils.trimAllWhitespace(data);
			LOGGER.debug("messageID = " + messageID);
		}
	}

}
