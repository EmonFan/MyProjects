package ca.servicecanada.daisi.ei.endpoint.dsb;

public class DataAreaAdapterDBLookUp implements DataAreaAdapter {

	@Override
	public String toConsentStatementType(String sharingAgreementID, String channel) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String toChannelType(String channel) {
		// TODO Auto-generated method stub
		return null;
	}


	

}
