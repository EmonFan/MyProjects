package ca.servicecanada.daisi.ws.validation;

public interface WSValidator {

	public boolean validate(String UserId, String Password);

}
