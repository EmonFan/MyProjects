package ca.servicecanada.daisi.ei.endpoint.dsb;

public interface DataAreaAdapter {

	public String toConsentStatementType(String sharingAgreementID, String channel);
	
	public String toChannelType( String channel);

}
