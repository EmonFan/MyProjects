/**
 * CsSystemException.java This file was auto-generated from WSDL by the Apache Axis 1.2.1 Jun 14,
 * 2005 (09:15:57 EDT) WSDL2Java emitter.
 */

package ca.servicecanada.daisi.ws.service.common;

import java.io.PrintWriter;
import java.io.StringWriter;

public class DaisiWSException extends Exception implements java.io.Serializable
{
  private DaisiWSExceptionCD errorCode;

  private java.lang.String errorMessage;

  public enum DaisiWSExceptionCD
  {
    NO_DATA_RETURNED, //
    AUTHENTICATION_FAILED, //
    UNEXPECTED_THROWABLE;
  }

  public DaisiWSException()
  {
  }

  public DaisiWSException(final DaisiWSExceptionCD errorCode, final java.lang.String errorMessage)
  {
    this.errorCode = errorCode;
    this.errorMessage = errorMessage;

  }

  public DaisiWSException(final DaisiWSExceptionCD errorCode, final Throwable e)
  {
    this(errorCode, "", e);
  }

  public DaisiWSException(final DaisiWSExceptionCD errorCode, final java.lang.String errorMessage,
      final Throwable e)
  {
    final StringWriter sw = new StringWriter();
    final PrintWriter pw = new PrintWriter(sw);
    e.printStackTrace(pw);
    pw.flush();
    this.errorMessage = errorMessage;
    this.errorCode = errorCode;

  }

  /**
   * Gets the errorCode value for this CsSystemException.
   *
   * @return errorCode
   */
  public DaisiWSExceptionCD getErrorCode()
  {
    return errorCode;
  }

  /**
   * Sets the errorCode value for this CsSystemException.
   *
   * @param errorCode
   */
  public void setErrorCode(final DaisiWSExceptionCD errorCode)
  {
    this.errorCode = errorCode;
  }

  /**
   * Gets the errorMessage value for this CsSystemException.
   *
   * @return errorMessage
   */
  public java.lang.String getErrorMessage()
  {
    return errorMessage;
  }

  /**
   * Sets the errorMessage value for this CsSystemException.
   *
   * @param errorMessage
   */
  public void setErrorMessage(final java.lang.String errorMessage)
  {
    this.errorMessage = errorMessage;
  }

  @Override
  public String toString()
  {
    final String result = "\n******** CsSystemException **********" //
        + "\n  errorCode    = " + (errorCode != null
            ? errorCode.name()
            : "null") //
        + "\n  errorMessage = " + (errorMessage != null
            ? errorMessage
            : "null");
    return result;
  }
}
