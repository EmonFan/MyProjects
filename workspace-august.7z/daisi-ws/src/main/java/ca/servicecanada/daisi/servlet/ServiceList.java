package ca.servicecanada.daisi.servlet;

import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * PEN-199
 */
public class ServiceList extends HttpServlet
{

  /**
   * This class is meant to perform the same function as the behaviour of Axis when the Axis runtime
   * gets a request without a servlet specified.
   */
  private static final long serialVersionUID = 1L;

  ServletContext context = null;

  @Override
  public void init()
  {
    context = getServletContext();
  }

  @Override
  public void doGet(final HttpServletRequest httpRequest, final HttpServletResponse httpResponse)
      throws ServletException
  {

    final String url = context.getContextPath();

    final PrintWriter writer = new FilterPrintWriter(httpResponse);

    final MBeanServiceListThisModule mbeanServiceListThisModule = new MBeanServiceListThisModule();
    final int result = mbeanServiceListThisModule.initializeJMXAccess(httpRequest, httpResponse);

    final String htmlPartial =
        mbeanServiceListThisModule.getServicePageHtmlBeforeList("Services List - " + url);

    String listContent = null;
    if (result == JMXMBeanAccess.ADMIN_SERVER) // admin server
    {
      listContent = mbeanServiceListThisModule.buildHtmlListOfServices(url);
    }
    else
    {
      if (result == JMXMBeanAccess.MANAGED_SERVER) // managed server
      {
        listContent = mbeanServiceListThisModule.buildHtmlListOfServices(url);
      }
      else
      {
        listContent = "<br/><br/>Server type detection error.<br/><br/>";
      }
    }

    httpResponse.setContentType("text/html; charset=utf-8");

    final String htmlh1 = "<h1>Services List - " + url + "</h1>";
    writer.println(htmlPartial + htmlh1 + listContent
        + mbeanServiceListThisModule.getServicePageHtmlAfterList());

    writer.close();
  }
}
