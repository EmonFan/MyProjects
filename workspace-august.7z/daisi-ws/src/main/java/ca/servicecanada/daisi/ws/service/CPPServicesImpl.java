package ca.servicecanada.daisi.ws.service;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.wsaddressing.W3CEndpointReference;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINRequestType;

public class CPPServicesImpl {

	private Logger LOGGER = LogManager.getLogger(getClass());

	private String WSDL_LOCATION = "http://localhost:7001/daisi-dsb-0.0.1-SNAPSHOT/BankAccountServiceCallbackService?WSDL";

	private String NS = "http://ws.daisi.dsb.ca/";
	private String SERVICE_NAME = "BankAccountServiceCallbackService";
	private QName qName = new QName(NS, SERVICE_NAME);

	@Resource
	private WebServiceContext context;

	// @Override
	public void retrieveBankAccountBySIN(W3CEndpointReference w3cEpr,
			RetrieveBankAccountBySINRequestType retrieveBankAccountBySINRequest) {

		// callback();
		try {
			Thread t = new Thread(new CallbackHandler());
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		// t.start();
		// LOGGER.debug("returning responseCode =202" );
		// //return 202;
		//
		// HeaderList hl = (HeaderList)
		// context.getMessageContext().get(JAXWSProperties.INBOUND_HEADER_LIST_PROPERTY);
		//// // // gets the addressing informations in the SOAP header
		// WSEndpointReference reference = hl.getReplyTo(AddressingVersion.W3C,
		// SOAPVersion.SOAP_11);
		// String messageId = hl.getMessageID(AddressingVersion.W3C,
		// SOAPVersion.SOAP_11);
		// //
		// URL wsdlUrl;
		// try {
		// wsdlUrl = new URL(WSDL_LOCATION);
		// } catch (MalformedURLException e) {
		// e.printStackTrace();
		// throw new RuntimeException(e);
		//// }
		//
		// LOGGER.debug("callback WSDL: "+wsdlUrl.getPath());
		//
		//// BankAccountServiceCallbackService svs = new
		// BankAccountServiceCallbackService(wsdlUrl, qName);
		//// BankAccountServiceCallback bankAccountServiceCallback =
		// svs.getBankAccountServiceCallbackPort();

	}

	class CallbackHandler implements Runnable {

		public void run() {
			try {
				Thread.sleep(1000 * 20);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// HeaderList hl = (HeaderList)
			// context.getMessageContext().get(JAXWSProperties.INBOUND_HEADER_LIST_PROPERTY);
			// // // gets the addressing informations in the SOAP header
			// WSEndpointReference reference =
			// hl.getReplyTo(AddressingVersion.W3C, SOAPVersion.SOAP_11);
			// String messageId = hl.getMessageID(AddressingVersion.W3C,
			// SOAPVersion.SOAP_11);
			//
			// URL wsdlUrl;
			// try {
			// wsdlUrl = new URL(WSDL_LOCATION);
			// } catch (MalformedURLException e) {
			// e.printStackTrace();
			// throw new RuntimeException(e);
			// }
			//
			// LOGGER.debug("callback WSDL: "+wsdlUrl.getPath());
			// LOGGER.debug("Reply to messageID: "+messageId);

			// BankAccountServiceCallbackService svs = new
			// BankAccountServiceCallbackService(wsdlUrl, qName);
			// BankAccountServiceCallback bankAccountServiceCallback =
			// svs.getBankAccountServiceCallbackPort();
			//
			// WSBindingProvider bp = (WSBindingProvider)
			// bankAccountServiceCallback;
			//
			// bp.setAddress(reference.getAddress());
			// bp.setOutboundHeaders(Headers.create(AddressingVersion.W3C.relatesToTag,
			// messageId));
			// LOGGER.debug("Call back address = " + reference.getAddress());
			// LOGGER.debug("Message id = " + messageId);
			// LOGGER.debug("call callback now
			// ************************************************************");
			// //
			//
			// RetrieveBankAccountBySINAsyncResponseType response = new
			// RetrieveBankAccountBySINAsyncResponseType();
			// parameters.setReturn("RETURNED FROM TARGET!!");
			//
			// bankAccountServiceCallback.handleNotification(parameters);

		}
	}

}
