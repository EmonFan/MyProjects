
package ca.servicecanada.daisi.ws.endpoint.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PublishBankAccountAppliedBySINAsyncResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PublishBankAccountAppliedBySINAsyncResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://interoperability.gc.ca/core/1.0}MessageManifest"/>
 *         &lt;choice>
 *           &lt;element name="DataArea" type="{http://interoperability.gc.ca/entity/citizenprofile/1.0}PublishBankAccountAppliedBySINResponseDataAreaType"/>
 *           &lt;element name="Fault" type="{http://interoperability.gc.ca/core/1.0}Fault"/>
 *         &lt;/choice>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PublishBankAccountAppliedBySINAsyncResponseType", propOrder = {
    "messageManifest",
    "dataArea",
    "fault"
})
public class PublishBankAccountAppliedBySINAsyncResponseType {

    @XmlElement(name = "MessageManifest", namespace = "http://interoperability.gc.ca/core/1.0", required = true)
    protected MessageManifestTransactionalCT messageManifest;
    @XmlElement(name = "DataArea")
    protected PublishBankAccountAppliedBySINResponseDataAreaType dataArea;
    @XmlElement(name = "Fault")
    protected Fault fault;

    /**
     * Gets the value of the messageManifest property.
     * 
     * @return
     *     possible object is
     *     {@link MessageManifestTransactionalCT }
     *     
     */
    public MessageManifestTransactionalCT getMessageManifest() {
        return messageManifest;
    }

    /**
     * Sets the value of the messageManifest property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageManifestTransactionalCT }
     *     
     */
    public void setMessageManifest(MessageManifestTransactionalCT value) {
        this.messageManifest = value;
    }

    /**
     * Gets the value of the dataArea property.
     * 
     * @return
     *     possible object is
     *     {@link PublishBankAccountAppliedBySINResponseDataAreaType }
     *     
     */
    public PublishBankAccountAppliedBySINResponseDataAreaType getDataArea() {
        return dataArea;
    }

    /**
     * Sets the value of the dataArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link PublishBankAccountAppliedBySINResponseDataAreaType }
     *     
     */
    public void setDataArea(PublishBankAccountAppliedBySINResponseDataAreaType value) {
        this.dataArea = value;
    }

    /**
     * Gets the value of the fault property.
     * 
     * @return
     *     possible object is
     *     {@link Fault }
     *     
     */
    public Fault getFault() {
        return fault;
    }

    /**
     * Sets the value of the fault property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fault }
     *     
     */
    public void setFault(Fault value) {
        this.fault = value;
    }

}
