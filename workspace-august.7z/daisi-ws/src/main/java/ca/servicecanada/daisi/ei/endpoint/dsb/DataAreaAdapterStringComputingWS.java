package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class DataAreaAdapterStringComputingWS implements DataAreaAdapter {

	private Logger LOGGER = LogManager.getLogger(getClass());

	/**
	 * {S|PHONE=STL, R|PHONE=RTL, S|FORM=SFO, S|ONLINE=SON, R|ONLINE=RON,
	 * R|FORM=UNDEFINED}
	 */
	private Map<String, String> daisiToCraConsentMap;

	private Map<String, String> daisiToCraChannelMap;

	private static final String CONSENT_TYPE_DD_SEND_ONLINE = "SON";
	private static final String CONSENT_TYPE_DD_REQUEST_ONLINE = "RON";
	private static final String CONSENT_TYPE_DD_SEND_PHONE = "STL";
	private static final String CONSENT_TYPE_DD_REQUEST_PHONE = "RTL";
	private static final String CONSENT_TYPE_DD_SEND_FORM = "SFO";
	private static final String CONSENT_TYPE_DD_REQUEST_FORM = "UNDEFINED";

	private static final String CHANNEL_TYPE_ONLINE = "ONLINE";
	private static final String CHANNEL_TYPE_PHONE = "PHONE";
	private static final String CHANNEL_TYPE_FORM = "FORM";

	private static final String ACTION_TYPE_REQUEST = "R";
	private static final String ACTION_TYPE_SEND = "S";

	private static final String SEPARATOR = "|";

	private static final String DD_SEND_ONLINE = ACTION_TYPE_SEND + SEPARATOR + CHANNEL_TYPE_ONLINE;
	private static final String DD_SEND_PHONE = ACTION_TYPE_SEND + SEPARATOR + CHANNEL_TYPE_PHONE;
	private static final String DD_SEND_FORM = ACTION_TYPE_SEND + SEPARATOR + CHANNEL_TYPE_FORM;

	private static final String DD_REQUEST_ONLINE = ACTION_TYPE_REQUEST + SEPARATOR + CHANNEL_TYPE_ONLINE;
	private static final String DD_REQUEST_PHONE = ACTION_TYPE_REQUEST + SEPARATOR + CHANNEL_TYPE_PHONE;
	private static final String DD_REQUEST_FORM = ACTION_TYPE_REQUEST + SEPARATOR + CHANNEL_TYPE_FORM;

	public DataAreaAdapterStringComputingWS() {
		daisiToCraConsentMap = new HashMap<String, String>();
		daisiToCraChannelMap = new HashMap<String, String>();
		buildDaisiToCraConsentMap();
		buildDaisiToCraChannelMap();
	}

	void buildDaisiToCraConsentMap() {
		daisiToCraConsentMap.put(DD_SEND_ONLINE, CONSENT_TYPE_DD_SEND_ONLINE);
		daisiToCraConsentMap.put(DD_SEND_PHONE, CONSENT_TYPE_DD_SEND_PHONE);
		daisiToCraConsentMap.put(DD_SEND_FORM, CONSENT_TYPE_DD_SEND_FORM);

		daisiToCraConsentMap.put(DD_REQUEST_ONLINE, CONSENT_TYPE_DD_REQUEST_ONLINE);
		daisiToCraConsentMap.put(DD_REQUEST_PHONE, CONSENT_TYPE_DD_REQUEST_PHONE);
		daisiToCraConsentMap.put(DD_REQUEST_FORM, CONSENT_TYPE_DD_REQUEST_FORM);

	}

	void buildDaisiToCraChannelMap() {
		daisiToCraChannelMap.put("Online", "ONL");
		daisiToCraChannelMap.put("Phone", "TEL");
		daisiToCraChannelMap.put("Form", "FRM");

	}

	@Override
	public String toConsentStatementType(String sharingAgreementID, String channel) {
		LOGGER.debug("Adapting  sharingAgreementID = " + sharingAgreementID + ", channel = " + channel);

		if (sharingAgreementID == null || sharingAgreementID.length() < 3) {
			throw new IllegalArgumentException("sharingAgreementID is null or too short");
		}

		String transactionType = sharingAgreementID.substring(2, 3).toUpperCase();

		String key = transactionType + SEPARATOR + channel.toUpperCase();

		String consentType;

		if (daisiToCraConsentMap.containsKey(key)) {
			consentType = daisiToCraConsentMap.get(key);
		} else {
			LOGGER.error("Can't find consent Statement Type for input " + key);
			throw new IllegalArgumentException("Can't find consent Statement Type for input " + key);
		}

		return consentType;
	}

	@Override
	public String toChannelType(String channel) {
		String channelType;
		if (daisiToCraChannelMap.containsKey(channel)) {
			channelType = daisiToCraChannelMap.get(channel);
		} else {
			LOGGER.error("Can't find channel type for input " + channel);
			throw new IllegalArgumentException("Can't find channel type for input " + channel);
		}

		return channelType;

	}

}
