package ca.servicecanada.daisi.ws.handler.support;

public class WSSecurityFault {

	private String wsError;

	public String getFault() {
		return wsError;
	}

	public void setFault(String wsError) {
		this.wsError = wsError;
	}
}
