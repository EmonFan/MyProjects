
package ca.servicecanada.daisi.ws.endpoint.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RetrieveBankAccountBySINResponseDataAreaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrieveBankAccountBySINResponseDataAreaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BankAccount" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                 &lt;sequence>
 *                   &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Transit"/>
 *                   &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}AccountNumber"/>
 *                   &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Institution"/>
 *                 &lt;/sequence>
 *               &lt;/restriction>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *         &lt;element name="ProcessingStatus" type="{http://interoperability.gc.ca/entity/citizenprofile/1.0}ProcessingStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveBankAccountBySINResponseDataAreaType", propOrder = {
    "bankAccount",
    "processingStatus"
})
public class RetrieveBankAccountBySINResponseDataAreaType {

    @XmlElement(name = "BankAccount")
    protected RetrieveBankAccountBySINResponseDataAreaType.BankAccount bankAccount;
    @XmlElement(name = "ProcessingStatus", required = true)
    protected ProcessingStatus processingStatus;

    /**
     * Gets the value of the bankAccount property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveBankAccountBySINResponseDataAreaType.BankAccount }
     *     
     */
    public RetrieveBankAccountBySINResponseDataAreaType.BankAccount getBankAccount() {
        return bankAccount;
    }

    /**
     * Sets the value of the bankAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveBankAccountBySINResponseDataAreaType.BankAccount }
     *     
     */
    public void setBankAccount(RetrieveBankAccountBySINResponseDataAreaType.BankAccount value) {
        this.bankAccount = value;
    }

    /**
     * Gets the value of the processingStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ProcessingStatus }
     *     
     */
    public ProcessingStatus getProcessingStatus() {
        return processingStatus;
    }

    /**
     * Sets the value of the processingStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProcessingStatus }
     *     
     */
    public void setProcessingStatus(ProcessingStatus value) {
        this.processingStatus = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *       &lt;sequence>
     *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Transit"/>
     *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}AccountNumber"/>
     *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Institution"/>
     *       &lt;/sequence>
     *     &lt;/restriction>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "transit",
        "accountNumber",
        "institution"
    })
    public static class BankAccount {

        @XmlElement(name = "Transit", required = true)
        protected String transit;
        @XmlElement(name = "AccountNumber", required = true)
        protected String accountNumber;
        @XmlElement(name = "Institution", required = true)
        protected String institution;

        /**
         * Gets the value of the transit property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTransit() {
            return transit;
        }

        /**
         * Sets the value of the transit property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTransit(String value) {
            this.transit = value;
        }

        /**
         * Gets the value of the accountNumber property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getAccountNumber() {
            return accountNumber;
        }

        /**
         * Sets the value of the accountNumber property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setAccountNumber(String value) {
            this.accountNumber = value;
        }

        /**
         * Gets the value of the institution property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getInstitution() {
            return institution;
        }

        /**
         * Sets the value of the institution property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setInstitution(String value) {
            this.institution = value;
        }

    }

}
