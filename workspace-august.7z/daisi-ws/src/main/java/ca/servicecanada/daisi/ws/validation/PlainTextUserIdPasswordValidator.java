package ca.servicecanada.daisi.ws.validation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;

public class PlainTextUserIdPasswordValidator implements WSValidator {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Value("${ws.username}")
	private String username;

	@Value("${ws.password}")
	private String password;

	// @Override
	public boolean validate(String user, String pswd) {
		if (username.equals(user) && password.equals(pswd)) {
			LOGGER.debug("WS-security passed");
			return true;
		} else {
			LOGGER.warn("WS-security failed for username provided: " + user);
			return false;
		}
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
