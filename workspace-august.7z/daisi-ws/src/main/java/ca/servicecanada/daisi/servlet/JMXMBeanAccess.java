package ca.servicecanada.daisi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Hashtable;

import javax.management.AttributeNotFoundException;
import javax.management.InstanceNotFoundException;
import javax.management.MBeanAttributeInfo;
import javax.management.MBeanException;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.ReflectionException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * PEN-199 - base class for mbean classes which build service lists. Only one of the three classes
 * actually got committed, though, so this class looks [prett unnecessary.
 */
public class JMXMBeanAccess
{

  protected MBeanServerConnection connection = null;

  protected ObjectName runtimeServiceBean = null;

  protected String host = null;

  protected Integer port = null;

  protected ObjectName serverRT = null;

  public static final int ADMIN_SERVER = 1;

  public static final int MANAGED_SERVER = 2;

  public static final int ERROR_DETECTING_SERVER = -1;

  private final String BEAN_URI_ADMIN_SERVER =
      "com.bea:Name=DomainRuntimeService,Type=weblogic.management.mbeanservers.domainruntime.DomainRuntimeServiceMBean";

  private final String BEAN_URI_MANAGED_SERVER =
      "com.bea:Name=RuntimeService,Type=weblogic.management.mbeanservers.runtime.RuntimeServiceMBean";

  private final String DOMAIN_RUNIME_URI_ADMIN_SERVER = "java:comp/env/jmx/domainRuntime";

  private final String DOMAIN_RUNIME_URI_MANAGED_SERVER = "java:comp/env/jmx/runtime";

  public int initializeJMXAccess(final HttpServletRequest httpRequest,
      final HttpServletResponse httpResponse)
  {
    String reason = "";
    try
    {

      final InitialContext ctx = new InitialContext();

      //final MBeanServerConnection 

      boolean isAdmin = false;
      boolean exceptionOnTestAdmin = false;
      boolean exceptionOnTestManaged = false;
      try
      {
        connection = (MBeanServerConnection) ctx.lookup(DOMAIN_RUNIME_URI_ADMIN_SERVER);
        runtimeServiceBean = new ObjectName(BEAN_URI_ADMIN_SERVER);

        reason += "runtimeServiceBean not null";
        System.out.println("runtimeServiceBean not null");
        // Here can be several
        final ObjectName[] serverRuntimeMBeans =
            (ObjectName[]) connection.getAttribute(runtimeServiceBean, "ServerRuntimes");

        port = (Integer) connection.getAttribute(serverRuntimeMBeans[0], "ListenPort");

        host = (String) connection.getAttribute(serverRuntimeMBeans[0], "AdminServerHost");

        serverRT = serverRuntimeMBeans[0];
        reason += "host and port determined";
        System.out.println("host and port determined");

        isAdmin = true;
        return JMXMBeanAccess.ADMIN_SERVER;
      }
      catch (final Exception ex)
      {
        reason += "try Admin\r\n" + ex.getMessage();
        System.out.println("try Admin\r\n" + ex.getMessage());
        exceptionOnTestAdmin = true;
      }

      if (isAdmin)
      {
        final int noop = 0;
        reason += "reports as Admin";
        System.out.println("reports as Admin");
      }
      else
      {
        reason += "trying Managed\r\n";
        try
        {
          connection = (MBeanServerConnection) ctx.lookup(DOMAIN_RUNIME_URI_MANAGED_SERVER);
          runtimeServiceBean = new ObjectName(BEAN_URI_MANAGED_SERVER);
          reason += "reports as Managed";
          System.out.println("reports as Managed");

          reason += "runtimeServiceBean not null";
          System.out.println("runtimeServiceBean not null");
          // Here can be several
          serverRT = (ObjectName) connection.getAttribute(runtimeServiceBean, "ServerRuntime");

          port = (Integer) connection.getAttribute(serverRT, "ListenPort");

          host = (String) connection.getAttribute(serverRT, "AdminServerHost");

          reason += "host and port determined";
          System.out.println("host and port determined");
          return JMXMBeanAccess.MANAGED_SERVER; //reason;
        }
        catch (final Exception ex)
        {
          reason += "try Managed\r\n" + ex.getMessage();
          System.out.println("try Managed\r\n" + ex.getMessage());
          exceptionOnTestManaged = true;
        }
      }

      if (runtimeServiceBean == null)
      {
        reason += "runtimeService Bean null";
        System.out.println("runtimeService Bean null");
        return JMXMBeanAccess.ERROR_DETECTING_SERVER;

      }
      else
      {

        //      final String name = (String) connection.getAttribute(serverRuntimeMBeans[0], "Name");
        //
        //      final String address = (String) connection.getAttribute(serverRuntimeMBeans[0], "ListenAddress");
        //
        //      final String webLogicHome = (String) connection.getAttribute(serverRuntimeMBeans[0], "WeblogicHome");
        //
        //      final String oracleHome = (String) connection.getAttribute(serverRuntimeMBeans[0], "OracleHome");
        //
        //      final String currentDirectory = (String) connection.getAttribute(serverRuntimeMBeans[0], "CurrentDirectory");
        //
        //      final String serverClasspath = (String) connection.getAttribute(serverRuntimeMBeans[0], "ServerClasspath");
        //
        //      final MBeanAttributeInfo[] atribs = connection.getMBeanInfo(serverRuntimeMBeans[0]).getAttributes();
      }

    }
    catch (final NamingException ex)
    {
      System.out.println(ex.toString());
      //    } catch (final MalformedObjectNameException ex) {
      //      System.out.println(ex.toString());
    }
    catch (final Exception ex)
    {
      System.out.println(ex.toString());
      ex.printStackTrace();
    }

    return JMXMBeanAccess.ERROR_DETECTING_SERVER;

  }

  private String findAttributeTypeAndGetValue(final MBeanAttributeInfo mbean,
      final ObjectName objWithMBeanAttribs, final MBeanServerConnection connection)
  {

    String retVal = "noPathTaken";
    final String attributeName = mbean.getName();
    final String attributeType = mbean.getType();
    try
    {
      switch (attributeType)
      {
      case "java.lang.String":
      {
        retVal = (String) connection.getAttribute(objWithMBeanAttribs, attributeName);
        break;
      }
      case "javax.management.openmbean.CompositeData":
      {
        break;
      }
      case "java.lang.Integer":
      {
        int dummy = 0;
        dummy++;
        final Integer attribAsInteger =
            (Integer) connection.getAttribute(objWithMBeanAttribs, attributeName);
        retVal = attribAsInteger.toString();
        break;
      }
      case "java.lang.Boolean":
      {
        retVal = "Not handled";
        break;
      }
      case "java.lang.Long":
      {
        int dummy = 0;
        dummy++;
        final Long attribAsLong =
            (Long) connection.getAttribute(objWithMBeanAttribs, attributeName);
        retVal = attribAsLong.toString();
        break;
      }
      case "javax.management.ObjectName":
      {
        final ObjectName attribVal =
            (ObjectName) connection.getAttribute(objWithMBeanAttribs, attributeName);
        retVal = "javax.managemant.ObjectName - TODO";
        break;
      }
      case "[Ljava.lang.String":
      {
        final String[] arrayRetVals =
            (String[]) connection.getAttribute(objWithMBeanAttribs, attributeName);
        final int lenArray = arrayRetVals.length;
        for (int looper = 0; looper < lenArray; looper++)
        {
          retVal += arrayRetVals[looper];
        }
        break;
      }
      case "weblogic.health.HealthState":
      {
        break;
      }
      case "[Ljavax.management.ObjectName":
      {
        final ObjectName[] attribVals =
            (ObjectName[]) connection.getAttribute(objWithMBeanAttribs, attributeName);
        if (attribVals == null)
        {
          retVal = attributeType + "resulted in null";
        }
        else
        {
          if (attribVals.length > 0)
          {
            retVal = attribVals[0].getCanonicalName();
          }
          else
          {
            int dummy5 = 0;
            dummy5++;
          }
        }
        break;
      }
      case "java.util.HashMap":
      {
        retVal = "Not handled";
        break;
      }
      default:
        retVal = "Not handled";
        break;
      }

    }
    catch (final IOException ex)
    {
      int dummy = 0;
      dummy++;
    }
    catch (final ReflectionException ex)
    {
      int dummy = 0;
      dummy++;
    }
    catch (final InstanceNotFoundException ex)
    {
      int dummy = 0;
      dummy++;
    }
    catch (final AttributeNotFoundException ex)
    {
      int dummy = 0;
      dummy++;
    }
    catch (final MBeanException ex)
    {
      int dummy = 0;
      dummy++;
    }
    return retVal;
  }

  public void getAndWriteServiceInfo(final HttpServletResponse response,
      final HttpServletRequest request, String body, final String host, final Integer port,
      final Context ctx) throws Exception
  {

    final PrintWriter writer = new FilterPrintWriter(response);

    final MBeanServerConnection connection =
        (MBeanServerConnection) ctx.lookup("java:comp/env/jmx/runtime");

    final ObjectName runtimeservicebean = new ObjectName(
        "com.bea:Name=RuntimeService,Type=weblogic.management.mbeanservers.runtime.RuntimeServiceMBean");

    /*
     *
     * Attribute: ParentAttribute of Type : java.lang.String Attribute: Type
     * of Type : java.lang.String Attribute: ParentService of Type :
     * javax.management.ObjectName Attribute: ServerRuntime of Type :
     * javax.management.ObjectName Attribute: ServerName of Type :
     * java.lang.String Attribute: DomainConfiguration of Type :
     * javax.management.ObjectName Attribute: Path of Type :
     * java.lang.String Attribute: Name of Type : java.lang.String
     * Attribute: Services of Type : [Ljavax.management.ObjectName;
     * Attribute: ServerConfiguration of Type : javax.management.ObjectName
     */

    String attributeValue = "";

    final ObjectName[] onServices =
        (ObjectName[]) connection.getAttribute(runtimeservicebean, "Services");

    {
      final ObjectName itrServicesRestrictive = new ObjectName(
          "com.bea:ServerRuntime=AdminServer,Name=AdminServer_/itrjws,ApplicationRuntime=ITRDSWebServicesJWS-15.1,Type=WebAppComponentRuntime");

      final MBeanAttributeInfo[] itrServicesRestrictiveAttribs =
          connection.getMBeanInfo(itrServicesRestrictive).getAttributes();

      // Hashtable<String,String> ht1 =
      // wseert[j_WseeRt].getKeyPropertyList();
      // String contextRoot = ht1.get("ApplicationRuntime");

      for (int k_WseeRtAttribs =
          0; k_WseeRtAttribs < itrServicesRestrictiveAttribs.length; k_WseeRtAttribs++)
      {

        attributeValue = findAttributeTypeAndGetValue(
            itrServicesRestrictiveAttribs[k_WseeRtAttribs], runtimeservicebean, connection);

        final String attribName = itrServicesRestrictiveAttribs[k_WseeRtAttribs].getName();
        body += "<br/>&nbsp;Name: ";
        body += attribName;
        body += "<br/>&nbsp;Value: ";
        body += attributeValue;

        body += "<br/>";
        body += "Attribute: " + itrServicesRestrictiveAttribs[k_WseeRtAttribs].getName()
            + "   of Type : " + itrServicesRestrictiveAttribs[k_WseeRtAttribs].getType();
        System.out.println("Attribute: " + itrServicesRestrictiveAttribs[k_WseeRtAttribs].getName()
            + "   of Type : " + itrServicesRestrictiveAttribs[k_WseeRtAttribs].getType());

        if (attribName.equals("WseeV2Runtimes"))
        {
          final ObjectName[] v2runtime =
              (ObjectName[]) connection.getAttribute(itrServicesRestrictive, "WseeV2Runtimes");
          final int lengthj_WseeRt = v2runtime.length;

          for (int j_WseeRt = 0; j_WseeRt < lengthj_WseeRt; j_WseeRt++)
          {
            final MBeanAttributeInfo[] WseeRtAttribs =
                connection.getMBeanInfo(v2runtime[j_WseeRt]).getAttributes();

            final Hashtable<String, String> ht1 = v2runtime[j_WseeRt].getKeyPropertyList();
            for (int z_WseeRtAttribs = 0; z_WseeRtAttribs < WseeRtAttribs.length; z_WseeRtAttribs++)
            {

              final String attribName2 = WseeRtAttribs[z_WseeRtAttribs].getName();

              // if (attribName.equals("URI")) // pick one of the
              // components of the link, any one will do - then
              // reference the others
              // {
              System.out.println("Attribute  Inner: " + WseeRtAttribs[z_WseeRtAttribs].getName()
                  + "   of Type : " + WseeRtAttribs[z_WseeRtAttribs].getType());
              final String myVal = findAttributeTypeAndGetValue(WseeRtAttribs[z_WseeRtAttribs],
                  v2runtime[j_WseeRt], connection);
              System.out.println(myVal);
              // String url = (String)
              // connection.getAttribute(v2runtime[j_WseeRt],
              // "URI");
              // if (url.startsWith("/itrjws"))
              // {
              // String webSvcDescName = (String)
              // connection.getAttribute(v2runtime[j_WseeRt],
              // "WebserviceDescriptionName");
              //
              // String sb = "";
              // body += "<br/>";
              // sb += webSvcDescName;
              // sb += "&nbsp;<a href=\"";
              // sb += "http://"+host+":"+port.toString()+"/"+url;
              // sb += "?wsdl\"><i>(wsdl)</i></a>";
              // body += sb;
              // }
              // }
            }
          }
        }

      }

    }

    // "com.bea:ServerRuntime=AdminServer,Name=AdminServer_/itrjws,ApplicationRuntime=ITRDSWebServicesJWS-15.1,Type=WebAppComponentRuntime"

    final ObjectName serverConfiguration =
        (ObjectName) connection.getAttribute(onServices[0], "ServerConfiguration");

    // for (int yy = 0; yy < serverConfiguration.length; yy++)
    // {
    final MBeanAttributeInfo[] runtimeAttribs =
        connection.getMBeanInfo(serverConfiguration).getAttributes();

    // Hashtable<String,String> ht1 = wseert[j_WseeRt].getKeyPropertyList();
    // String contextRoot = ht1.get("ApplicationRuntime");

    for (int k_WseeRtAttribs = 0; k_WseeRtAttribs < runtimeAttribs.length; k_WseeRtAttribs++)
    {

      attributeValue = findAttributeTypeAndGetValue(runtimeAttribs[k_WseeRtAttribs],
          runtimeservicebean, connection);

      final String attribName = runtimeAttribs[k_WseeRtAttribs].getName();
      body += "<br/>&nbsp;Name: ";
      body += attribName;
      body += "<br/>&nbsp;Value: ";
      body += attributeValue;

      body += "<br/>";
      body += "Attribute: " + runtimeAttribs[k_WseeRtAttribs].getName() + "   of Type : "
          + runtimeAttribs[k_WseeRtAttribs].getType();
      System.out.println("Attribute: " + runtimeAttribs[k_WseeRtAttribs].getName() + "   of Type : "
          + runtimeAttribs[k_WseeRtAttribs].getType());

    }

    // }

    final ObjectName runtimeService =
        (ObjectName) connection.getAttribute(onServices[0], "RuntimeService");

    final ObjectName[] domainConfiguration =
        (ObjectName[]) connection.getAttribute(runtimeService, "DomainConfiguration");

    final int length2 = domainConfiguration.length;

    for (int i_apprt = 0; i_apprt < length2; i_apprt++)
    {
      final String xx = domainConfiguration[i_apprt].getCanonicalName();
      {
        final ObjectName[] wseert =
            (ObjectName[]) connection.getAttribute(domainConfiguration[i_apprt], "AppDeployments");
        final int lengthj_WseeRt = wseert.length;

        for (int j_WseeRt = 0; j_WseeRt < lengthj_WseeRt; j_WseeRt++)
        {
          final MBeanAttributeInfo[] WseeRtAttribs =
              connection.getMBeanInfo(wseert[j_WseeRt]).getAttributes();

          final Hashtable<String, String> ht1 = wseert[j_WseeRt].getKeyPropertyList();
          for (int k_WseeRtAttribs = 0; k_WseeRtAttribs < WseeRtAttribs.length; k_WseeRtAttribs++)
          {

            final String attribName = WseeRtAttribs[k_WseeRtAttribs].getName();

            // if (attribName.equals("URI")) // pick one of the
            // components of the link, any one will do - then
            // reference the others
            // {

            // String url = (String)
            // connection.getAttribute(wseert[j_WseeRt], "URI");
            // if (url.startsWith("/itrjws"))
            // {
            /// String webSvcDescName = (String)
            // connection.getAttribute(wseert[j_WseeRt],
            // "WebserviceDescriptionName");

            // String sb = "";
            // body += "<br/>";
            // sb += webSvcDescName;
            // sb += "&nbsp;<a href=\"";
            // sb += "http://"+host+":"+port.toString()+"/"+url;
            // sb += "?wsdl\"><i>(wsdl)</i></a>";
            // body += sb;
            // }
            // }
          }
        }
      }
    }

    response.setContentType("text/html; charset=utf-8");
    writer.println("<h2>And now... Some Services</h2>");
    writer.println(body);

    writer.close();
  }

  public String getServicePageHtmlBeforeList(final String title)
  {
    final String crlf = "\r\n";
    String html = "<!DOCTYPE html>" + crlf;
    html += "<html>" + crlf;
    html += "<head>" + crlf;
    html += "<title>" + title + "</title>" + crlf;
    html += "</head>" + crlf;
    html += "<body>" + crlf;

    return html;
  }

  public String getServicePageHtmlAfterList()
  {
    final String crlf = "\r\n";
    return "</body>" + crlf + "</html>" + crlf;

  }

}
