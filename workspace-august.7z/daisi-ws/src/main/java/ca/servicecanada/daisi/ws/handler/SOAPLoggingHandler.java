package ca.servicecanada.daisi.ws.handler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

public class SOAPLoggingHandler extends SpringBeanAutowiringSupport implements SOAPHandler<SOAPMessageContext> {

	public static final String DIRECTION_OUT = "OUTGOING SOAP TO ";
	public static final String DIRECTION_IN = "INCOMING SOAP FROM ";
	public static final String DECORATION_LINE = " ******** ";

	
	private Logger LOGGER = LogManager.getLogger("XML");

	public boolean handleMessage(SOAPMessageContext context) {
		logSOAP(context);
		return true;
	}

	private void logSOAP(SOAPMessageContext context) {
		boolean isOutbound = false;
		try {
			isOutbound = ((Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		String direction = (isOutbound) ? DIRECTION_OUT : DIRECTION_IN;

		//Get the soap complete message
		StringBuffer messageContent = buildXML(context);
		//Extract the transaction ID from the message
		String transactionId = getTransactionId(messageContent);
		
		String source = "Not resolved";
        // retrieve the client information
        HttpServletRequest httpServletRequest = 
            (HttpServletRequest)context.get(MessageContext.SERVLET_REQUEST);

        if (httpServletRequest != null)
        	source = (httpServletRequest.getRemoteHost());

		StringBuffer sbuf = new StringBuffer();
		sbuf.append("\n");
		sbuf.append(DECORATION_LINE);
		sbuf.append(direction);
		sbuf.append(source);
		sbuf.append(" START(ws) for TRANSACTION ID: ");
		sbuf.append(transactionId);
		sbuf.append(" ->");
		sbuf.append("\n");
		sbuf.append(messageContent);
		sbuf.append("\n");
		sbuf.append(direction);
		sbuf.append(source);
		sbuf.append(" <- (ws)END");
		sbuf.append(DECORATION_LINE);
		sbuf.append("\n");

		LOGGER.info(sbuf.toString());
	}

	//Return the business transactionID contained in the message
	private String getTransactionId(StringBuffer messageContent) {
		String startTag = "BusinessTransactionID>";
		
		int startIndex = messageContent.indexOf(startTag) + startTag.length();
		int endIndex = messageContent.indexOf(startTag, startIndex);
		
		String transactionId = "No TRANSACTION ID!";
		
		try {
			transactionId = messageContent.substring(startIndex, endIndex);
			transactionId = transactionId.substring(0,transactionId.indexOf('<'));
		} catch (Exception e) {
			LOGGER.debug("There was no transaction ID provided.");
		}
		
		return transactionId;
	}

	private StringBuffer buildXML(SOAPMessageContext context) {
		SOAPMessage message = null;
		try {
			message = context.getMessage();
		} catch (Exception e1) {
			LOGGER.error(e1.getMessage());
		}
		
		StringBuffer sbuf = new StringBuffer();
		try {
			sbuf.append("\n");
			// sbuf.append(message.toString());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			message.writeTo(baos);
			sbuf.append("\n");
			sbuf.append(baos.toString());
			sbuf.append("\n");

		} catch (Exception e) {
			sbuf.append("Exception in SOAP Handler: " + e);
		}

		return sbuf;
	}

	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
