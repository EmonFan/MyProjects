
package ca.servicecanada.daisi.ws.endpoint.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for MessageManifest-Transactional-CT complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageManifest-Transactional-CT">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MessageDateTime" type="{http://interoperability.gc.ca/core/1.0}DateTimeST"/>
 *         &lt;element name="MessageID" type="{http://interoperability.gc.ca/core/1.0}NotificationIDCT"/>
 *         &lt;element name="TechnicalTransactionDateTime" type="{http://interoperability.gc.ca/core/1.0}DateTimeST"/>
 *         &lt;element name="TechnicalTransactionID" type="{http://interoperability.gc.ca/core/1.0}NotificationIDCT"/>
 *         &lt;element name="BusinessTransactionDateTime" type="{http://interoperability.gc.ca/core/1.0}DateTimeST"/>
 *         &lt;element name="BusinessTransactionID" type="{http://interoperability.gc.ca/core/1.0}NotificationIDCT"/>
 *         &lt;element name="SystemID" type="{http://interoperability.gc.ca/core/1.0}SystemIDCT"/>
 *         &lt;element name="TestIndicator" type="{http://interoperability.gc.ca/core/1.0}IndicatorST" minOccurs="0"/>
 *         &lt;element name="LanguageCode" type="{http://interoperability.gc.ca/core/1.0}LanguageCodeCT" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageManifest-Transactional-CT", namespace = "http://interoperability.gc.ca/core/1.0", propOrder = {
    "messageDateTime",
    "messageID",
    "technicalTransactionDateTime",
    "technicalTransactionID",
    "businessTransactionDateTime",
    "businessTransactionID",
    "systemID",
    "testIndicator",
    "languageCode"
})
public class MessageManifestTransactionalCT {

    @XmlElement(name = "MessageDateTime", required = true)
    protected XMLGregorianCalendar messageDateTime;
    @XmlElement(name = "MessageID", required = true)
    protected NotificationIDCT messageID;
    @XmlElement(name = "TechnicalTransactionDateTime", required = true)
    protected XMLGregorianCalendar technicalTransactionDateTime;
    @XmlElement(name = "TechnicalTransactionID", required = true)
    protected NotificationIDCT technicalTransactionID;
    @XmlElement(name = "BusinessTransactionDateTime", required = true)
    protected XMLGregorianCalendar businessTransactionDateTime;
    @XmlElement(name = "BusinessTransactionID", required = true)
    protected NotificationIDCT businessTransactionID;
    @XmlElement(name = "SystemID", required = true)
    protected SystemIDCT systemID;
    @XmlElement(name = "TestIndicator", defaultValue = "false")
    protected Boolean testIndicator;
    @XmlElement(name = "LanguageCode")
    protected LanguageCodeCT languageCode;

    /**
     * Gets the value of the messageDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMessageDateTime() {
        return messageDateTime;
    }

    /**
     * Sets the value of the messageDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMessageDateTime(XMLGregorianCalendar value) {
        this.messageDateTime = value;
    }

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link NotificationIDCT }
     *     
     */
    public NotificationIDCT getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NotificationIDCT }
     *     
     */
    public void setMessageID(NotificationIDCT value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the technicalTransactionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTechnicalTransactionDateTime() {
        return technicalTransactionDateTime;
    }

    /**
     * Sets the value of the technicalTransactionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTechnicalTransactionDateTime(XMLGregorianCalendar value) {
        this.technicalTransactionDateTime = value;
    }

    /**
     * Gets the value of the technicalTransactionID property.
     * 
     * @return
     *     possible object is
     *     {@link NotificationIDCT }
     *     
     */
    public NotificationIDCT getTechnicalTransactionID() {
        return technicalTransactionID;
    }

    /**
     * Sets the value of the technicalTransactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NotificationIDCT }
     *     
     */
    public void setTechnicalTransactionID(NotificationIDCT value) {
        this.technicalTransactionID = value;
    }

    /**
     * Gets the value of the businessTransactionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getBusinessTransactionDateTime() {
        return businessTransactionDateTime;
    }

    /**
     * Sets the value of the businessTransactionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setBusinessTransactionDateTime(XMLGregorianCalendar value) {
        this.businessTransactionDateTime = value;
    }

    /**
     * Gets the value of the businessTransactionID property.
     * 
     * @return
     *     possible object is
     *     {@link NotificationIDCT }
     *     
     */
    public NotificationIDCT getBusinessTransactionID() {
        return businessTransactionID;
    }

    /**
     * Sets the value of the businessTransactionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NotificationIDCT }
     *     
     */
    public void setBusinessTransactionID(NotificationIDCT value) {
        this.businessTransactionID = value;
    }

    /**
     * Gets the value of the systemID property.
     * 
     * @return
     *     possible object is
     *     {@link SystemIDCT }
     *     
     */
    public SystemIDCT getSystemID() {
        return systemID;
    }

    /**
     * Sets the value of the systemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link SystemIDCT }
     *     
     */
    public void setSystemID(SystemIDCT value) {
        this.systemID = value;
    }

    /**
     * Gets the value of the testIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isTestIndicator() {
        return testIndicator;
    }

    /**
     * Sets the value of the testIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setTestIndicator(Boolean value) {
        this.testIndicator = value;
    }

    /**
     * Gets the value of the languageCode property.
     * 
     * @return
     *     possible object is
     *     {@link LanguageCodeCT }
     *     
     */
    public LanguageCodeCT getLanguageCode() {
        return languageCode;
    }

    /**
     * Sets the value of the languageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link LanguageCodeCT }
     *     
     */
    public void setLanguageCode(LanguageCodeCT value) {
        this.languageCode = value;
    }

}
