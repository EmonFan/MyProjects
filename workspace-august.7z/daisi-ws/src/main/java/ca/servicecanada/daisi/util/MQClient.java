package ca.servicecanada.daisi.util;

import java.util.Hashtable;
import java.util.concurrent.TimeUnit;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.annotation.Resource;
import org.apache.camel.CamelContext;
import org.apache.camel.CamelContextAware;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;

import ca.servicecanada.daisi.ei.model.DaisiMessageID;

@Import( org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class )
public class MQClient implements CamelContextAware {

	private Logger LOGGER = LogManager.getLogger(getClass());
	private static boolean kickStarted = false;

	private static CamelContext CamelContext;

	@Value("${message.queue.timeout}")
	private String timerValue;
	
	@Resource
	private DaisiMessageID daisiMessageID;
	
	private String queueName;

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public MQClient(String queueName) {
		this.queueName = queueName;
	}

	public MQClient() {
		// this(QUEUE);
	}

	public void send(String message, String replyTo, String relatesTo) {
		ProducerTemplate producerTemplate = getCamelContext().createProducerTemplate();
        Exchange exchange = new DefaultExchange(getCamelContext());

		Message camelMessage = exchange.getIn();
		camelMessage.setBody(message);
		camelMessage.setHeader("ReplyTo", replyTo);
		camelMessage.setHeader("RelatesTo", relatesTo);
		exchange.setIn(camelMessage);

		producerTemplate.send(queueName, exchange);
	}

	public String sendJson(String message) {
		String msgID = "";

		ProducerTemplate producerTemplate = getCamelContext().createProducerTemplate();
		Exchange exchange = new DefaultExchange(getCamelContext());
		
		Message camelMessage = exchange.getIn();
		camelMessage.setBody(message);
		exchange.setIn(camelMessage);

		//Yet another activeMQ/memory queue strange behavior
		//The very first time we hit the queue, all processing goes on as expected
		//except that the message ID processor is not called in sequence.
		//Let's send a bogus message to kickstart activeMQ. Only do this once
		//Everything runs normally after this
		if (!kickStarted) { //Wake up the queue!

			try {
				NotifyBuilder notify = new NotifyBuilder(getCamelContext()).whenDone(1).create();
				 
				//Send to the queue.
				producerTemplate.sendBody("activemq:kickStartActiveMQ-Queue", null);
				notify.matches(3000, TimeUnit.MILLISECONDS);  //Timeout after 3 seconds.
			} catch (CamelExecutionException e) {
				//Ignore, keep going
			} catch (NumberFormatException e) {
				//Ignore, keep going
			}
			
			kickStarted = true;
		}
		
		NotifyBuilder notify = new NotifyBuilder(getCamelContext()).whenDone(1).create();
		 
		//Send to the queue.
		producerTemplate.send(queueName, exchange);

		// now we want to wait until the message has been routed and completed
		// or we reach the timeout value
		//I don't fully understand what is going on here
		//But less than 5 (local, longer on the server) milliseconds causes the ID returned to be the previous one.
		//The messageID processor is not called until after the timer if set too short
		//Default server based delay is set to 50msec. That works out to 20 requests per second, 1200 per minute or 72000 per hour
		//If there's a performance issue, tweak the delay in the properties file
		notify.matches(Integer.parseInt(timerValue), TimeUnit.MILLISECONDS);  //Timeout after x milliseconds.

		//The message ID should have been set by the processor defined in the route
		return daisiMessageID.getMessageID();
	}
	
	@Override
	public void setCamelContext(CamelContext camelContext) {
		MQClient.CamelContext = camelContext;
	}

	@Override
	public CamelContext getCamelContext() {
		return CamelContext;
	}

}