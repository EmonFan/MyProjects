package ca.servicecanada.daisi.ws.handler;

import ca.servicecanada.daisi.ws.handler.support.WSSecurityFault;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFaultThreadLocal;
import ca.servicecanada.daisi.ws.validation.PlainTextUserIdPasswordValidator;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.ProtocolException;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

@Import(ca.servicecanada.daisi.ws.validation.PlainTextUserIdPasswordValidator.class)
public class ServerWSSecuritySOAPHandler extends SpringBeanAutowiringSupport
    implements SOAPHandler<SOAPMessageContext>
{
  private final Logger LOGGER = LogManager.getLogger(getClass());

  @Autowired
  private PlainTextUserIdPasswordValidator validator;

  private static final String WSSE_NS =
      "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

  private static final String WSU_NS =
      "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

  private static final QName WSSE_QNAME =
      new QName(ServerWSSecuritySOAPHandler.WSSE_NS, "Security");

  private static final QName UNTOKEN_QNAME =
      new QName(ServerWSSecuritySOAPHandler.WSSE_NS, "UsernameToken");

  private static final QName USERNAME_QNAME =
      new QName(ServerWSSecuritySOAPHandler.WSSE_NS, "Username");

  private static final QName DIGEST_QNAME =
      new QName(ServerWSSecuritySOAPHandler.WSSE_NS, "Password");

  private static HashSet<QName> supportedHeaders;

  static
  {
    ServerWSSecuritySOAPHandler.supportedHeaders = new HashSet<>();
    ServerWSSecuritySOAPHandler.supportedHeaders.add(ServerWSSecuritySOAPHandler.WSSE_QNAME);
  }

  private final String USERNAME = "USERNAME";

  private final String PASSWORD = "PASSWORD";

  @Override
  public boolean handleMessage(final SOAPMessageContext context)
  {
    Map<String, String> credentials = null;
    final boolean outboundProperty =
        (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
    //--[ We only care when it is a request/inbound
    if (!outboundProperty)
    {
      try
      {
        credentials = extractData(context);
        final String username = credentials.get(USERNAME);
        final String password = credentials.get(PASSWORD);
        LOGGER.debug("In WS-Security ..checking provided username=" + username);
        if (validate(username, password))
        {
          LOGGER.info("WS-security passed ..");
          //Reset any previous security faults
          WSSecurityFaultThreadLocal.unset();
          return true;

        }
        else
        {
          final String faultMessage = "Invalid username / password ..";
          LOGGER.error(faultMessage);
          final WSSecurityFault fault = new WSSecurityFault();
          fault.setFault(faultMessage);
          WSSecurityFaultThreadLocal.set(fault);

          //Returns true so that the handler chain continues
          //Webservices should individually verify WSSecurityFaultThreadLocal
          //for a security fault and act accordingly
          return true;
        }

      }
      catch (final Exception e)
      {
        LOGGER.error(e.getMessage());
      }
    }
    return true;

  }

  boolean validate(final String username, final String password)
  {
    if (validator == null)
    {
      LOGGER.error("validator=null  , Spring config? ");
    }
    return validator.validate(username, password);
  }

  public Map<String, String> extractData(final SOAPMessageContext context)
  {
    boolean outboundProperty = false;
    try
    {
      outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
    }
    catch (final Exception e)
    {
      LOGGER.error(e.getMessage());
    }

    final Map<String, String> credentiasls = new HashMap<>();

    SOAPEnvelope envelope;
    SOAPHeader header;
    SOAPElement tokenElem;
    SOAPElement passwordElem;

    String username;
    String password;

    // --[ We only care when it is a request/inbound
    if (!outboundProperty)
    {
      try
      {
        envelope = context.getMessage().getSOAPPart().getEnvelope();

        header = envelope.getHeader();
        if (header == null)
        {
          throw new SOAPException("No SOAP header present in envelope.");
        }

        // ---[ Get the needed pieces from the header
        tokenElem =
            ServerWSSecuritySOAPHandler.findChildElement(
                ServerWSSecuritySOAPHandler.findChildElement(header,
                    ServerWSSecuritySOAPHandler.WSSE_QNAME),
                ServerWSSecuritySOAPHandler.UNTOKEN_QNAME);

        username = ServerWSSecuritySOAPHandler
            .findChildElement(tokenElem, ServerWSSecuritySOAPHandler.USERNAME_QNAME)
            .getTextContent();
        if (username.equals(""))
        {
          throw new SOAPException(
              "Element " + ServerWSSecuritySOAPHandler.USERNAME_QNAME + " must not be empty.");
        }
        passwordElem = ServerWSSecuritySOAPHandler.findChildElement(tokenElem,
            ServerWSSecuritySOAPHandler.DIGEST_QNAME);
        password = passwordElem.getTextContent();
        if (password.equals(""))
        {
          throw new SOAPException(
              "Element " + ServerWSSecuritySOAPHandler.DIGEST_QNAME + " must not be empty.");
        }

        credentiasls.put(PASSWORD, password);
        credentiasls.put(USERNAME, username);
      }
      catch (final Throwable ex)
      {
        final String msg = "An error occured processing request authentication. Aborting handler. ["
            + ex.getMessage() + "]";

        LOGGER.error(ex.getMessage());
        throw new ProtocolException(msg, ex);
      }
    }
    else
    {
      LOGGER.debug("In WS-Security, outbound , ignoring ..");
    }

    return credentiasls;
  }

  @Override
  public boolean handleFault(final SOAPMessageContext context)
  {
    return true;
  }

  @Override
  public void close(final MessageContext context)
  {
  }

  @Override
  public Set<QName> getHeaders()
  {
    return ServerWSSecuritySOAPHandler.supportedHeaders;
  }

  /**
   * Returns the child element with the speicied qualified name, throws an exception if not found.
   */
  private static SOAPElement findChildElement(final SOAPElement parent, final QName childName)
      throws SOAPException
  {
    final Iterator<?> iter = parent.getChildElements(childName); // (Name)
    // childName
    if (!iter.hasNext())
    {
      throw new SOAPException("SOAP element [" + childName + "] not found in SOAP header.");
    }
    return (SOAPElement) iter.next();
  }

}
