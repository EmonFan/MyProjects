package ca.servicecanada.daisi.dsb;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.PortInfo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import com.sun.xml.ws.client.ClientTransportException;

import ca.servicecanada.daisi.ws.endpoint.generated.*;
import ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler;
import ca.servicecanada.daisi.ws.handler.WSSecuritySOAPHandler;

@Import(org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class)
@Component
public class OutboundCallbackWsClientWS implements InitializingBean {

	protected Logger LOGGER = LogManager.getLogger(getClass());

	@Value("${dsb.wsdl}")
	protected String WSDL;

	protected URL SOASERVICE_WSDL_LOCATION;

	@Value("${dsb.user}")
	protected String username;// = "ITRDS_UAT_Adm";

	@Value("${dsb.password}")
	protected String password;// = "w3w3r3CS";

	protected HandlerResolver handlerResolver;

	private String NS = "http://interoperability.gc.ca/service/citizenprofile/1.0";
	private String SERVICE_NAME = "ClientProfileAsyncCallbackServices";

	private QName qName = new QName(NS, SERVICE_NAME);

	URL wsdlUrl = SOASERVICE_WSDL_LOCATION;

	ClientProfileAsyncCallbackServices callbackService;
	private ExecuteCallbackPtt port;

	public OutboundCallbackWsClientWS() {

		URL url = null;
		try {
			URL baseUrl;
			baseUrl = OutboundCallbackWsClientWS.class.getResource(".");
			url = new URL(baseUrl, WSDL);

			System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
			System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
			System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
			System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");

		} catch (MalformedURLException e) {
			LOGGER.warn("Failed to create URL for the wsdl Location: " + WSDL);
			LOGGER.error(e.getMessage());
		}
		SOASERVICE_WSDL_LOCATION = url;

	}

	// DAISI outgoing - CPP pull from CRA
	public int callbackRetrieveBankAccountBySINAsyncResponse(RetrieveBankAccountBySINAsyncResponseType response,
			String replyTo) {

		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		try {
			setAddressing(replyTo);
			port.retrieveBankAccountBySINResponse(response);

			responseContext = ((BindingProvider) port).getResponseContext();
		} catch (ClientTransportException e) {
			responseContext = ((BindingProvider) port).getResponseContext();
			handleClientTransportException(e, responseContext);
		}

		int responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
		LOGGER.debug("sent!");
		return responseCode;

	}

	// DAISI outgoing - CPP pull from CRA
	public int callbackSetBankAccountBySINAsyncResponse(SetBankAccountBySINAsyncResponseType response, String replyTo) {
		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		try {
			setAddressing(replyTo);

			port.setBankAccountBySINResponse(response);

			responseContext = ((BindingProvider) port).getResponseContext();
		} catch (ClientTransportException e) {
			responseContext = ((BindingProvider) port).getResponseContext();
			handleClientTransportException(e, responseContext);
		}

		int responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
		LOGGER.debug("sent!");
		return responseCode;
	}

	void setAddressing(String endpointURL) {
		BindingProvider bp = (BindingProvider) port;
		bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointURL);

	}

	void initEndpoints() {
		try {
			callbackService = new ClientProfileAsyncCallbackServices(wsdlUrl, qName);
		} catch (javax.xml.ws.WebServiceException e) {
			throw new RuntimeException(e);
		}
		callbackService.setHandlerResolver(handlerResolver);
		port = callbackService.getExecuteCallbackPtt();

	}

	protected void initHandlerResolver() {
		handlerResolver = new HandlerResolver() {
			@SuppressWarnings("rawtypes")
			@Override
			public List<Handler> getHandlerChain(final PortInfo portInfo) {
				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();
//				handlerChain.add(new SOAPLoggingHandler());
				handlerChain.add(new WSSecuritySOAPHandler(username, password, "en-US;q=1.0, en;q=0.8"));
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}
		};
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		initHandlerResolver();
		initEndpoints();
		

	}

	protected void handleClientTransportException(ClientTransportException e, Map<String, Object> responseContext) {

		LOGGER.error(e.getMessage());
		// String key = e.getKey();
		//// [0] Integer (id=34063)
		//// [1] "Bad Request" (id=34064)
		int responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);

		String endpoint = (String) responseContext.get("javax.xml.ws.service.endpoint.address");
		String operation = ((QName) responseContext.get("javax.xml.ws.wsdl.operation")).getLocalPart();

		StringBuilder b = new StringBuilder();
		b.append("Error HTTP ");
		b.append(responseCode);
		b.append(" while sending a SOAP request to endpoint ");
		b.append(endpoint);
		b.append(", operation ");
		b.append(operation);
		String tmp = b.toString();

		LOGGER.error(tmp);

	}
}
