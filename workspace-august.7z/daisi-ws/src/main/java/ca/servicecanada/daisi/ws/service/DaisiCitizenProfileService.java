package ca.servicecanada.daisi.ws.service;

import javax.annotation.Resource;
import javax.jws.WebParam;
import javax.xml.ws.WebServiceContext;

//
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINRequestType;

public class DaisiCitizenProfileService {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private WebServiceContext wsContext;
	// private static final AddressingVersion WS_ADDR_VER =
	// AddressingVersion.W3C;

	// @WebMethod
	// @Oneway
	public void retrieveBankAccountBySINFromCPP(
			@WebParam(name = "RetrieveBankAccountBySINRequest", targetNamespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", partName = "RetrieveBankAccountBySINResponse") RetrieveBankAccountBySINRequestType request) {
		LOGGER.debug("in DaisiCitizenProfileService.retrieveBankAccountBySINFromCPP");
		handleCallback();
	}

	void handleCallback() {
		// HeaderList headerList =
		// (HeaderList)wsContext.getMessageContext().get(JAXWSProperties.INBOUND_HEADER_LIST_PROPERTY);
		// Header realtesToheader = headerList.get(WS_ADDR_VER.relatesToTag,
		// true);
		// Header actionHeader = headerList.get(WS_ADDR_VER.actionTag, true);
		// Header replyToHeader= headerList.get(WS_ADDR_VER.replyToTag, true);
		// LOGGER.debug("replyToHeader="+replyToHeader.getStringContent());
		//
		// String messageId = headerList.getMessageID(AddressingVersion.W3C,
		// SOAPVersion.SOAP_11);
		// LOGGER.debug("messageId="+messageId );

	}
}
