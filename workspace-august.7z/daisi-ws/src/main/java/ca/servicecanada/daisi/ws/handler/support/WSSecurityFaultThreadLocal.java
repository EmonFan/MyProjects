package ca.servicecanada.daisi.ws.handler.support;

public class WSSecurityFaultThreadLocal {

	public static final ThreadLocal threadLocal = new ThreadLocal();

	public static void set(WSSecurityFault error) {
		threadLocal.set(error);
	}

	public static void unset() {
		threadLocal.remove();
	}

	public static WSSecurityFault get() {
		return (WSSecurityFault) threadLocal.get();
	}

}
