package ca.servicecanada.daisi.ws.service.request;

public class SetBankAccountRequest extends ClientData
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  protected String transit;

  protected String accountNumber;

  protected String institution;

  public String getTransit()
  {
    return transit;
  }

  public void setTransit(final String transit)
  {
    this.transit = transit;
  }

  public String getAccountNumber()
  {
    return accountNumber;
  }

  public void setAccountNumber(final String accountNumber)
  {
    this.accountNumber = accountNumber;
  }

  public String getInstitution()
  {
    return institution;
  }

  public void setInstitution(final String institution)
  {
    this.institution = institution;
  }

}
