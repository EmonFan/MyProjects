package ca.servicecanada.daisi.ws.handler;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;
import org.w3c.dom.DOMException;
import org.w3c.dom.NodeList;

import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyTo;
import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyToThreadLocal;

public class WSAddressingSOAPHandler extends SpringBeanAutowiringSupport implements SOAPHandler<SOAPMessageContext> {

	private Logger LOGGER = LogManager.getLogger(getClass());

	public static final String MESSAGE_ID = "MessageID";
	public static final String RELATES_TO = "wsa:RelatesTo";
	public static final String REPLY_TO = "wsa:ReplyTo";
	public static final String ADDRESS = "wsa:Address";

	protected String getRelatesTo(SOAPHeader header) {
		NodeList nodeListMessageId = header.getElementsByTagName(RELATES_TO);
		return nodeListMessageId.item(0).getTextContent();
	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {

		SOAPHeader header;

		String replyTo = null;
		try {
			SOAPEnvelope envelope = context.getMessage().getSOAPPart().getEnvelope();
			header = envelope.getHeader();

			NodeList nodeListAddress = header.getElementsByTagName(ADDRESS);
			try {
				replyTo = nodeListAddress.item(0).getTextContent();
				LOGGER.info("ReplyTo = " + replyTo);
			} catch (Exception e) {
				LOGGER.info("No ReplyTo supplied");
			}

			NodeList nodeListRelatesTo = header.getElementsByTagName(RELATES_TO);
			String relatesTo = null;
			try {
				relatesTo = nodeListRelatesTo.item(0).getTextContent();
				LOGGER.info("relatesTo = " + relatesTo);
			} catch (Exception e) {
				LOGGER.info("No RelatesTo supplied");
			}

			NodeList nodeListMessageId = header.getElementsByTagName(ADDRESS);
			String messageID = null;
			try {
				messageID = nodeListMessageId.item(0).getTextContent();
				LOGGER.info("messageID = " + messageID);
			} catch (Exception e) {
				LOGGER.info("No messageID supplied");
			}

			WsAddressingReplyTo wsAddressingReplyTo = new WsAddressingReplyTo();
			wsAddressingReplyTo.setReplyTo(replyTo);
			wsAddressingReplyTo.setMessageID(messageID);
			wsAddressingReplyTo.setRelatesTo(relatesTo);

			WsAddressingReplyToThreadLocal.set(wsAddressingReplyTo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		LOGGER.info("ReplyTo = " + replyTo);

		return true;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
