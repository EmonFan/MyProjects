/**
 * This web service is used for ITRDS to send Push/Pull DD request to DAISI
 */
package ca.servicecanada.daisi.ws.service;

import ca.servicecanada.daisi.ws.endpoint.generated.ObjectFactory;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFault;
import ca.servicecanada.daisi.ws.handler.support.WSSecurityFaultThreadLocal;
import ca.servicecanada.daisi.ws.service.request.ClientData;
import ca.servicecanada.daisi.ws.service.request.SetBankAccountRequest;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.jws.HandlerChain;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

@Component
@Import({ org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class,
    ca.servicecanada.daisi.ws.handler.ServerWSSecuritySOAPHandler.class,
    ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler.class })

@WebService(name = "BankAccountSync", targetNamespace = "http://servicecanada.ca/daisi/ws/service")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
@HandlerChain(file = "handler-chain-sync.xml")
@XmlSeeAlso({ ObjectFactory.class })
public class BankAccountSyncServices extends SpringBeanAutowiringSupport
{

  @Autowired
  private DaisiQueueAdapter adapter;

  private final Logger LOGGER = LogManager.getLogger(getClass());

  /**
   * For ITRDS put Pull DD from CRA request in DAISI Return an JMS id
   */
  @WebMethod(operationName = "RetrieveBankAccount", action = "RetrieveBankAccount")
  public String retrieveBankAccount(
      @WebParam(name = "RetrieveBankAccountRequest") final ClientData retrieveBankAccountBySINRequest)
  {

    LOGGER.debug("retrieveBankAccount from CRA\n");
    String businessTransactionID = "";

    if (BankAccountSyncServices.hasWSSecurityFaults())
    {
      LOGGER.debug("BankAccountSyncServices/RetrieveBankAccount: error in username/password");
      return "403";
    }
    else
    {
      final JsonObject jsonObj = new JsonObject();
      jsonObj.add("sin",
          new JsonPrimitive(retrieveBankAccountBySINRequest.getSocialInsuranceNumber()));
      jsonObj.add("birthDate", new JsonPrimitive(retrieveBankAccountBySINRequest.getBirthDate()));
      jsonObj.add("surname", new JsonPrimitive(retrieveBankAccountBySINRequest.getSurname()));
      jsonObj.add("channelTypeID", new JsonPrimitive(retrieveBankAccountBySINRequest.getChannel()));
      jsonObj.add("consentCode",
          new JsonPrimitive(retrieveBankAccountBySINRequest.getSharingAgreementID()));

      try
      {
        businessTransactionID =
            adapter.onMessageRetrieveBankAccountBySINRequestDataAreaType(jsonObj.toString());
      }
      catch (final Exception e)
      {
        e.printStackTrace();
        LOGGER.error(
            "Error while parsing incoming RetrieveBankAccountBySINRequest businessTransactionID="
                + businessTransactionID);
      }
    }

    LOGGER.debug("-- BusinessTransactionID -- " + businessTransactionID);

    return businessTransactionID;

  }

  @WebMethod(operationName = "SetBankAccount", action = "SetBankAccount")
  public String setBankAccount(
      @WebParam(name = "SetBankAccountRequest", partName = "SetBankAccount") final SetBankAccountRequest SetBankAccountBySINRequest)
  {

    LOGGER.debug("SetBankAccount In CRA \n");

    String businessTransactionID = "";

    if (BankAccountSyncServices.hasWSSecurityFaults())
    {
      LOGGER.debug("BankAccountSyncServices/SetBankAccount: error in username/password");
      return "403";
    }
    else
    {
      final JsonObject jsonObj = new JsonObject();

      jsonObj.add("sin", new JsonPrimitive(SetBankAccountBySINRequest.getSocialInsuranceNumber()));
      jsonObj.add("surname", new JsonPrimitive(SetBankAccountBySINRequest.getSurname()));
      jsonObj.add("birthDate", new JsonPrimitive(SetBankAccountBySINRequest.getBirthDate()));
      jsonObj.add("channelTypeID", new JsonPrimitive(SetBankAccountBySINRequest.getChannel()));
      jsonObj.add("consentCode",
          new JsonPrimitive(SetBankAccountBySINRequest.getSharingAgreementID()));

      jsonObj.add("accountNumber",
          new JsonPrimitive(SetBankAccountBySINRequest.getAccountNumber()));
      jsonObj.add("institution", new JsonPrimitive(SetBankAccountBySINRequest.getInstitution()));
      jsonObj.add("transitNumber", new JsonPrimitive(SetBankAccountBySINRequest.getTransit()));

      try
      {
        businessTransactionID =
            adapter.onMessageSetBankAccountBySINRequestDataAreaType(jsonObj.toString());
      }
      catch (final Exception e)
      {
        e.printStackTrace();
        LOGGER
            .error("Error while parsing incoming SetBankAccountBySINRequest businessTransactionID="
                + businessTransactionID);
      }
    }
    LOGGER.debug("-- BusinessTransactionID -- " + businessTransactionID);
    return businessTransactionID;
  }

  private static boolean hasWSSecurityFaults()
  {
    final WSSecurityFault fault = WSSecurityFaultThreadLocal.get();
    if (StringUtils.isEmpty(fault))
    {
      return false;
    }
    else
    {
      return true;
    }
  }

}
