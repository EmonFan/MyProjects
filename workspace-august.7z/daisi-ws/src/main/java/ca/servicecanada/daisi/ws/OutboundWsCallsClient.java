package ca.servicecanada.daisi.ws;

//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.GregorianCalendar;
//import java.util.List;
//import java.util.Random;
//
//import javax.xml.datatype.DatatypeConfigurationException;
//import javax.xml.datatype.DatatypeFactory;
//import javax.xml.datatype.XMLGregorianCalendar;
//import javax.xml.namespace.QName;
//import javax.xml.ws.handler.Handler;
//import javax.xml.ws.handler.HandlerResolver;
//import javax.xml.ws.handler.PortInfo;
//import javax.xml.ws.soap.AddressingFeature;
//
//import org.apache.log4j.Logger;
//
////import com.sun.xml.ws.api.addressing.*;
////import com.sun.xml.ws.api.addressing.AddressingVersion;
////import com.sun.xml.ws.api.addressing.OneWayFeature;
////import com.sun.xml.ws.api.addressing.WSEndpointReference;
//import com.sun.xml.ws.api.addressing.AddressingVersion;
//import com.sun.xml.ws.api.addressing.OneWayFeature;
//import com.sun.xml.ws.api.addressing.WSEndpointReference;
//
//
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.ClientProfileAsyncServices;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.ExecutePtt;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.MessageManifestTransactionalCT;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.NotificationIDCT;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.RetrieveBankAccountBySINRequestDataAreaType;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.RetrieveBankAccountBySINRequestType;
//import ca.servicecanada.daisi.ws.endpoint.dsb.generated.SystemIDCT;
//import ca.servicecanada.daisi.ws.handler.SOAPLoggingHandler;
//import ca.servicecanada.daisi.ws.handler.ClientWSSecuritySOAPHandler;

//WS Client to call DSB WS Async, includes ReplyTo SOAP Header
public class OutboundWsCallsClient {
//	static URL SOASERVICE_WSDL_LOCATION;
//	static private Logger LOGGER2 = Logger.getLogger(OutboundWsCallsClient.class);
//	static {
//		URL url = null;
//		try {
//			URL baseUrl;
//			baseUrl = ca.servicecanada.daisi.ws.OutboundWsCallsClient.class.getResource(".");
//			url = new URL(baseUrl,
//					"file:/C:/projects/DAISI/DAISI-WS/daisi-ws/src/main/resources/wsdl/ClientProfile_Async.wsdl");
//		} catch (MalformedURLException e) {
//			LOGGER2.warn(
//					"Failed to create URL for the wsdl Location: 'file:/C:/projects/DAISI/DAISI-WS/daisi-ws/src/main/resources/wsdl/ClientProfile_Async.wsdl', retrying as a local file");
//			LOGGER2.error(e.getMessage());
//		}
//
//		SOASERVICE_WSDL_LOCATION = url;
//
//	}
//
//	private String replyToLocation = "http://10.24.233.62:7001/daisi-ws-poc/RetrieveBankAccountBySINCallbackServiceService";
//	private Logger LOGGER = Logger.getLogger(getClass());
//
//	private String NS = "http://interoperability.gc.ca/service/citizenprofile/1.0";
//	private String SERVICE_NAME = "ClientProfileAsyncServices";
//
//	private QName qName = new QName(NS, SERVICE_NAME);
//
//	private String user = "ITRDS_UAT_Adm";
//	private String password = "w3w3r3CS";
//
//	public void retrieveBankAccountBySINFromDSB(String SIN) {
//		URL wsdlUrl = SOASERVICE_WSDL_LOCATION;
//
//		ClientProfileAsyncServices service = new ClientProfileAsyncServices(wsdlUrl, qName);
//		service.setHandlerResolver(new HandlerResolver() {
//			@SuppressWarnings("rawtypes")
//			@Override
//			public List<Handler> getHandlerChain(final PortInfo portInfo) {
//				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();
//				handlerChain.add(new SOAPLoggingHandler());
//				handlerChain.add(new ClientWSSecuritySOAPHandler(user, password, "en-US;q=1.0, en;q=0.8"));
//				handlerChain.add(new SOAPLoggingHandler());
//				return handlerChain;
//			}
//		});
//
//		AddressingFeature addressingfeature = new AddressingFeature();
//		WSEndpointReference replyTo = new WSEndpointReference(replyToLocation, AddressingVersion.W3C);
//		OneWayFeature onewayfeature = new OneWayFeature(true, replyTo);
//		ExecutePtt port = service.getExecuteAsyncPt(addressingfeature, onewayfeature);
//
//
//		RetrieveBankAccountBySINRequestType retrieveBankAccountBySINRequest = buildRequest();
//
//		LOGGER.debug("sending SOAP");
//		port.retrieveBankAccountBySIN(retrieveBankAccountBySINRequest);
//		LOGGER.debug("sent!");
//
//		try {
//			Thread.sleep(50000L);
//		} catch (InterruptedException ex) {
//			ex.printStackTrace();
//		}
//	}
//
//	RetrieveBankAccountBySINRequestType buildRequest() {
//		RetrieveBankAccountBySINRequestType request = new RetrieveBankAccountBySINRequestType();
//
//		//MessageManifestTransactionalCT mf = buildManifet();
//		RetrieveBankAccountBySINRequestDataAreaType dataArea = buildDataArea();
//
//		request.setDataArea(dataArea);
//		//request.setMessageManifest(mf);
//
//		return request;
//	}
//
////	MessageManifestTransactionalCT buildManifet() {
////
////		GregorianCalendar c = new GregorianCalendar();
////		c.setTime(new Date());
////		XMLGregorianCalendar date = null;
////		;
////		try {
////			date = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
////		} catch (DatatypeConfigurationException e) {
////		}
////
////		MessageManifestTransactionalCT mf = new MessageManifestTransactionalCT();
////
////		NotificationIDCT businessTransactionID = new NotificationIDCT();
////		businessTransactionID.setValue("" + (new Random()).nextInt(10000));
////		mf.setBusinessTransactionID(businessTransactionID);
////
////		mf.setBusinessTransactionDateTime(date);
////
////		NotificationIDCT msgID = new NotificationIDCT();
////		msgID.setValue("" + (new Random()).nextInt(10000));
////		mf.setMessageID(msgID);
////
////		mf.setMessageDateTime(date);
////
////		SystemIDCT system = new SystemIDCT();
////		system.setValue("CPP");
////		mf.setSystemID(system);
////
////		NotificationIDCT trxID = new NotificationIDCT();
////		trxID.setValue("" + (new Random()).nextInt(10000));
////		mf.setTechnicalTransactionID(trxID);
////
////		mf.setTechnicalTransactionDateTime(date);
////
////		mf.setTestIndicator(true);
////		return mf;
////	}
//
//	RetrieveBankAccountBySINRequestDataAreaType buildDataArea() {
//		RetrieveBankAccountBySINRequestDataAreaType d = new RetrieveBankAccountBySINRequestDataAreaType();
//		d.setBirthDate("1971-12-12");
//		d.setChannel("phone");
//		d.setProgram("CPP");
//		d.setSocialInsuranceNumber("007007007");
//		d.setSurname("Bond");
//
//		return d;
//	}

}