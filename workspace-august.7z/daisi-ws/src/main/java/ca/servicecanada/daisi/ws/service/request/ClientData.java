package ca.servicecanada.daisi.ws.service.request;

public class ClientData implements java.io.Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  protected String socialInsuranceNumber;

  protected String birthDate;

  protected String surname;

  protected String channel;

  protected String program;

  protected String sharingAgreementID;

  public String getSocialInsuranceNumber()
  {
    return socialInsuranceNumber;
  }

  public void setSocialInsuranceNumber(final String socialInsuranceNumber)
  {
    this.socialInsuranceNumber = socialInsuranceNumber;
  }

  public String getBirthDate()
  {
    return birthDate;
  }

  public void setBirthDate(final String birthDate)
  {
    this.birthDate = birthDate;
  }

  public String getSurname()
  {
    return surname;
  }

  public void setSurname(final String surname)
  {
    this.surname = surname;
  }

  public String getChannel()
  {
    return channel;
  }

  public void setChannel(final String channel)
  {
    this.channel = channel;
  }

  public String getProgram()
  {
    return program;
  }

  public void setProgram(final String program)
  {
    this.program = program;
  }

  public String getSharingAgreementID()
  {
    return sharingAgreementID;
  }

  public void setSharingAgreementID(final String sharingAgreementID)
  {
    this.sharingAgreementID = sharingAgreementID;
  }

}
