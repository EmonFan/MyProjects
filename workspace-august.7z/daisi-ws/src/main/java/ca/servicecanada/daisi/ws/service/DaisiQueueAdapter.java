package ca.servicecanada.daisi.ws.service;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbToDaisiCanonicalFormTranslator;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;
import ca.servicecanada.daisi.util.MQClient;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.endpoint.generated.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINRequestType;
import ca.servicecanada.daisi.ws.endpoint.generated.SetBankAccountBySINResponseType;
import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyTo;
import ca.servicecanada.daisi.ws.handler.support.WsAddressingReplyToThreadLocal;

//push a message into the queue
@Import( {org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class, ca.servicecanada.daisi.util.MQClient.class} )
@Component
public class DaisiQueueAdapter {

	private Logger LOGGER = LogManager.getLogger(getClass());

	private String pushQueueName = "activemq:daisi-incoming-CPP-push-DD-Queue";

	private String pullQueueName = "activemq:daisi-incoming-CPP-pull-DD-Queue";

	private String pushCallbackQueueName = "activemq:daisi-outgoing-CPP-push-DD-callback-Queue";

	private String pullCallbackQueueName = "activemq:daisi-outgoing-CPP-pull-DD-callback-Queue";
	
	private String rejectedQueueName = "activemq:daisi-rejected-Queue";

	private String cppPullQueueName = "activemq:daisi-outgoing-CPP-pull-DD-Queue";
	
	private String cppPushQueueName = "activemq:daisi-outgoing-CPP-push-DD-Queue";

	private Map<String, String> queueMap = new HashMap<String, String>();

	@Resource
	private DsbToDaisiCanonicalFormTranslator translator;

	@Resource
	private MQClient mq;

	public DaisiQueueAdapter() {
		try {
			queueMap.put(RetrieveBankAccountBySINResponseType.class.getName(), pullCallbackQueueName);
			queueMap.put(SetBankAccountBySINResponseType.class.getName(), pushCallbackQueueName);
			queueMap.put(RetrieveBankAccountBySINRequestType.class.getName(), pullQueueName);
			queueMap.put(SetBankAccountBySINRequestType.class.getName(), pushQueueName);
			queueMap.put(SetBankAccountBySINRequestType.class.getName(), pushQueueName);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
	}

	// CPPpull
	public String onMessageRetrieveBankAccountBySINRequestDataAreaType(String jsonString) {

		String messageID = "";
		LOGGER.debug("Preparing RetrieveBankAccountBySINRequest for queue ");
		try {
			mq.setQueueName(cppPullQueueName);
			messageID = mq.sendJson(jsonString);
		} catch (Exception e) {
			LOGGER.error("Something happened trying to send JSON string to queue " + cppPullQueueName);
		}
		
		return messageID;
	}
	
	// CPPpush
	public String onMessageSetBankAccountBySINRequestDataAreaType(String jsonString) {

		String messageID = "";
		LOGGER.debug("Preparing SetBankAccountBySINRequestDataAreaType for queue ");
		try {
			mq.setQueueName(cppPushQueueName);
			messageID = mq.sendJson(jsonString);
		} catch (Exception e) {
			LOGGER.error("Something happened trying to send JSON string to queue " + cppPushQueueName);
		}
		
		return messageID;
	}
	
	
	String queueNameFactory(String dsbClassName) {
		String queue = "";
		LOGGER.debug("in factory");
		if (queueMap.containsKey(dsbClassName)) {
			queue = queueMap.get(dsbClassName);
		} else {
			throw new IllegalArgumentException("unknown DSB data type " + dsbClassName);
		}
		return queue;
	}

	void onMessage(DaisiExchangeRequest request, String dsbClassName) {
		String msg = null;
		try {
			LOGGER.debug("in onMessage");
			msg = translator.unmarshall(request);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		String queueName = null;
		String resultCode = request.getResultCode();
		
		if ("Rejected".equalsIgnoreCase(resultCode)){
			queueName = rejectedQueueName;
		} else {
			try {
				queueName = queueNameFactory(dsbClassName);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}
		}

		mq.setQueueName(queueName);

		WsAddressingReplyTo wsAddressingReplyTo = null;
		try {
			wsAddressingReplyTo = WsAddressingReplyToThreadLocal.get();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		String replyTo = wsAddressingReplyTo.getReplyTo();
		String relatesTo = wsAddressingReplyTo.getRelatesTo();
		
		mq.send(msg, replyTo, relatesTo );

		LOGGER.debug("Sending to DAISI queue " + queueName + ": \n" + msg);
	}

	// pull callback
	public void onRetrieveBankAccountBySINResponse(RetrieveBankAccountBySINResponseType dsbData) {

		LOGGER.debug("Transforming DSB to DAISI .. Callback for RetrieveBankAccountBySINResponse... ");
		DaisiExchangeRequest request = null;
		try {
			request = translator.transformRetrieveBankAccountBySINAsyncResponse(dsbData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		String dsbClassName = dsbData.getClass().getName();
		onMessage(request, dsbClassName);

	}

	// push callback
	public void onSetBankAccountBySINResponse(SetBankAccountBySINResponseType dsbData) {
		LOGGER.debug("Transforming DSB to DAISI .. Callback for SetBankAccountBySINResponse... ");

		DaisiExchangeRequest request = null;
		try {
			request = translator.transformRetrieveBankAccountBySINAsyncResponse(dsbData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		String dsbClassName = dsbData.getClass().getName();
		onMessage(request, dsbClassName);

	}

	// pull
	public void onMessageRetrieveBankAccountBySIN(RetrieveBankAccountBySINRequestType dsbData) {

		LOGGER.debug("Transforming DSB to DAISI .. RetrieveBankAccountBySIN... ");

		DaisiExchangeRequest request = null;
		try {
			request = translator.transformRetrieveBankAccountBySINRequest(dsbData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		String dsbClassName = dsbData.getClass().getName();
		onMessage(request, dsbClassName);

	}

	// push
	public void onMessageSetBankAccountBySIN(SetBankAccountBySINRequestType dsbData) {
		LOGGER.debug("Transforming DSB to DAISI .. RetrieveBankAccountBySIN... ");

		DaisiExchangeRequest request = null;
		try {
			request = translator.transformSetBankAccountBySINRequest(dsbData);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		String dsbClassName = dsbData.getClass().getName();
		onMessage(request, dsbClassName);
	}

	String toString(Object data, Class clazz) {
		StringWriter tempHolder = new StringWriter();

		JAXBContext jxbClientContext = null;
		Marshaller jxbClientMarshaler = null;

		try {
			jxbClientContext = JAXBContext.newInstance(clazz);
			jxbClientMarshaler = jxbClientContext.createMarshaller();
			// Removes the <?xml ....?> tag
			jxbClientMarshaler.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
			jxbClientMarshaler.marshal(data, tempHolder);

		} catch (JAXBException e) {
			e.printStackTrace();
		}
		String tmp = tempHolder.toString();
		LOGGER.debug(tmp);
		return tmp;

	}

}
