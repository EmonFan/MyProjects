package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.StatusType;

public interface StatusDao {

	List<StatusType> getAllStatusType();

	StatusType findStatusTypeByID(int id);

	int createStatusType(StatusType data);

	StatusType findStatusTypeByAbrv(String eventLogTypeAbrv);

	StatusType findStatusTypeByAbrv(String statusTypeAbrv, String languageCode);

}
