package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static ca.gc.servicecanada.daisi.constants.DaoConstants.LANG_EN;
import static ca.gc.servicecanada.daisi.constants.DaoConstants.LANG_FR;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.ref.RejectReasonDao;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;

@Component
public class RejectReasonDaoImpl implements RejectReasonDao {

	private final static String SELECT_ALL_REJECT_REASON_TYPE = "SELECT e FROM RejectReasonType e";

	// --------------- FIND BY ABRV ----------------
	private final static String FIND_REJECT_REASON_BY_ABRV_EN = "SELECT e FROM RejectReasonType e WHERE e.rejectReasonTypeAbrvEn = :rejectReasonTypeAbrv";
	private final static String FIND_REJECT_REASON_BY_ABRV_FR = "SELECT e FROM RejectReasonType e WHERE e.rejectReasonTypeAbrvFr = :rejectReasonTypeAbrv";

	// --------------- FIND BY EXTERNAL_CODE -----------------------
	private final static String FIND_REJECT_REASON_BY_EXTERNAL_CODE = "SELECT e FROM RejectReasonType e WHERE e.externalCode = :externalCode";

	private Map<String, String> rejectReasonQueryMap = new HashMap<String, String>();

	public RejectReasonDaoImpl() {
		rejectReasonQueryMap = new HashMap<String, String>();
		rejectReasonQueryMap.put(LANG_EN, FIND_REJECT_REASON_BY_ABRV_EN);
		rejectReasonQueryMap.put(LANG_FR, FIND_REJECT_REASON_BY_ABRV_FR);

	}

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public List<RejectReasonType> getAllRejectReasonType() {
		TypedQuery<RejectReasonType> query = entityManager.createQuery(SELECT_ALL_REJECT_REASON_TYPE,
				RejectReasonType.class);
		return query.getResultList();
	}

	public RejectReasonType findRejectReasonTypeByID(int id) {
		RejectReasonType data = null;
		data = (RejectReasonType) entityManager.find(RejectReasonType.class, id);
		return data;

	}

	@Override
	public RejectReasonType findRejectReasonTypeByAbrv(String code) {
		return findRejectReasonTypeByAbrv(code, LANG_EN);
	}

	@Override
	public RejectReasonType findRejectReasonTypeByAbrv(String rejectReasonTypeAbrv, String languageCode) {
		languageCode = languageCode.toLowerCase();

		if (rejectReasonQueryMap.containsKey(languageCode)) {
			String queryString = rejectReasonQueryMap.get(languageCode);
			TypedQuery<RejectReasonType> query = entityManager.createQuery(queryString, RejectReasonType.class);
			query.setParameter("rejectReasonTypeAbrv", rejectReasonTypeAbrv);
			RejectReasonType data = query.getSingleResult();
			return data;
		} else {
			throw new IllegalArgumentException("Unsupported language " + languageCode);
		}
	}

	@Override
	public RejectReasonType findRejectReasonTypeByextErnalCode(String externalCode) {

		TypedQuery<RejectReasonType> query = entityManager.createQuery(FIND_REJECT_REASON_BY_EXTERNAL_CODE, RejectReasonType.class);
		query.setParameter("externalCode", externalCode);
		RejectReasonType data = query.getSingleResult();
		return data;
	}

	public int createRejectReasonType(RejectReasonType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getRejectReasonTypeID();
	}

}
