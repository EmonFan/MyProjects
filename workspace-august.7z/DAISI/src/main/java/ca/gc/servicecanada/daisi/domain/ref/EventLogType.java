package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_EVENT_LOG_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class EventLogType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "EVENT_LOG_TYPE_ID")
  private int eventLogTypeID;

  @Column(name = "EVENT_LOG_TYPE_CODE")
  private String eventLogTypeCode;

  @Column(name = "EVENT_LOG_TYPE_NAME_EN", length = 50)
  private String eventLogTypeNameEn;

  @Column(name = "EVENT_LOG_TYPE_NAME_FR", length = 50)
  private String eventLogTypeNameFr;

  @Column(name = "EVENT_LOG_TYPE_DESC_EN", length = 2000)
  private String eventLogTypeDescEn;

  @Column(name = "EVENT_LOG_TYPE_DESC_FR", length = 2000)
  private String eventLogTypeDescFr;

  @Column(name = "EVENT_LOG_TYPE_ABRV_EN", length = 10)
  private String eventLogTypeAbrvEn;

  @Column(name = "EVENT_LOG_TYPE_ABRV_FR", length = 10)
  private String eventLogTypeAbrvFr;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  // @Transient
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  // @Transient
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getEventLogTypeID()
  {
    return eventLogTypeID;
  }

  public void setEventLogTypeID(final int eventLogTypeID)
  {
    this.eventLogTypeID = eventLogTypeID;
  }

  public String getEventLogTypeCode()
  {
    return eventLogTypeCode;
  }

  public void setEventLogTypeCode(final String eventLogTypeCode)
  {
    this.eventLogTypeCode = eventLogTypeCode;
  }

  public String getEventLogTypeNameEn()
  {
    return eventLogTypeNameEn;
  }

  public void setEventLogTypeNameEn(final String eventLogTypeNameEn)
  {
    this.eventLogTypeNameEn = eventLogTypeNameEn;
  }

  public String getEventLogTypeNameFr()
  {
    return eventLogTypeNameFr;
  }

  public void setEventLogTypeNameFr(final String eventLogTypeNameFr)
  {
    this.eventLogTypeNameFr = eventLogTypeNameFr;
  }

  public String getEventLogTypeDescEn()
  {
    return eventLogTypeDescEn;
  }

  public void setEventLogTypeDescEn(final String eventLogTypeDescEn)
  {
    this.eventLogTypeDescEn = eventLogTypeDescEn;
  }

  public String getEventLogTypeDescFr()
  {
    return eventLogTypeDescFr;
  }

  public void setEventLogTypeDescFr(final String eventLogTypeDescFr)
  {
    this.eventLogTypeDescFr = eventLogTypeDescFr;
  }

  public String getEventLogTypeAbrvEn()
  {
    return eventLogTypeAbrvEn;
  }

  public void setEventLogTypeAbrvEn(final String eventLogTypeAbrvEn)
  {
    this.eventLogTypeAbrvEn = eventLogTypeAbrvEn;
  }

  public String getEventLogTypeAbrvFr()
  {
    return eventLogTypeAbrvFr;
  }

  public void setEventLogTypeAbrvFr(final String eventLogTypeAbrvFr)
  {
    this.eventLogTypeAbrvFr = eventLogTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("EventLogType [");
    builder.append(eventLogTypeID);
    builder.append(", ");
    builder.append(eventLogTypeNameEn);
    builder.append(", ");
    builder.append(eventLogTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE REFOWNRE9.CD_EVENT_LOG_TYPE
  (
    EVENT_LOG_TYPE_ID      NUMBER (12) NOT NULL ,
    EVENT_LOG_TYPE_CODE    VARCHAR2 (3 BYTE) NOT NULL ,
    EVENT_LOG_TYPE_NAME_EN VARCHAR2 (50 BYTE) NOT NULL ,
    EVENT_LOG_TYPE_NAME_FR VARCHAR2 (50 BYTE) NOT NULL ,
    EVENT_LOG_TYPE_DESC_EN VARCHAR2 (2000 BYTE) ,
    EVENT_LOG_TYPE_DESC_FR VARCHAR2 (2000 BYTE) ,
    EVENT_LOG_TYPE_ABRV_EN VARCHAR2 (10 BYTE) ,
    EVENT_LOG_TYPE_ABRV_FR VARCHAR2 (10 BYTE) ,
    EFFECTIVE_DATE         DATE NOT NULL ,
    EXPIRY_DATE            DATE ,
    DATE_CREATED           DATE NOT NULL ,
    SYSTEM_CREATED         VARCHAR2 NOT NULL ,
    USER_CREATED           VARCHAR2 NOT NULL ,
    DATE_UPDATED           DATE ,
    USER_UPDATED           VARCHAR2
  ) ;
ALTER TABLE REFOWNRE9.CD_EVENT_LOG_TYPE ADD CONSTRAINT EVNTLGTP_PK PRIMARY KEY ( EVENT_LOG_TYPE_ID ) ;

</code>
 */