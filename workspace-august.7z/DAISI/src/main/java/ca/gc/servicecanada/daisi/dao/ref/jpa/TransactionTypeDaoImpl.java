package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.TransactionTypeDao;
import ca.gc.servicecanada.daisi.domain.ref.ActionType;
import ca.gc.servicecanada.daisi.domain.ref.ActionType_;
import ca.gc.servicecanada.daisi.domain.ref.InformationType;
import ca.gc.servicecanada.daisi.domain.ref.InformationType_;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType_;

@Component
public class TransactionTypeDaoImpl implements TransactionTypeDao {

	private Logger LOGGER = LogManager.getLogger(getClass());
	
	private final static String SELECT_ALL_ACTION_TYPE = "SELECT e FROM ActionType e";
	private final static String SELECT_ALL_INFORMATION_TYPE = "SELECT e FROM InformationType e";
	private final static String SELECT_ALL_TRANSACTION_TYPE = "SELECT e FROM TransactionType e";

	//--------------- FIND BY CODE ---------------- 
//	private final static String FIND_ACTION_TYPE_BY_CODE = "SELECT e FROM ActionType e WHERE e.actionTypeCode = :actionTypeCode";
//	private final static String FIND_INFORMATION_TYPE_BY_CODE = "SELECT e FROM InformationType e WHERE e.informationTypeCode = :informationTypeCode";

	//--------------- FIND BY ABRV ----------------
	private final static String FIND_ACTION_TYPE_BY_ABRV_EN = "SELECT e FROM ActionType e WHERE e.actionTypeAbrvEn = :actionTypeAbrvEn";
	private final static String FIND_INFORMATION_TYPE_BY_ABRV_EN = "SELECT e FROM InformationType e WHERE e.informationTypeAbrvEn = :informationTypeAbrvEn";

	private final static String FIND_ACTION_TYPE_BY_ABRV_FR = "SELECT e FROM ActionType e WHERE e.actionTypeAbrvFr = :actionTypeAbrvFr";
	private final static String FIND_INFORMATION_TYPE_BY_ABRV_FR = "SELECT e FROM InformationType e WHERE e.informationTypeAbrvFr = :informationTypeAbrvFr";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public List<ActionType> getAllActionType() {
		TypedQuery<ActionType> query = entityManager.createQuery(SELECT_ALL_ACTION_TYPE, ActionType.class);
		return query.getResultList();
	}

	public ActionType findActionTypeByID(int id) {
		ActionType data = null;
		data = (ActionType) entityManager.find(ActionType.class, id);
		return data;
	}

	public ActionType findActionTypeByAbrv(String actionTypeAbrv) {
		//English abbreviation by default
		return findActionTypeByAbrv(actionTypeAbrv, DaoConstants.LANG_EN);
	}

	public ActionType findActionTypeByAbrv(String actionTypeAbrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<ActionType> query = entityManager.createQuery(FIND_ACTION_TYPE_BY_ABRV_EN,
					ActionType.class);
			query.setParameter("actionTypeAbrvEn", actionTypeAbrv);
			ActionType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<ActionType> query = entityManager.createQuery(FIND_ACTION_TYPE_BY_ABRV_FR,
					ActionType.class);
			query.setParameter("actionTypeAbrvFr", actionTypeAbrv);
			ActionType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	public InformationType findInformationTypeByAbrv(String informationTypeAbrv) {
		//English abbreviation by default
		return findInformationTypeByAbrv(informationTypeAbrv, DaoConstants.LANG_EN);
	}

	public InformationType findInformationTypeByAbrv(String informationTypeAbrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<InformationType> query = entityManager.createQuery(FIND_INFORMATION_TYPE_BY_ABRV_EN,
					InformationType.class);
			query.setParameter("informationTypeAbrvEn", informationTypeAbrv);
			InformationType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<InformationType> query = entityManager.createQuery(FIND_INFORMATION_TYPE_BY_ABRV_FR,
					InformationType.class);
			query.setParameter("informationTypeAbrvFr", informationTypeAbrv);
			InformationType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	public int createActionType(ActionType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getActionTypeID();
	}

	public List<InformationType> getAllInformationType() {
		TypedQuery<InformationType> query = entityManager.createQuery(SELECT_ALL_INFORMATION_TYPE,
				InformationType.class);
		return query.getResultList();
	}

	public InformationType findInformationTypeByID(int id) {
		InformationType data = null;
		data = (InformationType) entityManager.find(InformationType.class, id);
		return data;
	}

	public int createInformationType(InformationType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getInformationTypeID();
	}

	// --------- TransactionType --------

	public List<TransactionType> getAllTransactionType() {
		TypedQuery<TransactionType> query = entityManager.createQuery(SELECT_ALL_TRANSACTION_TYPE,
				TransactionType.class);
		return query.getResultList();
	}

	public TransactionType findTransactionTypeByID(int id) {
		TransactionType data = null;
		data = (TransactionType) entityManager.find(TransactionType.class, id);
		return data;
	}

	public int createTransactionType(TransactionType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getTransactionTypeID();
	}

	public TransactionType findTransactionTypeByActionAndInfoTypeCode(String actionTypeCode,
			String informationTypeCode) {

		LOGGER.debug("findTransactionTypeByActionAndInfoTypeCode: "+ actionTypeCode +" + "+informationTypeCode );
		
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TransactionType> criteriaQuery = criteriaBuilder.createQuery(TransactionType.class);
		Root<TransactionType> root = criteriaQuery.from(TransactionType.class);

		Join<TransactionType, ActionType> join = root.join(TransactionType_.actionType);
		Join<TransactionType, InformationType> join2 = root.join(TransactionType_.informationType);

		criteriaQuery.where(criteriaBuilder.equal(join.get(ActionType_.actionTypeCode), actionTypeCode),
				criteriaBuilder.equal(join2.get(InformationType_.informationTypeCode), informationTypeCode));

		return (TransactionType) entityManager.createQuery(criteriaQuery).setMaxResults(1).getSingleResult();
	}

	public TransactionType findTransactionTypeByActionAndInfoTypeNames(String actionTypeNameEn,
			String informationTypeNameEn) {

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TransactionType> criteriaQuery = criteriaBuilder.createQuery(TransactionType.class);
		Root<TransactionType> root = criteriaQuery.from(TransactionType.class);

		Join<TransactionType, ActionType> join = root.join(TransactionType_.actionType, JoinType.LEFT);
		Join<TransactionType, InformationType> join2 = root.join(TransactionType_.informationType);

		criteriaQuery.where(criteriaBuilder.equal(join.get(ActionType_.actionTypeNameEn), actionTypeNameEn),
				criteriaBuilder.equal(join2.get(InformationType_.informationTypeNameEn), informationTypeNameEn));
		
		return (TransactionType) entityManager.createQuery(criteriaQuery).setMaxResults(1).getSingleResult();

	}

}
