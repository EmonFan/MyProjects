package ca.gc.servicecanada.daisi.service.client;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

/** reference (demo) REST client to retrieve DAISI Referential Data */
//@Component
public class DaisiReferenceDataClient {
	private Logger LOGGER = LogManager.getLogger(getClass());

	//@Resource
	private WebServicesCaller restService;

	//@Value("${ProgramServiceTypesUrl}")
	private String programServiceTypesUrl;

	private Gson gson = new Gson();

	public List<ProgramServiceType> getProgramServiceTypes() {
		String json = restService.executeGet(programServiceTypesUrl);
		List<ProgramServiceType> data = transfromProgramServiceTypes(json);
		return data;
	}

	public ProgramServiceType findDaisiProgramServiceTypeByID(int id) {
		String url = programServiceTypesUrl+"/"+id;
		String json = restService.executeGet(url);
		ProgramServiceType data = transfromProgramServiceType(json);
		return data;
	}

	

	public List<ProgramServiceType> transfromProgramServiceTypes(String json) {
		List<ProgramServiceType> collection = gson.fromJson(json, new TypeToken<ArrayList<ProgramServiceType>>() {
		}.getType());
		return collection;
	}

	public ProgramServiceType transfromProgramServiceType(String json) {
		ProgramServiceType data = gson.fromJson(json, new TypeToken<ProgramServiceType>() {
		}.getType());
		return data;
	}

}
