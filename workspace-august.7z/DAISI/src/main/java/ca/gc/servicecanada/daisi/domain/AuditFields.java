package ca.gc.servicecanada.daisi.domain;

import java.util.Date;

public interface AuditFields {

	public Date getDateCreated();

	public void setDateCreated(Date dateCreated);

	public String getSystemCreated();

	public void setSystemCreated(String systemCreated);

	public String getUserCreated();

	public void setUserCreated(String userCreated);

	public Date getDateUpdated();

	public void setDateUpdated(Date dateUpdated);

	public String getUserUpdated();

	public void setUserUpdated(String userUpdated);

}
