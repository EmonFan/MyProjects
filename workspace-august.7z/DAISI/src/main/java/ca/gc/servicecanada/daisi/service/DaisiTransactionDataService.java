package ca.gc.servicecanada.daisi.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;

@Component
public class DaisiTransactionDataService {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private BusinessTransactionDao transactionDao;

	public List<BusinessTransaction> findBusinessTransactionsBySin(String sin) {

		List<BusinessTransaction> data = transactionDao.findBusinessTransactionBySIN(sin);
		return data;
	}

	public BusinessTransaction create(BusinessTransaction data) {
		data = transactionDao.create(data);
		return data;
	}
	
	public BusinessTransaction update(BusinessTransaction data) {
		data = transactionDao.update(data);
		return data;
	}


	public BusinessTransaction findBusinessTransactionById(int id) {
		BusinessTransaction data = transactionDao.findBusinessTransactionByID(id);
		return data;
	}

	public BusinessTransaction findBusinessTransactionByTrxId(String businessTransactionID) {
		BusinessTransaction data = transactionDao.findBusinessTransactionByBusinessTransactionID(businessTransactionID);
		return data;

	}

}
