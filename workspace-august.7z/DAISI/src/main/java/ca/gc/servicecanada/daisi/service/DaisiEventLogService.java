package ca.gc.servicecanada.daisi.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.ref.EventLogTypeDao;
import ca.gc.servicecanada.daisi.dao.trx.EventLogDao;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;

@Component
public class DaisiEventLogService {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private EventLogDao eventLogDao;

	@Resource
	private EventLogTypeDao eventLogTypeDao;

	public List<EventLog> findEventLogByTransactionID(int trxId) {
		LOGGER.debug("EventLog lookup for trxId=" + trxId);
		return eventLogDao.findEventLogByTransactionID(trxId);
	}

	public List<EventLog> findEventLogBySin(String SIN) {
		LOGGER.debug("EventLog lookup for SIN=***" + SIN.substring(6));
		return eventLogDao.findEventLogBySin(SIN);
	}

	public List<EventLog> getAllEventLogs() {
		return eventLogDao.getAllEventLogs();
	}

	public void createEventLog(EventLog event) {
		eventLogDao.createEventLog(event);
	}

	// -----
	public List<EventLogType> getAllEventLogTypes() {
		return eventLogTypeDao.getAllEventLogType();
	}

	public EventLogType findEventLogTypeByCode(String eventLogTypeCode) {
		return eventLogTypeDao.findEventLogTypeByCode(eventLogTypeCode);
	}
	
	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv) {
		return eventLogTypeDao.findEventLogTypeByAbrv(eventLogTypeAbrv);
	}


}
