package ca.gc.servicecanada.daisi.dao.trx.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.trx.TransactionMessageDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction_;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction_;
import ca.gc.servicecanada.daisi.domain.trx.TransactionMessage;
import ca.gc.servicecanada.daisi.domain.trx.TransactionMessage_;


@Component
public class TransactionMessageDaoImpl implements TransactionMessageDao {

	private Logger LOGGER = LogManager.getLogger(getClass());

	// for testing only
	private final static String SELECT_ALL_TRANSACTION_MESSAGES = "SELECT e FROM TransactionMessage e";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	@Override
	public List<TransactionMessage> findTransactionMessageByTransactionID(int trxId) {
		LOGGER.debug("lookup for TransactionMessages for TECHNICAL_TRANS_ID = " + trxId);
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TransactionMessage> query = criteriaBuilder.createQuery(TransactionMessage.class);
		Root<TransactionMessage> root = query.from(TransactionMessage.class);
		Join<TransactionMessage, TechnicalTransaction> join = root.join(TransactionMessage_.technicalTransaction);
		query.where(criteriaBuilder.equal(join.get(TechnicalTransaction_.transactionID), trxId));
		query.select(root);
		List<TransactionMessage> data = entityManager.createQuery(query).getResultList();

		return data;
	}

	@Override
	public List<TransactionMessage> findTransactionMessageBySIN(String SIN) {
		LOGGER.debug("lookup for TransactionMessage for SIN = " + SIN);
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TransactionMessage> query = criteriaBuilder.createQuery(TransactionMessage.class);
		
		Root<TransactionMessage> root = query.from(TransactionMessage.class);
		
		Join<TransactionMessage, TechnicalTransaction> messageAndTechnical = root.join(TransactionMessage_.technicalTransaction);
		Join<TechnicalTransaction, BusinessTransaction> technicalAndBusiness = messageAndTechnical.join(TechnicalTransaction_.businessTransaction);
		query.where(criteriaBuilder.equal(technicalAndBusiness.get(BusinessTransaction_.sin), SIN));
		query.select(root);
		List<TransactionMessage> data = entityManager.createQuery(query).getResultList();

		return data;
	}

	// for testing only
	@Override
	public List<TransactionMessage> getAllTransactionMessages() {
		TypedQuery<TransactionMessage> query = entityManager.createQuery(SELECT_ALL_TRANSACTION_MESSAGES, TransactionMessage.class);
		return query.getResultList();

	}

	@Override
	public TransactionMessage createTransactionMessage(TransactionMessage transactionMessage) {
		entityManager.persist(transactionMessage);
		int id = transactionMessage.getTransactionMessageID();
		return transactionMessage;
	}

}
