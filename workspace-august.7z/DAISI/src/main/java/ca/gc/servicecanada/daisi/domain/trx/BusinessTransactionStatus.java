package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "BUSINESS_TRANS_STATUS")
public class BusinessTransactionStatus extends AuditFieldsImpl
{

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "BUSINESS_TRANS_STATUS_ID")
  private int businessTransactionStatusID;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "STATUS_TYPE_ID", nullable = false, updatable = false)
  private StatusType statusType;

  @ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
  @JoinColumn(name = "REJECT_REASON_TYPE_ID", nullable = true, updatable = false)
  private RejectReasonType rejectReasonType;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "EFFECTIVE_DATE")
  private Date effectiveDate;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "EXPIRY_DATE")
  private Date expiryDate;

  public int getBusinessTransactionStatusID()
  {
    return businessTransactionStatusID;
  }

  public void setBusinessTransactionStatusID(final int businessTransactionStatusID)
  {
    this.businessTransactionStatusID = businessTransactionStatusID;
  }

  public StatusType getStatusType()
  {
    return statusType;
  }

  public void setStatusType(final StatusType statusType)
  {
    this.statusType = statusType;
  }

  public RejectReasonType getRejectReasonType()
  {
    return rejectReasonType;
  }

  public void setRejectReasonType(final RejectReasonType rejectReasonType)
  {
    this.rejectReasonType = rejectReasonType;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("BusinessTransactionStatus [businessTransactionStatusID=");
    builder.append(businessTransactionStatusID);
    builder.append(", statusType=");
    builder.append(statusType);
    builder.append(", rejectReasonType=");
    builder.append(rejectReasonType);
    builder.append("]");
    return builder.toString();
  }
}
