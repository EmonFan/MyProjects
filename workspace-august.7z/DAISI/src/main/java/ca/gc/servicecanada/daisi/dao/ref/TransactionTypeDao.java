package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.ActionType;
import ca.gc.servicecanada.daisi.domain.ref.InformationType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;

public interface TransactionTypeDao {
	// ------------- ActionType ----------
	List<ActionType> getAllActionType();
	
	ActionType findActionTypeByAbrv(String actionTypeAbrv);

	ActionType findActionTypeByAbrv(String actionTypeAbrv, String languageCode);

	ActionType findActionTypeByID(int id);

	int createActionType(ActionType data);

	// ------------- ActionType ----------
	List<InformationType> getAllInformationType();

	InformationType findInformationTypeByID(int id);

	InformationType findInformationTypeByAbrv(String informationTypeAbrv);

	InformationType findInformationTypeByAbrv(String informationTypeAbrv, String languageCode);

	int createInformationType(InformationType data);

	// ------------- TransactionType ----------
	List<TransactionType> getAllTransactionType();

	TransactionType findTransactionTypeByID(int id);

	int createTransactionType(TransactionType data);
	
	//----------- Lookups ------------------------
			 
	TransactionType  findTransactionTypeByActionAndInfoTypeNames(String actionTypeNameEn, String informationTypeNameEn);

	TransactionType findTransactionTypeByActionAndInfoTypeCode(String actionTypeCode, String informationTypeCode);

}
