package ca.gc.servicecanada.daisi.controller.rest;

import javax.annotation.Resource;
import javax.ws.rs.PathParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ca.gc.servicecanada.daisi.service.DaisiDataSerializerStrategy;
import ca.gc.servicecanada.daisi.service.DaisiReferenceDataService;

//FIXME: there is a manual serialize to JSOn step that I am sure can be delegated to the Spring container out of the box
@RestController
@RequestMapping("/DaisiReferenceData")
public class DaisiRefDataRestService {
	
	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private DaisiReferenceDataService refDataService;

	@Resource
	private DaisiDataSerializerStrategy daisiSerializer;

	// *********** Lookups ******************

	@RequestMapping(value = { "ProgramServiceTypes/code={code}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findDaisiProgramServiceTypeByCode(@PathVariable String code) {
		return serialize(refDataService.findDaisiProgramServiceTypeByCode(code));
	}
	

	
	@RequestMapping(value = { "/OrganizationTypes/code={code}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findOrganizationTypeByCode(@PathVariable String code) {
		return serialize(refDataService.findOrganizationTypeByCode(code));
	}

	
	@RequestMapping(value = { "/ChannelTypes/code={code}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findChannelTypeByCode(@PathVariable String code) {
		return serialize(refDataService.findChannelTypeByCode(code));
	}

	
	@RequestMapping(value = { "/ChannelTypes/abrv={abrv}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findChannelTypeByAbrv(@PathVariable String abrv) {
		return serialize(refDataService.findChannelTypeByAbrv(abrv));
	}

	
	@RequestMapping(value = { "/ConsentStatementTypes/code={code}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findConsentStatementTypeByCode(@PathVariable String code) {
		return serialize(refDataService.findConsentStatementTypeByCode(code));
	}

	
	@RequestMapping(value = { "/TransactionTypes/actionTypeName={actionTypeName}/informationTypeName={informationTypeName}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findTransactionTypeByActionAndInfoTypeNames(@PathVariable String actionTypeName,
			@PathParam("informationTypeName") String informationTypeName) {
		
		return serialize(
				refDataService.findTransactionTypeByActionAndInfoTypeNames(actionTypeName, informationTypeName));
	}
	
	
	@RequestMapping(value = { "/TransactionTypes/actionTypeCode={actionTypeCode}/informationTypeCode={informationTypeCode}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findTransactionTypeByActionAndInfoTypeCode(@PathVariable String actionTypeCode,
			@PathParam("informationTypeCode") String informationTypeCode) {
		
		return serialize(
				refDataService.findTransactionTypeByActionAndInfoTypeNames(actionTypeCode, informationTypeCode));
	}
	

	// *********** All ******************

	
	@RequestMapping(value = { "/ProgramServiceTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllProgramServiceType() {
		return serialize(refDataService.getAllProgramServiceType());
	}

	
	@RequestMapping(value = { "/ProgramServiceTypes/{id}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findDaisiProgramServiceTypeByID(@PathVariable int id) {
		return serialize(refDataService.findDaisiProgramServiceTypeByID(id));
	}

	
	@RequestMapping(value = { "/ConsentStatementTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllConsentStatementType() {
		return serialize(refDataService.getAllConsentStatementType());
	}

	
	@RequestMapping(value = { "/TransactionTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllTransactionType() {
		return serialize(refDataService.getAllTransactionType());
	}

	
	@RequestMapping(value = { "/OrganizationTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllOrganizationType() {
		return serialize(refDataService.getAllOrganizationType());
	}

	
	@RequestMapping(value = { "/ChannelTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllChannelType() {
		return serialize(refDataService.getAllChannelType());
	}

	
	@RequestMapping(value = { "/StatusTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllStatusType() {
		return serialize(refDataService.getAllStatusType());
	}

	
	@RequestMapping(value = { "/InformationTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllInformationType() {
		return serialize(refDataService.getAllInformationType());
	}

	
	@RequestMapping(value = { "/ActionTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllActionType() {
		return serialize(refDataService.getAllActionType());
	}

	
	@RequestMapping(value = { "/RejectReasonTypes" }, method = RequestMethod.GET)
	@ResponseBody
	public String getAllRejectReasonType() {
		return serialize(refDataService.getAllRejectReasonType());
	}

	String serialize(Object data) {
		String output = daisiSerializer.serialize(data);
		LOGGER.debug("serialized to \n" + output);
		return output;
	}

}
