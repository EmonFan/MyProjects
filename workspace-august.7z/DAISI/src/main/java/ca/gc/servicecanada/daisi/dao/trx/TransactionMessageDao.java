package ca.gc.servicecanada.daisi.dao.trx;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.trx.*;

public interface TransactionMessageDao {

	List<TransactionMessage> findTransactionMessageByTransactionID(int trxId);

	List<TransactionMessage> findTransactionMessageBySIN(String SIN);

	List<TransactionMessage> getAllTransactionMessages();

	TransactionMessage createTransactionMessage(TransactionMessage transactionMessage);


}
