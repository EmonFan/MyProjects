package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "BUSINESS_TRANS")
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "JPA_DESCRIMINATOR")
public abstract class BusinessTransaction extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BSNSTRNS_SEQ")
  @SequenceGenerator(name = "BSNSTRNS_SEQ", sequenceName = "BSNSTRNS_SEQ")
  @Column(name = "BUSINESS_TRANS_ID")
  protected int id;

  // ------------ META DATA ---------------
  @Column(name = "BUSINESS_TRANSACTION_ID", updatable = false)
  protected String businessTransactionID;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "BUSINESS_TRANSACTION_DATE", nullable = true, updatable = false)
  protected Date businessTransactionDate;

  @JsonManagedReference
  @OneToMany(mappedBy = "businessTransaction", fetch = FetchType.EAGER, cascade = {
      CascadeType.PERSIST, CascadeType.MERGE })
  protected List<TechnicalTransaction> technicalTransactions;

  @JsonManagedReference
  //@OneToMany(mappedBy = "businessTransaction", fetch = FetchType.EAGER, cascade = { CascadeType.ALL})
  @OneToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
  //@Cascade({CascadeType.ALL}) 
  @JoinColumn(name = "BUSINESS_TRANS_ID", nullable = false)
  protected Set<BusinessTransactionStatus> businessTransactionStatuses;

  // ------------ USER INPUT ---------------
  @Column(name = "SIN", updatable = false)
  protected String sin;

  @Column(name = "SURNAME", updatable = false)
  protected String surname;

  @Column(name = "BIRTH_DATE", updatable = false)
  protected String birthDate;

  @Column(name = "CONSENT_CODE", updatable = false)
  protected String consentCode;

  // ------------ REFERENCE ---------------

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "TRANSACTION_TYPE_ID", nullable = true, updatable = false)
  protected TransactionType transactionType;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ORGANIZATION_TYPE_ID_TARGET", nullable = true, updatable = false)
  protected OrganizationType organizationTypeTarget;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ORGANIZATION_TYPE_ID_SOURCE", nullable = true, updatable = false)
  protected OrganizationType organizationTypeSource;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "PROGRAM_SERVICE_TYPE_ID_SOURCE", nullable = true, updatable = false)
  protected ProgramServiceType programServiceTypeSource;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "PROGRAM_SERVICE_TYPE_ID_TARGET", nullable = true, updatable = false)
  protected ProgramServiceType programServiceTypeTarget;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "CHANNEL_TYPE_ID", nullable = true, updatable = false)
  protected ChannelType channelType;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "CONSENT_STATEMENT_TYPE_ID", nullable = true, updatable = false)
  protected ConsentStatementType consentStatementType;

  public void addTechnicalTransaction(final TechnicalTransaction technicalTransaction)
  {
    technicalTransactions.add(technicalTransaction);
    if (technicalTransaction.getBusinessTransaction() != this)
    {
      technicalTransaction.setBusinessTransaction(this);
    }
  }

  public int getId()
  {
    return id;
  }

  public void setId(final int id)
  {
    this.id = id;
  }

  public String getBusinessTransactionID()
  {
    return businessTransactionID;
  }

  public void setBusinessTransactionID(final String businessTransactionID)
  {
    this.businessTransactionID = businessTransactionID;
  }

  public List<TechnicalTransaction> getTechnicalTransactions()
  {
    return technicalTransactions;
  }

  public void setTechnicalTransactions(final List<TechnicalTransaction> technicalTransactions)
  {
    this.technicalTransactions = technicalTransactions;
  }

  public Date getBusinessTransactionDate()
  {
    return businessTransactionDate;
  }

  public void setBusinessTransactionDate(final Date businessTransactionDate)
  {
    this.businessTransactionDate = businessTransactionDate;
  }

  public TransactionType getTransactionType()
  {
    return transactionType;
  }

  public void setTransactionType(final TransactionType transactionType)
  {
    this.transactionType = transactionType;
  }

  public OrganizationType getOrganizationTypeTarget()
  {
    return organizationTypeTarget;
  }

  public void setOrganizationTypeTarget(final OrganizationType organizationTypeTarget)
  {
    this.organizationTypeTarget = organizationTypeTarget;
  }

  public OrganizationType getOrganizationTypeSource()
  {
    return organizationTypeSource;
  }

  public void setOrganizationTypeSource(final OrganizationType organizationTypeSource)
  {
    this.organizationTypeSource = organizationTypeSource;
  }

  public ProgramServiceType getProgramServiceTypeSource()
  {
    return programServiceTypeSource;
  }

  public void setProgramServiceTypeSource(final ProgramServiceType programServiceTypeSource)
  {
    this.programServiceTypeSource = programServiceTypeSource;
  }

  public ProgramServiceType getProgramServiceTypeTarget()
  {
    return programServiceTypeTarget;
  }

  public void setProgramServiceTypeTarget(final ProgramServiceType programServiceTypeTarget)
  {
    this.programServiceTypeTarget = programServiceTypeTarget;
  }

  public ChannelType getChannelType()
  {
    return channelType;
  }

  public void setChannelType(final ChannelType channelType)
  {
    this.channelType = channelType;
  }

  public ConsentStatementType getConsentStatementType()
  {
    return consentStatementType;
  }

  public void setConsentStatementType(final ConsentStatementType consentStatementType)
  {
    this.consentStatementType = consentStatementType;
  }

  public Set<BusinessTransactionStatus> getBusinessTransactionStatuses()
  {
    return businessTransactionStatuses;
  }

  public void setBusinessTransactionStatuses(
      final Set<BusinessTransactionStatus> businessTransactionStatuses)
  {
    this.businessTransactionStatuses = businessTransactionStatuses;
  }

  public String getSin()
  {
    return sin;
  }

  public void setSin(final String sin)
  {
    this.sin = sin;
  }

  public String getSurname()
  {
    return surname;
  }

  public void setSurname(final String surname)
  {
    this.surname = surname;
  }

  public String getBirthDate()
  {
    return birthDate;
  }

  public void setBirthDate(final String birthDate)
  {
    this.birthDate = birthDate;
  }

  public String getConsentCode()
  {
    return consentCode;
  }

  public void setConsentCode(final String consentCode)
  {
    this.consentCode = consentCode;
  }

  @Override
  public Date getDateCreated()
  {
    return dateCreated;
  }

  @Override
  public void setDateCreated(final Date dateCreated)
  {
    this.dateCreated = dateCreated;
  }

  @Override
  public String getSystemCreated()
  {
    return systemCreated;
  }

  @Override
  public void setSystemCreated(final String systemCreated)
  {
    this.systemCreated = systemCreated;
  }

  @Override
  public String getUserCreated()
  {
    return userCreated;
  }

  @Override
  public void setUserCreated(final String userCreated)
  {
    this.userCreated = userCreated;
  }

  @Override
  public Date getDateUpdated()
  {
    return dateUpdated;
  }

  @Override
  public void setDateUpdated(final Date dateUpdated)
  {
    this.dateUpdated = dateUpdated;
  }

  @Override
  public String getUserUpdated()
  {
    return userUpdated;
  }

  @Override
  public void setUserUpdated(final String userUpdated)
  {
    this.userUpdated = userUpdated;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("BusinessTransaction [id=");
    builder.append(id);
    builder.append(", businessTransactionID=");
    builder.append(businessTransactionID);
    builder.append(", businessTransactionDate=");
    builder.append(businessTransactionDate);
    builder.append(", technicalTransactions=");
    builder.append(technicalTransactions);
    builder.append(", businessTransactionStatuses=");
    builder.append(businessTransactionStatuses);
    builder.append(", sin=");
    builder.append(sin);
    builder.append(", surname=");
    builder.append(surname);
    builder.append(", birthDate=");
    builder.append(birthDate);
    builder.append(", transactionType=");
    builder.append(transactionType);
    builder.append(", organizationTypeTarget=");
    builder.append(organizationTypeTarget);
    builder.append(", organizationTypeSource=");
    builder.append(organizationTypeSource);
    builder.append(", programServiceTypeSource=");
    builder.append(programServiceTypeSource);
    builder.append(", programServiceTypeTarget=");
    builder.append(programServiceTypeTarget);
    builder.append(", channelType=");
    builder.append(channelType);
    builder.append(", consentStatementType=");
    builder.append(consentStatementType);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE ISPOWNRE9.BUSINESS_TRANS
(
  BUSINESS_TRANS_ID              NUMERIC (12) NOT NULL ,
  BUSINESS_TRANSACTION_ID        VARCHAR(50) NOT NULL ,
  BUSINESS_TRANSACTION_DATE      DATE ,
  TRANSACTION_TYPE_ID            NUMERIC (12) ,
  ORGANIZATION_TYPE_ID_TARGET    NUMERIC (12) ,
  ORGANIZATION_TYPE_ID_SENDER    NUMERIC (12) ,
  PROGRAM_SERVICE_TYPE_ID_SOURCE NUMERIC (12) ,
  PROGRAM_SERVICE_TYPE_ID_TARGET NUMERIC (12) ,
  CHANNEL_TYPE_ID                NUMERIC (12) ,
  CONSENT_STATEMENT_TYPE_ID      NUMERIC (12) ,
  SIN                            VARCHAR (9 ) ,
  SURNAME                        VARCHAR(30 ) ,
  BIRTH_DATE                     DATE ,
  CONSENT_CODE                   VARCHAR (7 ) ,
  JPA_DESCRIMINATOR              CHAR (3 ) ,
  DATE_CREATED                   DATE NOT NULL ,
  SYSTEM_CREATED                 VARCHAR (30 ) NOT NULL ,
  USER_CREATED                   VARCHAR (30 ) NOT NULL ,
  DATE_UPDATED                   DATE ,
  USER_UPDATED                   VARCHAR (30 )
) ;

</code>
 */