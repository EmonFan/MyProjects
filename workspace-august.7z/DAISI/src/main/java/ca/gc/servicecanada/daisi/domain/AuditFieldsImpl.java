package ca.gc.servicecanada.daisi.domain;

import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlTransient;

@MappedSuperclass
public class AuditFieldsImpl implements AuditFields, Serializable
{

  private static final long serialVersionUID = 1L;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "DATE_CREATED", updatable = false)
  @Temporal(TemporalType.TIMESTAMP)
  protected Date dateCreated = new Date();

  @XmlTransient
  @Column(name = "SYSTEM_CREATED", updatable = false)
  protected String systemCreated = "DAISI";

  @XmlTransient
  @Column(name = "USER_CREATED", updatable = false)
  protected String userCreated = "DAISI_USER";

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "DATE_UPDATED")
  @Temporal(TemporalType.TIMESTAMP)
  protected Date dateUpdated;

  @XmlTransient
  @Column(name = "USER_UPDATED")
  protected String userUpdated;

  @Override
  public Date getDateCreated()
  {
    return dateCreated;
  }

  @Override
  public void setDateCreated(final Date dateCreated)
  {
    this.dateCreated = dateCreated;
  }

  @Override
  public String getSystemCreated()
  {
    return systemCreated;
  }

  @Override
  public void setSystemCreated(final String systemCreated)
  {
    this.systemCreated = systemCreated;
  }

  @Override
  public String getUserCreated()
  {
    return userCreated;
  }

  @Override
  public void setUserCreated(final String userCreated)
  {
    this.userCreated = userCreated;
  }

  @Override
  public Date getDateUpdated()
  {
    return dateUpdated;
  }

  @Override
  public void setDateUpdated(final Date dateUpdated)
  {
    this.dateUpdated = dateUpdated;
  }

  @Override
  public String getUserUpdated()
  {
    return userUpdated;
  }

  @Override
  public void setUserUpdated(final String userUpdated)
  {
    this.userUpdated = userUpdated;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("AuditFieldsImpl [dateCreated=");
    builder.append(dateCreated);
    builder.append(", systemCreated=");
    builder.append(systemCreated);
    builder.append(", userCreated=");
    builder.append(userCreated);
    builder.append(", dateUpdated=");
    builder.append(dateUpdated);
    builder.append(", userUpdated=");
    builder.append(userUpdated);
    builder.append("]");
    return builder.toString();
  }

}
