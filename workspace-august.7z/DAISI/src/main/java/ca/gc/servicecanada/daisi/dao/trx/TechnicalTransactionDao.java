package ca.gc.servicecanada.daisi.dao.trx;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

public interface TechnicalTransactionDao {

	// for testing only
	List<TechnicalTransaction> getAllTechnicalTransactions();

	TechnicalTransaction findTechnicalTransactionByTechnicalTransID(int id);

	List<TechnicalTransaction> findTechnicalTransactionsByBusinessTransactionId(int id);

	List<TechnicalTransaction> findTechnicalTransactionsByTechnicalTransactionId(String technicalTransactionID);	
	
	TechnicalTransaction create(TechnicalTransaction technicalTransaction);

}
