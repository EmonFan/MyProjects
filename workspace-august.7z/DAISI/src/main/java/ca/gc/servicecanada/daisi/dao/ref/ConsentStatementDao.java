package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;

public interface ConsentStatementDao {
	List<ChannelType> getAllChannelType();

	ChannelType findChannelTypeByID(int id);
	
	ChannelType findChannelTypeByCode(String channelTypeCode);

	ChannelType findChannelTypeByAbrv(String channelTypeAbrvCode);

	ChannelType findChannelTypeByAbrv(String channelTypeAbrv, String languageCode);

	int createChannelType(ChannelType data);

	List<ConsentStatementType> getAllConsentStatementType();

	ConsentStatementType findConsentStatementTypeByID(int id);
	
	ConsentStatementType findConsentStatementTypeByCode(String consentStatementTypeCode);

	ConsentStatementType findConsentStatementTypeByAbrv(String consentStatementTypeAbrv);
		
	int createConsentStatementType(ConsentStatementType data);

	ConsentStatementType findConsentStatementTypeByAbrv(String consentStatementTypeAbrv, String languageCode);
	
	String findConsentStatementTypeAbrv(String channelType, String consentCode);

}
