package ca.gc.servicecanada.daisi.service;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.ref.ConsentStatementDao;
import ca.gc.servicecanada.daisi.dao.ref.ProgramServiceDao;
import ca.gc.servicecanada.daisi.dao.ref.RejectReasonDao;
import ca.gc.servicecanada.daisi.dao.ref.StatusDao;
import ca.gc.servicecanada.daisi.dao.ref.TransactionTypeDao;
import ca.gc.servicecanada.daisi.domain.ref.ActionType;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.InformationType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;

@CacheConfig(cacheNames = { "refDataCache" })
@Component
public class DaisiReferenceDataService {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private ProgramServiceDao referenceDao;

	@Resource
	private ConsentStatementDao consentDao;

	@Resource
	private RejectReasonDao rejectDao;

	@Resource
	private TransactionTypeDao trxTypeDao;

	@Resource
	private StatusDao statusDao;

	@Resource
	private RejectReasonDao rejectReasonDao;

	// ------- Lookups by ID ----------------
	@Cacheable
	public RejectReasonType findRejectReasonTypeByID(int id) {
		RejectReasonType data = rejectReasonDao.findRejectReasonTypeByID(id);
		return data;
	}

	// ------- Lookups by code ----------------

	@Cacheable
	public ProgramServiceType findDaisiProgramServiceTypeByCode(String code) {
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByCode(code);
		return data;
	}

	@Cacheable
	public OrganizationType findOrganizationTypeByCode(String code) {
		OrganizationType data = referenceDao.findOrganizationTypeByCode(code);
		return data;
	}

	@Cacheable
	public ChannelType findChannelTypeByCode(String channelTypeCode) {
		ChannelType data = consentDao.findChannelTypeByCode(channelTypeCode);
		return data;
	}

	@Cacheable
	public ConsentStatementType findConsentStatementTypeByCode(String consentStatementTypeCode) {
		ConsentStatementType data = consentDao.findConsentStatementTypeByCode(consentStatementTypeCode);
		return data;
	}

	// ------- Lookups by abbreviation --------------
	@Cacheable
	public RejectReasonType findRejectReasonTypeByAbrv(String code) {
		RejectReasonType data = rejectReasonDao.findRejectReasonTypeByAbrv(code);
		return data;
	}
	
	@Cacheable
	public RejectReasonType findRejectReasonTypeByextErnalCode(String externalCode) {
		RejectReasonType data = rejectReasonDao.findRejectReasonTypeByextErnalCode(externalCode);
		return data;
	}

	@Cacheable
	public ProgramServiceType findDaisiProgramServiceTypeByAbrv(String abrv) {
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByAbrv(abrv);
		return data;
	}

	@Cacheable
	public OrganizationType findOrganizationTypeByAbrv(String abrv) {
		OrganizationType data = referenceDao.findOrganizationTypeByAbrv(abrv);
		return data;
	}

	@Cacheable
	public TransactionType findTransactionTypeByActionAndInfoTypeNames(String actionTypeNameEn,
			String informationTypeNameEn) {
		TransactionType data = trxTypeDao.findTransactionTypeByActionAndInfoTypeNames(actionTypeNameEn,
				informationTypeNameEn);
		return data;
	}

	@Cacheable
	public ChannelType findChannelTypeByAbrv(String channelTypeAbrv) {
		ChannelType data = consentDao.findChannelTypeByAbrv(channelTypeAbrv);
		return data;
	}

	@Cacheable
	public StatusType findStatusTypeByAbrv(String eventLogTypeAbrv) {
		StatusType data = statusDao.findStatusTypeByAbrv(eventLogTypeAbrv);
		return data;
	}

	/** lookup by actionTypeCode and informationTypeCode */
	@Cacheable
	public TransactionType findTransactionTypeByActionAndInfoTypeCode(String actionTypeCode,
			String informationTypeCode) {
		LOGGER.debug("findTransactionTypeByActionAndInfoTypeCode");
		String atc = this.trxTypeDao.findActionTypeByAbrv(actionTypeCode).getActionTypeCode();
		String itc = this.trxTypeDao.findInformationTypeByAbrv(informationTypeCode).getInformationTypeCode();
		TransactionType data = trxTypeDao.findTransactionTypeByActionAndInfoTypeCode(atc, itc);
		return data;
	}

	@Cacheable
	public ConsentStatementType findConsentStatementTypeByAbrv(String consentStatementTypeAbrv) {
		ConsentStatementType data = consentDao.findConsentStatementTypeByAbrv(consentStatementTypeAbrv);
		return data;
	}

	// ------- getAll ----------------

	@Cacheable
	public List<ProgramServiceType> getAllProgramServiceType() {
		List<ProgramServiceType> data = referenceDao.getAllProgramServiceType();
		return data;
	}

	@Cacheable
	public ProgramServiceType findDaisiProgramServiceTypeByID(int id) {
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByID(id);
		return data;
	}

	@Cacheable
	public List<ConsentStatementType> getAllConsentStatementType() {
		List<ConsentStatementType> data = consentDao.getAllConsentStatementType();
		return data;
	}

	@Cacheable
	public List<TransactionType> getAllTransactionType() {
		List<TransactionType> data = trxTypeDao.getAllTransactionType();
		return data;
	}

	@Cacheable
	public List<OrganizationType> getAllOrganizationType() {
		List<OrganizationType> data = referenceDao.getAllOrganizationType();
		return data;
	}

	@Cacheable
	public List<ChannelType> getAllChannelType() {
		List<ChannelType> data = consentDao.getAllChannelType();
		return data;
	}

	@Cacheable
	public List<StatusType> getAllStatusType() {
		List<StatusType> data = statusDao.getAllStatusType();
		return data;
	}

	@Cacheable
	public List<InformationType> getAllInformationType() {
		List<InformationType> data = trxTypeDao.getAllInformationType();
		return data;
	}

	@Cacheable
	public List<ActionType> getAllActionType() {
		List<ActionType> data = trxTypeDao.getAllActionType();
		return data;
	}

	@Cacheable
	public List<RejectReasonType> getAllRejectReasonType() {
		List<RejectReasonType> data = rejectDao.getAllRejectReasonType();
		return data;
	}

}
