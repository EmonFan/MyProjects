package ca.gc.servicecanada.daisi.service;

public interface DaisiDataSerializerStrategy {

	public String serialize(Object data);

}
