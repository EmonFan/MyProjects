package ca.gc.servicecanada.daisi.dao.trx;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.trx.*;

public interface EventLogDao {

	List<EventLog> findEventLogByTransactionID(int trxId);

	List<EventLog> findEventLogBySin(String SIN);

	List<EventLog> getAllEventLogs();

	void createEventLog(EventLog event);

}
