package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.EventLogType;

public interface EventLogTypeDao {
	// ------------- EventLogType ----------
	List<EventLogType> getAllEventLogType();

	EventLogType findEventLogTypeByID(int id);
	
	EventLogType findEventLogTypeByCode(String code);

	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv);

	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv, String languageCode);

	int createEventLogType(EventLogType data);

}
