package ca.gc.servicecanada.daisi.config;

import java.util.HashMap;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import ca.gc.servicecanada.daisi.constants.DaoConstants;

@Import( org.springframework.beans.factory.config.PropertyPlaceholderConfigurer.class )
@Configuration
@EnableTransactionManagement
@ComponentScan({ DaoConstants.PACKAGES_TO_SCAN })
@EnableJpaRepositories(
	    basePackages = DaoConstants.PACKAGES_TO_SCAN, 
	    entityManagerFactoryRef = "EntityManager", 
	    transactionManagerRef = "TransactionManager"	)
public class DaisiDataSourceConfiguration {
	private Logger LOGGER = LogManager.getLogger(getClass());

    @Bean
    public JpaTransactionManager refTransactionManager(){
		JpaTransactionManager jtManager = new JpaTransactionManager(
				refEntityManager().getObject());
		return jtManager;
	}
    
	@Bean
    @Qualifier(value = "entityManager")
	public LocalContainerEntityManagerFactoryBean refEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		try {
			em.setDataSource(refDataSource());
		} catch (NamingException e) {
			LOGGER.error("Unable to retrieve datasource");
			return null;
		}
        em.setPackagesToScan(new String[] { DaoConstants.PACKAGES_TO_SCAN });
        em.setPersistenceProviderClass(org.hibernate.jpa.HibernatePersistenceProvider.class);
        HibernateJpaVendorAdapter vendorAdapter = null;
		try {
			vendorAdapter = new HibernateJpaVendorAdapter();
		} catch (Exception e) {
			LOGGER.error("Unable to instantiate HibernateJPAVendorApadpter");
			return null;
		}

		em.setJpaVendorAdapter(vendorAdapter);
		em.setPersistenceUnitName(DaoConstants.DAISI_PERSISTANCE_NAME);
        
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect", DaoConstants.DATABASE_DIALECT);
        
        //ENABLE SECOND LEVEL CACHE
        properties.put("hibernate.cache.use_second_level_cache", "true");
        properties.put("hibernate.cache.provider_class", "org.hibernate.cache.EhCacheProvider");
        properties.put("hibernate.cache.region.factory_class", "org.hibernate.cache.ehcache.EhCacheRegionFactory");
        
        em.setJpaPropertyMap(properties);
        
        return em;
	}
	
    @Bean(destroyMethod = "")
    public DataSource refDataSource() throws NamingException {
        Object obj = null;
		Context context = new InitialContext();

	    try {
			obj = context.lookup(DaoConstants.DAISI_JNDI_NAME);
		} catch (Exception e) {
			LOGGER.error("Unable to get JNDI datasoure:" + DaoConstants.DAISI_JNDI_NAME);
			return null;
		}

	    return (DataSource) obj;
	}
}

