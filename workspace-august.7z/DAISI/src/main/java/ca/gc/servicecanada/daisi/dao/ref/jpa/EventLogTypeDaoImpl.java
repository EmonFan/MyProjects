package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.EventLogTypeDao;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;

@Component
public class EventLogTypeDaoImpl implements EventLogTypeDao {

	private Logger LOGGER = LogManager.getLogger(getClass());

	private final static String SELECT_ALL_EVENT_LOG_TYPE = "SELECT e FROM EventLogType e";
	
	private final static String FIND_EVENT_LOG_BY_CODE = "SELECT e FROM EventLogType e WHERE e.eventLogTypeCode = :eventLogTypeCode";

	//--------------- FIND BY ABRV ----------------
	private final static String FIND_EVENT_LOG_BY_CODE_ABRV_EN = "SELECT e FROM EventLogType e WHERE e.eventLogTypeAbrvEn = :eventLogTypeAbrvEn";
	private final static String FIND_EVENT_LOG_BY_CODE_ABRV_FR = "SELECT e FROM EventLogType e WHERE e.eventLogTypeAbrvFr = :eventLogTypeAbrvFr";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public List<EventLogType> getAllEventLogType() {
		TypedQuery<EventLogType> query = entityManager.createQuery(SELECT_ALL_EVENT_LOG_TYPE, EventLogType.class);
		LOGGER.debug("DAISI-JPA: getAllEventLogType");
		return query.getResultList();
	}

	public EventLogType findEventLogTypeByID(int id) {
		EventLogType data = null;
		LOGGER.debug("DAISI-JPA: findEventLogTypeByID: " + id);
		data = (EventLogType) entityManager.find(EventLogType.class, id);
		return data;
	}

	public EventLogType findEventLogTypeByCode(String code) {
		TypedQuery<EventLogType> query = entityManager.createQuery(FIND_EVENT_LOG_BY_CODE, EventLogType.class);
		LOGGER.debug("DAISI-JPA: findEventLogTypeByCode: " + code);
		query.setParameter("eventLogTypeCode", code);
		EventLogType data = query.getSingleResult();
		return data;
	}

	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv) {
		//English abbreviation by default
		return findEventLogTypeByAbrv(eventLogTypeAbrv, DaoConstants.LANG_EN); 
	}

	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv, String languageCode) {
		LOGGER.debug("DAISI-JPA: findEventLogTypeByAbrv: " + eventLogTypeAbrv + " + " + languageCode);
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<EventLogType> query = entityManager.createQuery(FIND_EVENT_LOG_BY_CODE_ABRV_EN, EventLogType.class);
			query.setParameter("eventLogTypeAbrvEn", eventLogTypeAbrv);
			EventLogType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<EventLogType> query = entityManager.createQuery(FIND_EVENT_LOG_BY_CODE_ABRV_FR, EventLogType.class);
			query.setParameter("eventLogTypeAbrvFr", eventLogTypeAbrv);
			EventLogType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	public int createEventLogType(EventLogType data) {
		LOGGER.debug("DAISI-JPA: createEventLogType: " + data.getEventLogTypeAbrvEn());
		entityManager.persist(data);
		entityManager.flush();
		return data.getEventLogTypeID();
	}

}
