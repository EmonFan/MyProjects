package ca.gc.servicecanada.daisi.controller.rest;

import java.util.List;

import javax.annotation.Resource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ca.gc.servicecanada.daisi.dao.ref.ConsentStatementDao;
import ca.gc.servicecanada.daisi.dao.ref.ProgramServiceDao;
import ca.gc.servicecanada.daisi.dao.ref.StatusDao;
import ca.gc.servicecanada.daisi.dao.ref.TransactionTypeDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.service.DaisiTransactionDataService;
import ca.gc.servicecanada.daisi.service.json.JsonSerializer;

@RestController
@RequestMapping("/DaisiTransactionData")
public class DaisiTransactionDataRestService {

	private Logger LOGGER = LogManager.getLogger(getClass());

	@Resource
	private JsonSerializer jsonSerializer;

	@Resource
	private DaisiTransactionDataService trxService;

	@Resource
	ConsentStatementDao consentDao;
	@Resource
	ProgramServiceDao referenceDao;
	@Resource
	TransactionTypeDao trxTypeDao;

	@Resource
	StatusDao statusDao;

	@RequestMapping(value = { "/BusinessTransactions/{sin}" }, method = RequestMethod.GET)
	@ResponseBody
	public String findBusinessTransactionsBySin(@PathVariable String sin) {
		LOGGER.debug("lookup for transactions for SIN ***" + sin.substring(3));
		List<BusinessTransaction> data = trxService.findBusinessTransactionsBySin(sin);
		String json = jsonSerializer.serialize(data);
		return json;
	}

}
