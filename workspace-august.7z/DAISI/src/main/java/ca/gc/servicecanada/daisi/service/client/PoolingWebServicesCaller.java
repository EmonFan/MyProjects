package ca.gc.servicecanada.daisi.service.client;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class PoolingWebServicesCaller implements WebServicesCaller{

	private Logger LOGGER = LogManager.getLogger(getClass());

	private HttpClient httpClient;

	private String url;

	public PoolingWebServicesCaller() {
		httpClient = HttpClientBuilder.create().build();
	}

	/** request is a REST url */
	public String executeGet(String request) {
		LOGGER.debug("preparing REST call to "+request);
		String response = null;
		url = request;
		HttpUriRequest httpRequest = new HttpGet(url);
		response = executeRequest(httpRequest);
		return response;
	}

	public String executePost(String request) {
		String response = null;
		HttpUriRequest httpRequest = new HttpPost(url);
		response = executeRequest(httpRequest);
		return response;

	}

	String executeRequest(HttpUriRequest httpRequest) {
		String response = null;
		try {
			HttpResponse httpResponse = httpClient.execute(httpRequest);
			HttpEntity entity = httpResponse.getEntity();

			if (entity != null) {
				response = EntityUtils.toString(entity);
			}
			int httpCode = httpResponse.getStatusLine().getStatusCode();
			if (httpCode < 200 || httpCode >= 300) {
				LOGGER.info("" + response);
				// LOGGER.error(response);
				String errMsg = handleError(response);
				throw new RuntimeException(errMsg);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			// LOGGER.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		} finally {
			// FIXME:
			// httpRequest.releaseConnection();
		}

		return response;

	}

	static final String FAULT_CODE_START = "<faultcode>";
	static final String FAULT_CODE_END = "</faultcode>";
	static final String FAULT_STRING_START = "<faultstring>";
	static final String FAULT_STRING_END = "</faultstring>";

	String handleError(String response) {
		String code = "";
		String faultstring = "";
		try {
			code = response.substring(response.indexOf(FAULT_CODE_START) + FAULT_CODE_START.length(),
					response.indexOf(FAULT_CODE_END));
			faultstring = response.substring(response.indexOf(FAULT_STRING_START) + FAULT_STRING_START.length(),
					response.indexOf(FAULT_STRING_END));
		} catch (Exception e) {
		}
		StringBuilder b = new StringBuilder();
		b.append("[ ");
		b.append(code);
		b.append(" ],  ");
		b.append("\n");
		b.append(faultstring);
		return b.toString();

	}

}
