package ca.gc.servicecanada.daisi.service.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomDateSerializer extends JsonSerializer<Date>
{

  // private static DateTimeFormatter formatter =
  // DateTimeFormat.forPattern("dd-MM-yyyy");

  private final String pattern = "dd-MM-yyyy HH:mm:ss";

  private final SimpleDateFormat format = new SimpleDateFormat(pattern);

  @Override
  public void serialize(final Date date, final JsonGenerator gen, final SerializerProvider arg2)
      throws IOException, JsonProcessingException
  {
    final String stringDate = format.format(date);

    gen.writeString(stringDate);
  }
}
