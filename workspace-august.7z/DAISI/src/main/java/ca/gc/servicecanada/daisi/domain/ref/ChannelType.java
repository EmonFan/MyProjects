package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_CHANNEL_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ChannelType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "CHANNEL_TYPE_ID")
  private int channelTypeID;

  @Column(name = "CHANNEL_TYPE_CODE")
  private String channelTypeCode;

  @Column(name = "CHANNEL_TYPE_NAME_EN", length = 50)
  private String channelTypeNameEn;

  @Column(name = "CHANNEL_TYPE_NAME_FR", length = 50)
  private String channelTypeNameFr;

  @Column(name = "CHANNEL_TYPE_DESC_EN", length = 2000)
  private String channelTypeDescEn;

  @Column(name = "CHANNEL_TYPE_DESC_FR", length = 2000)
  private String channelTypeDescFr;

  @Column(name = "CHANNEL_TYPE_ABRV_EN", length = 10)
  private String channelTypeAbrvEn;

  @Column(name = "CHANNEL_TYPE_ABRV_FR", length = 10)
  private String channelTypeAbrvFr;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  private Date effectiveDate;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  private Date expiryDate;

  public int getChannelTypeID()
  {
    return channelTypeID;
  }

  public void setChannelTypeID(final int channelTypeID)
  {
    this.channelTypeID = channelTypeID;
  }

  public String getChannelTypeCode()
  {
    return channelTypeCode;
  }

  public void setChannelTypeCode(final String channelTypeCode)
  {
    this.channelTypeCode = channelTypeCode;
  }

  public String getChannelTypeNameEn()
  {
    return channelTypeNameEn;
  }

  public void setChannelTypeNameEn(final String channelTypeNameEn)
  {
    this.channelTypeNameEn = channelTypeNameEn;
  }

  public String getChannelTypeNameFr()
  {
    return channelTypeNameFr;
  }

  public void setChannelTypeNameFr(final String channelTypeNameFr)
  {
    this.channelTypeNameFr = channelTypeNameFr;
  }

  public String getChannelTypeDescEn()
  {
    return channelTypeDescEn;
  }

  public void setChannelTypeDescEn(final String channelTypeDescEn)
  {
    this.channelTypeDescEn = channelTypeDescEn;
  }

  public String getChannelTypeDescFr()
  {
    return channelTypeDescFr;
  }

  public void setChannelTypeDescFr(final String channelTypeDescFr)
  {
    this.channelTypeDescFr = channelTypeDescFr;
  }

  public String getChannelTypeAbrvEn()
  {
    return channelTypeAbrvEn;
  }

  public void setChannelTypeAbrvEn(final String channelTypeAbrvEn)
  {
    this.channelTypeAbrvEn = channelTypeAbrvEn;
  }

  public String getChannelTypeAbrvFr()
  {
    return channelTypeAbrvFr;
  }

  public void setChannelTypeAbrvFr(final String channelTypeAbrvFr)
  {
    this.channelTypeAbrvFr = channelTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("ChannelType [");
    builder.append(channelTypeID);
    builder.append(", ");
    builder.append(channelTypeNameEn);
    builder.append(", ");
    builder.append(channelTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>



		CHANNEL_TYPE_CODE VARCHAR2(3) NOT NULL,
		CHANNEL_TYPE_NAME_EN VARCHAR2(50),
		CHANNEL_TYPE_NAME_FR VARCHAR2(50),
		CHANNEL_TYPE_DESC_EN VARCHAR2(2000),
		CHANNEL_TYPE_DESC_FR VARCHAR2(2000),
		CHANNEL_TYPE_ABRV_EN VARCHAR2(10),
		CHANNEL_TYPE_ABRV_FR VARCHAR2(10),
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30) NOT NULL,
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE CD_CHANNEL_TYPE ADD CONSTRAINT CHNLTP_UK UNIQUE (CHANNEL_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE CD_CHANNEL_TYPE ADD CONSTRAINT CHNLTP_UK2 UNIQUE (CHANNEL_TYPE_NAME_EN, EXPIRY_DATE);

ALTER TABLE CD_CHANNEL_TYPE ADD CONSTRAINT CHNLTP_UK3 UNIQUE (CHANNEL_TYPE_NAME_FR, EXPIRY_DATE);

ALTER TABLE CD_CHANNEL_TYPE ADD CONSTRAINT CHNLTP_PK PRIMARY KEY (CHANNEL_TYPE_ID);


</code>
 */