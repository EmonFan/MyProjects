package ca.gc.servicecanada.daisi.service.json;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ca.gc.servicecanada.daisi.service.DaisiDataSerializerStrategy;

@Component
public class JsonSerializer implements DaisiDataSerializerStrategy {

	private Logger LOGGER = LogManager.getLogger(getClass());

	private ObjectMapper objectMapper = new ObjectMapper();

	public JsonSerializer() {
		// objectMapper.registerModule(new JodaModule());
	}

	public String serialize(Object data) {
		String json;
		try {
			json = objectMapper.writeValueAsString(data);
		} catch (JsonProcessingException e) {
			LOGGER.error(e);
			throw new RuntimeException(e);
		}
		LOGGER.debug(json);
		return json;
	}

}
