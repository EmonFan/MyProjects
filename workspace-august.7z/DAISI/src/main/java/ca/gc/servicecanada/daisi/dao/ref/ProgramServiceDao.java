package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

public interface ProgramServiceDao {

	// ------- ProgramServiceType

	List<ProgramServiceType> getAllProgramServiceType();

	ProgramServiceType findDaisiProgramServiceTypeByID(int id);

	ProgramServiceType findDaisiProgramServiceTypeByCode(String code);

	public ProgramServiceType findDaisiProgramServiceTypeByAbrv(String abrv);
	
	public ProgramServiceType findDaisiProgramServiceTypeByAbrv(String abrv, String languageCode);
	
	int createProgramServiceType(ProgramServiceType data);

	// ------- OrganizationType

	List<OrganizationType> getAllOrganizationType();

	OrganizationType findOrganizationTypeByID(int id);

	OrganizationType findOrganizationTypeByCode(String code);

	public OrganizationType findOrganizationTypeByAbrv(String abrv);
	
	public OrganizationType findOrganizationTypeByAbrv(String abrv, String languageCode);

	int createOrganizationType(OrganizationType data);
}
