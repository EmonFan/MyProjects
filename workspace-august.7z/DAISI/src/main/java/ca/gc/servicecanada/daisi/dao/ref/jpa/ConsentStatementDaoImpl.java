package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.ConsentStatementDao;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;

@Component
public class ConsentStatementDaoImpl implements ConsentStatementDao {

	private final static String SELECT_ALL_CONSENT_TYPE = "SELECT e FROM ConsentStatementType e";
	private final static String SELECT_ALL_CHANNEL_TYPE = "SELECT e FROM ChannelType e";

	//--------------- FIND BY CODE ---------------- 
	private final static String FIND_CONSENT_BY_CODE = "SELECT e FROM ConsentStatementType e WHERE e.consentStatementTypeCode = :consentStatementTypeCode";
	private final static String FIND_CHANNEL_BY_CODE = "SELECT e FROM ChannelType e WHERE e.channelTypeCode = :channelTypeCode";

	//--------------- FIND BY ABRV ----------------
	private final static String FIND_CONSENT_BY_ABRV_EN = "SELECT e FROM ConsentStatementType e WHERE e.consentStatementTypeAbrvEn = :consentStatementTypeAbrvEn";
	private final static String FIND_CONSENT_BY_ABRV_FR = "SELECT e FROM ConsentStatementType e WHERE e.consentStatementTypeAbrvFr = :consentStatementTypeAbrvFr";

	private final static String FIND_CHANNEL_BY_ABRV_EN = "SELECT e FROM ChannelType e WHERE e.channelTypeAbrvEn = :channelTypeAbrvEn";
	private final static String FIND_CHANNEL_BY_ABRV_FR = "SELECT e FROM ChannelType e WHERE e.channelTypeAbrvFr = :channelTypeAbrvFr";
	
	//--------------- FIND ABRV ----------------
	private final static String FIND_CONSENT_TYPE_BY_CHANNEL_CONSENT_CODE = "SELECT e FROM ConsentStatementType e "
			+ "WHERE e.channelType = (select channelTypeID FROM ChannelType WHERE channelTypeNameEn = :channelType) and e.consentCode = :consentCode";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public List<ChannelType> getAllChannelType() {
		TypedQuery<ChannelType> query = entityManager.createQuery(SELECT_ALL_CHANNEL_TYPE, ChannelType.class);
		return query.getResultList();
	}

	public ChannelType findChannelTypeByID(int id) {
		ChannelType data = null;
		data = (ChannelType) entityManager.find(ChannelType.class, id);
		return data;
	}

	public int createChannelType(ChannelType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getChannelTypeID();
	}

	public List<ConsentStatementType> getAllConsentStatementType() {
		TypedQuery<ConsentStatementType> query = entityManager.createQuery(SELECT_ALL_CONSENT_TYPE,
				ConsentStatementType.class);
		return query.getResultList();
	}

	public ConsentStatementType findConsentStatementTypeByID(int id) {
		ConsentStatementType data = null;
		data = (ConsentStatementType) entityManager.find(ConsentStatementType.class, id);
		return data;
	}

	public ConsentStatementType findConsentStatementTypeByCode(String consentStatementTypeCode) {

		TypedQuery<ConsentStatementType> query = entityManager.createQuery(FIND_CONSENT_BY_CODE,
				ConsentStatementType.class);
		query.setParameter("consentStatementTypeCode", consentStatementTypeCode);
		ConsentStatementType data = query.getSingleResult();
		return data;
	}

	// Find by abbreviation
	public ConsentStatementType findConsentStatementTypeByAbrv(String consentStatementTypeAbrv) {
		//English abbreviation by default
		return findConsentStatementTypeByAbrv(consentStatementTypeAbrv, DaoConstants.LANG_EN); 
	}

	public ConsentStatementType findConsentStatementTypeByAbrv(String consentStatementTypeAbrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<ConsentStatementType> query = entityManager.createQuery(FIND_CONSENT_BY_ABRV_EN,
					ConsentStatementType.class);
			query.setParameter("consentStatementTypeAbrvEn", consentStatementTypeAbrv);
			ConsentStatementType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<ConsentStatementType> query = entityManager.createQuery(FIND_CONSENT_BY_ABRV_FR,
					ConsentStatementType.class);
			query.setParameter("consentStatementTypeAbrvFr", consentStatementTypeAbrv);
			ConsentStatementType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	public int createConsentStatementType(ConsentStatementType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getConsentStatementTypeID();

	}

	public ChannelType findChannelTypeByCode(String channelTypeCode) {
		TypedQuery<ChannelType> query = entityManager.createQuery(FIND_CHANNEL_BY_CODE, ChannelType.class);
		query.setParameter("channelTypeCode", channelTypeCode);
		ChannelType data = query.getSingleResult();
		return data;
	}

	public ChannelType findChannelTypeByAbrv(String channelTypeAbrv) {
		//English abbreviation by default
		return findChannelTypeByAbrv(channelTypeAbrv, DaoConstants.LANG_EN); 
	}

	public ChannelType findChannelTypeByAbrv(String channelTypeAbrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<ChannelType> query = entityManager.createQuery(FIND_CHANNEL_BY_ABRV_EN,
					ChannelType.class);
			query.setParameter("channelTypeAbrvEn", channelTypeAbrv);
			ChannelType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<ChannelType> query = entityManager.createQuery(FIND_CHANNEL_BY_ABRV_FR,
					ChannelType.class);
			query.setParameter("channelTypeAbrvFr", channelTypeAbrv);
			ChannelType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	@Override
	public String findConsentStatementTypeAbrv(String channelType, String consentCode) {
		TypedQuery<ConsentStatementType> query = entityManager.createQuery(FIND_CONSENT_TYPE_BY_CHANNEL_CONSENT_CODE,
				ConsentStatementType.class);
		query.setParameter("channelType", channelType);
		query.setParameter("consentCode", consentCode);
		ConsentStatementType data = query.getSingleResult();
		return data.getConsentStatementTypeAbrvEn();
	}
}
