package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "TRANSACTION_MESSAGE")
public class TransactionMessage extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "TRANSACTION_MESSAGE_ID")
  private int transactionMessageID;

  // private int transactionID; // this is covered off in the
  // systemtransaction var above

  @ManyToOne(targetEntity = TechnicalTransaction.class, fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "TECHNICAL_TRANS_ID", nullable = true, updatable = false)
  private TechnicalTransaction technicalTransaction;

  @Column(name = "MESSAGE_ID")
  private String messageID;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "MESSAGE_DATE_TIME")
  private Date messageDateTime;

  // ------------ COMMON AUDIT FIELDS ---------------

  public TechnicalTransaction getTechnicalTransaction()
  {
    return technicalTransaction;
  }

  public void setTechnicalTransaction(final TechnicalTransaction technicalTrans)
  {
    technicalTransaction = technicalTrans;
  }

  public int getTransactionMessageID()
  {
    return transactionMessageID;
  }

  public void setTransactionMessageID(final int transactionMessageID)
  {
    this.transactionMessageID = transactionMessageID;
  }

  public String getMessageID()
  {
    return messageID;
  }

  public void setMessageID(final String messageID)
  {
    this.messageID = messageID;
  }

  public Date getMessageDateTime()
  {
    return messageDateTime;
  }

  public void setMessageDateTime(final Date messageDateTime)
  {
    this.messageDateTime = messageDateTime;
  }

  @Override
  public String toString()
  {
    return "TransactionMessage [transactionMessageID=" + transactionMessageID
        + ", technicalTransaction=" + technicalTransaction + ", messageID=" + messageID
        + ", messageDateTime=" + messageDateTime + "]";
  }

}
