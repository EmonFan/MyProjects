package ca.gc.servicecanada.daisi.service.client;

public interface WebServicesCaller {

	String executeGet(String request);

	String executePost(String request);

}
