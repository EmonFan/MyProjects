package ca.gc.servicecanada.daisi.dao.ref;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;

public interface RejectReasonDao {
	
	// ------------- RejectReasonType ----------
	List<RejectReasonType> getAllRejectReasonType();

	RejectReasonType findRejectReasonTypeByID(int id);

	int createRejectReasonType(RejectReasonType data);

	RejectReasonType findRejectReasonTypeByAbrv(String code);

	RejectReasonType findRejectReasonTypeByAbrv(String code, String languageCode);
	
	RejectReasonType findRejectReasonTypeByextErnalCode(String externalCode);

}
