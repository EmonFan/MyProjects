package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

// @XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "TECHNICAL_TRANS")
public class TechnicalTransaction extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TCHNLTRN_SEQ")
  @SequenceGenerator(name = "TCHNLTRN_SEQ", sequenceName = "TCHNLTRN_SEQ")
  @Column(name = "TECHNICAL_TRANS_ID")
  private int transactionID;

  @XmlTransient // to avoid an infinite loop: DDBusinessTransaction
  @JsonBackReference
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "BUSINESS_TRANS_ID", nullable = true, updatable = false)
  private BusinessTransaction businessTransaction;

  @JsonManagedReference
  @OneToMany(mappedBy = "technicalTransaction", fetch = FetchType.EAGER)
  private List<EventLog> eventLogs;

  @Column(name = "TECHNICAL_TRANSACTION_ID")
  private String technicalTransactionID;

  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "TECHNICAL_TRANSACTION_DATE")
  private Date technicalTransactionDate;

  public int getTransactionID()
  {
    return transactionID;
  }

  public void setTransactionID(final int transactionID)
  {
    this.transactionID = transactionID;
  }

  public BusinessTransaction getBusinessTransaction()
  {
    return businessTransaction;
  }

  public void setBusinessTransaction(final BusinessTransaction businessTransaction)
  {
    this.businessTransaction = businessTransaction;
  }

  public String getTechnicalTransactionID()
  {
    return technicalTransactionID;
  }

  public void setTechnicalTransactionID(final String technicalTransactionID)
  {
    this.technicalTransactionID = technicalTransactionID;
  }

  public Date getTechnicalTransactionDate()
  {
    return technicalTransactionDate;
  }

  public void setTechnicalTransactionDate(final Date technicalTransactionDate)
  {
    this.technicalTransactionDate = technicalTransactionDate;
  }

  public List<EventLog> getEventLogs()
  {
    return eventLogs;
  }

  public void setEventLogs(final List<EventLog> eventLogs)
  {
    this.eventLogs = eventLogs;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("SystemTransaction [transactionID=");
    builder.append(transactionID);
    builder.append(", technicalTransactionID=");
    builder.append(technicalTransactionID);
    builder.append(", technicalTransactionDate=");
    builder.append(technicalTransactionDate);

    return builder.toString();
  }

}

/**
 * <code>


--------------------------------------------------------
--  DDL for Table TECHNICAL_TRANS
--------------------------------------------------------

  CREATE TABLE "EXTOWNRE9"."TECHNICAL_TRANS"
   (	"TECHNICAL_TRANS_ID" NUMBER(12,0),
	"BUSINESS_TRANSACTION_ID" NUMBER(12,0),
	"TECHNICAL_TRANSACTION_ID" VARCHAR2(50 BYTE),
	"TECHNICAL_TRANSACTION_DATE" DATE,
	"DATE_CREATED" DATE,
	"SYSTEM_CREATED" VARCHAR2(30 BYTE),
	"USER_CREATED" VARCHAR2(30 BYTE),
	"DATE_UPDATED" DATE,
	"USER_UPDATED" VARCHAR2(30 BYTE)
   ) SEGMENT CREATION DEFERRED
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  DDL for Index TCHNLTRN_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "EXTOWNRE9"."TCHNLTRN_PK" ON "EXTOWNRE9"."TECHNICAL_TRANS" ("TECHNICAL_TRANS_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  DDL for Index TCHNLTRN_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "EXTOWNRE9"."TCHNLTRN_UK" ON "EXTOWNRE9"."TECHNICAL_TRANS" ("BUSINESS_TRANSACTION_ID", "TECHNICAL_TRANSACTION_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  Constraints for Table TECHNICAL_TRANS
--------------------------------------------------------

  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" ADD CONSTRAINT "TCHNLTRN_UK" UNIQUE ("BUSINESS_TRANSACTION_ID", "TECHNICAL_TRANSACTION_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA"  ENABLE;
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" ADD CONSTRAINT "TCHNLTRN_PK" PRIMARY KEY ("TECHNICAL_TRANS_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA"  ENABLE;
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" MODIFY ("USER_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" MODIFY ("SYSTEM_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" MODIFY ("DATE_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" MODIFY ("TECHNICAL_TRANSACTION_ID" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" MODIFY ("BUSINESS_TRANSACTION_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table TECHNICAL_TRANS
--------------------------------------------------------

  ALTER TABLE "EXTOWNRE9"."TECHNICAL_TRANS" ADD CONSTRAINT "BSNSTRNS_TCHNLTRN_FK" FOREIGN KEY ("BUSINESS_TRANSACTION_ID")
	  REFERENCES "EXTOWNRE9"."BUSINESS_TRANS" ("BUSINESS_TRANS_ID") ENABLE;


</code>
 */