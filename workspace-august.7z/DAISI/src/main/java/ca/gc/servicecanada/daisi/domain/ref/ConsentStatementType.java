package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_CONSENT_STATEMENT_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ConsentStatementType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "CONSENT_STATEMENT_TYPE_ID")
  private int consentStatementTypeID;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "CHANNEL_TYPE_ID", nullable = false, updatable = false)
  private ChannelType channelType;

  @Column(name = "CONSENT_STATEMENT_TYPE_CODE")
  private String consentStatementTypeCode;

  @Column(name = "CONSENT_STATEMENT_TYPE_NAME_EN", length = 50)
  private String consentStatementTypeNameEn;

  @Column(name = "CONSENT_STATEMENT_TYPE_NAME_FR", length = 50)
  private String consentStatementTypeNameFr;

  @Column(name = "CONSENT_STATEMENT_TYPE_DESC_EN", length = 2000)
  private String consentStatementTypeDescEn;

  @Column(name = "CONSENT_STATEMENT_TYPE_DESC_FR", length = 2000)
  private String consentStatementTypeDescFr;

  @Column(name = "CONSENT_STATEMENT_TYPE_ABRV_EN", length = 10)
  private String consentStatementTypeAbrvEn;

  @Column(name = "CONSENT_STATEMENT_TYPE_ABRV_FR", length = 10)
  private String consentStatementTypeAbrvFr;

  @Column(name = "CONSENT_STATEMENT_TYPE_YEAR")
  private String consentStatementTypeYear;

  @Column(name = "CONSENT_STATEMENT_TYPE_VERSION")
  private String consentStatementTypeVersion;

  @Column(name = "CONSENT_CODE")
  private String consentCode;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  private Date effectiveDate;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  private Date expiryDate;

  public int getConsentStatementTypeID()
  {
    return consentStatementTypeID;
  }

  public void setConsentStatementTypeID(final int consentStatementTypeID)
  {
    this.consentStatementTypeID = consentStatementTypeID;
  }

  public ChannelType getChannelType()
  {
    return channelType;
  }

  public void setChannelType(final ChannelType channelType)
  {
    this.channelType = channelType;
  }

  public String getConsentStatementTypeCode()
  {
    return consentStatementTypeCode;
  }

  public void setConsentStatementTypeCode(final String consentStatementTypeCode)
  {
    this.consentStatementTypeCode = consentStatementTypeCode;
  }

  public String getConsentStatementTypeNameEn()
  {
    return consentStatementTypeNameEn;
  }

  public void setConsentStatementTypeNameEn(final String consentStatementTypeNameEn)
  {
    this.consentStatementTypeNameEn = consentStatementTypeNameEn;
  }

  public String getConsentStatementTypeNameFr()
  {
    return consentStatementTypeNameFr;
  }

  public void setConsentStatementTypeNameFr(final String consentStatementTypeNameFr)
  {
    this.consentStatementTypeNameFr = consentStatementTypeNameFr;
  }

  public String getConsentStatementTypeDescEn()
  {
    return consentStatementTypeDescEn;
  }

  public void setConsentStatementTypeDescEn(final String consentStatementTypeDescEn)
  {
    this.consentStatementTypeDescEn = consentStatementTypeDescEn;
  }

  public String getConsentStatementTypeDescFr()
  {
    return consentStatementTypeDescFr;
  }

  public void setConsentStatementTypeDescFr(final String consentStatementTypeDescFr)
  {
    this.consentStatementTypeDescFr = consentStatementTypeDescFr;
  }

  public String getConsentStatementTypeAbrvEn()
  {
    return consentStatementTypeAbrvEn;
  }

  public void setConsentStatementTypeAbrvEn(final String consentStatementTypeAbrvEn)
  {
    this.consentStatementTypeAbrvEn = consentStatementTypeAbrvEn;
  }

  public String getConsentStatementTypeAbrvFr()
  {
    return consentStatementTypeAbrvFr;
  }

  public void setConsentStatementTypeAbrvFr(final String consentStatementTypeAbrvFr)
  {
    this.consentStatementTypeAbrvFr = consentStatementTypeAbrvFr;
  }

  public String getConsentStatementTypeYear()
  {
    return consentStatementTypeYear;
  }

  public void setConsentStatementTypeYear(final String consentStatementTypeYear)
  {
    this.consentStatementTypeYear = consentStatementTypeYear;
  }

  public String getConsentStatementTypeVersion()
  {
    return consentStatementTypeVersion;
  }

  public void setConsentStatementTypeVersion(final String consentStatementTypeVersion)
  {
    this.consentStatementTypeVersion = consentStatementTypeVersion;
  }

  public String getConsentCode()
  {
    return consentCode;
  }

  public void setConsentCode(final String consentCode)
  {
    this.consentCode = consentCode;
  }

  // -------
  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("ConsentStatementType [");
    builder.append(consentStatementTypeID);
    builder.append(", ");
    builder.append(channelType);
    builder.append(", ");
    builder.append(consentStatementTypeCode);
    builder.append(", ");
    builder.append(consentStatementTypeAbrvEn);
    builder.append(", ");
    builder.append(consentStatementTypeYear);
    builder.append(", ");
    builder.append(consentStatementTypeVersion);
    builder.append(", ");
    builder.append(consentCode);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>


CREATE TABLE CD_CONSENT_STATEMENT_TYPE (
		CONSENT_STATEMENT_TYPE_ID NUMBER(12 , 0) NOT NULL,
		CHANNEL_TYPE_ID NUMBER(12 , 0) NOT NULL,
		CONSENT_STATEMENT_TYPE_CODE VARCHAR2(3) NOT NULL,
		CONSENT_STATEMENT_TYPE_NAME_EN VARCHAR2(50),
		CONSENT_STATEMENT_TYPE_NAME_FR VARCHAR2(50),
		CONSENT_STATEMENT_TYPE_DESC_EN VARCHAR2(4000),
		CONSENT_STATEMENT_TYPE_DESC_FR VARCHAR2(4000),
		CONSENT_STATEMENT_TYPE_ABRV_EN VARCHAR2(10),
		CONSENT_STATEMENT_TYPE_ABRV_FR VARCHAR2(10),
		CONSENT_STATEMENT_TYPE_YEAR VARCHAR2(2) NOT NULL,
		CONSENT_STATEMENT_TYPE_VERSION VARCHAR2(2) NOT NULL,
		CONSENT_CODE VARCHAR2(12) NOT NULL,
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30),
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE CD_CONSENT_STATEMENT_TYPE ADD CONSTRAINT CNSSTMTP_UK UNIQUE (CONSENT_STATEMENT_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE CD_CONSENT_STATEMENT_TYPE ADD CONSTRAINT CNSSTMTP_PK PRIMARY KEY (CONSENT_STATEMENT_TYPE_ID);

ALTER TABLE CD_CONSENT_STATEMENT_TYPE ADD CONSTRAINT CNSSTMTP_UK3 UNIQUE (CONSENT_STATEMENT_TYPE_NAME_FR, EXPIRY_DATE);

ALTER TABLE CD_CONSENT_STATEMENT_TYPE ADD CONSTRAINT CNSSTMTP_UK2 UNIQUE (CONSENT_STATEMENT_TYPE_NAME_EN, EXPIRY_DATE);

ALTER TABLE CD_CONSENT_STATEMENT_TYPE ADD CONSTRAINT CHNLTP_CNSSTMTP_FK FOREIGN KEY (CHANNEL_TYPE_ID)
	REFERENCES CD_CHANNEL_TYPE (CHANNEL_TYPE_ID);


</code>
 */
