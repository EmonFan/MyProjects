package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_ORGANIZATION_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class OrganizationType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ORGANIZATION_TYPE_ID")
  private int organizationTypeID;

  @Column(name = "ORGANIZATION_TYPE_CODE")
  private String organizationTypeCode;

  @Column(name = "ORGANIZATION_TYPE_NAME_EN")
  private String organizationTypeNameEn;

  @Column(name = "ORGANIZATION_TYPE_NAME_FR")
  private String organizationTypeNameFr;

  @Column(name = "ORGANIZATION_TYPE_DESC_EN")
  private String organizationTypeDescEn;

  @Column(name = "ORGANIZATION_TYPE_DESC_FR")
  private String organizationTypeDescFr;

  @Column(name = "ORGANIZATION_TYPE_ABRV_EN")
  private String organizationTypeAbrvEn;

  @Column(name = "ORGANIZATION_TYPE_ABRV_FR")
  private String organizationTypeAbrvFr;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getOrganizationTypeID()
  {
    return organizationTypeID;
  }

  public void setOrganizationTypeID(final int organizationTypeID)
  {
    this.organizationTypeID = organizationTypeID;
  }

  public String getOrganizationTypeCode()
  {
    return organizationTypeCode;
  }

  public void setOrganizationTypeCode(final String organizationTypeCode)
  {
    this.organizationTypeCode = organizationTypeCode;
  }

  public String getOrganizationTypeNameEn()
  {
    return organizationTypeNameEn;
  }

  public void setOrganizationTypeNameEn(final String organizationTypeNameEn)
  {
    this.organizationTypeNameEn = organizationTypeNameEn;
  }

  public String getOrganizationTypeNameFr()
  {
    return organizationTypeNameFr;
  }

  public void setOrganizationTypeNameFr(final String organizationTypeNameFr)
  {
    this.organizationTypeNameFr = organizationTypeNameFr;
  }

  public String getOrganizationTypeDescEn()
  {
    return organizationTypeDescEn;
  }

  public void setOrganizationTypeDescEn(final String organizationTypeDescEn)
  {
    this.organizationTypeDescEn = organizationTypeDescEn;
  }

  public String getOrganizationTypeDescFr()
  {
    return organizationTypeDescFr;
  }

  public void setOrganizationTypeDescFr(final String organizationTypeDescFr)
  {
    this.organizationTypeDescFr = organizationTypeDescFr;
  }

  public String getOrganizationTypeAbrvEn()
  {
    return organizationTypeAbrvEn;
  }

  public void setOrganizationTypeAbrvEn(final String organizationTypeAbrvEn)
  {
    this.organizationTypeAbrvEn = organizationTypeAbrvEn;
  }

  public String getOrganizationTypeAbrvFr()
  {
    return organizationTypeAbrvFr;
  }

  public void setOrganizationTypeAbrvFr(final String organizationTypeAbrvFr)
  {
    this.organizationTypeAbrvFr = organizationTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("OrganizationType [");
    builder.append(organizationTypeID);
    builder.append(", ");
    builder.append(organizationTypeNameEn);
    builder.append(", ");
    builder.append(organizationTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE CD_ORGANIZATION_TYPE (
		ORGANIZATION_TYPE_ID NUMBER(12 , 0) NOT NULL,
		ORGANIZATION_TYPE_CODE VARCHAR2(3) NOT NULL,
		ORGANIZATION_TYPE_NAME_EN VARCHAR2(50),
		ORGANIZATION_TYPE_NAME_FR VARCHAR2(50),
		ORGANIZATION_TYPE_DESC_EN VARCHAR2(2000),
		ORGANIZATION_TYPE_DESC_FR VARCHAR2(2000),
		ORGANIZATION_TYPE_ABRV_EN VARCHAR2(10),
		ORGANIZATION_TYPE_ABRV_FR VARCHAR2(10),
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30) NOT NULL,
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE CD_ORGANIZATION_TYPE ADD CONSTRAINT ORGTP_UK2 UNIQUE (ORGANIZATION_TYPE_NAME_EN, EXPIRY_DATE);

ALTER TABLE CD_ORGANIZATION_TYPE ADD CONSTRAINT ORGTP_UK UNIQUE (ORGANIZATION_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE CD_ORGANIZATION_TYPE ADD CONSTRAINT ORGTP_UK3 UNIQUE (ORGANIZATION_TYPE_NAME_FR, EXPIRY_DATE);

ALTER TABLE CD_ORGANIZATION_TYPE ADD CONSTRAINT ORGTP_PK PRIMARY KEY (ORGANIZATION_TYPE_ID);

</code>
 */