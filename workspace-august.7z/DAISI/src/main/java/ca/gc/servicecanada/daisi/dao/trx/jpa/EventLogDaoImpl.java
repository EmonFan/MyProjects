package ca.gc.servicecanada.daisi.dao.trx.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.trx.EventLogDao;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;
import ca.gc.servicecanada.daisi.domain.trx.EventLog_;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction_;

@Component
public class EventLogDaoImpl implements EventLogDao {

	private Logger LOGGER = LogManager.getLogger(getClass());

	// for testing only
	private final static String SELECT_ALL_LOGS = "SELECT e FROM EventLog e";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	@Override
	public List<EventLog> findEventLogByTransactionID(int trxId) {
		LOGGER.debug("lookup for LogEvents for SYSTEM_TRANSACTION_ID = " + trxId);
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<EventLog> query = criteriaBuilder.createQuery(EventLog.class);
		Root<EventLog> root = query.from(EventLog.class);
		Join<EventLog, TechnicalTransaction> join = root.join(EventLog_.technicalTransaction);
		query.where(criteriaBuilder.equal(join.get(TechnicalTransaction_.transactionID), trxId));
		query.select(root);
		List<EventLog> data = entityManager.createQuery(query).getResultList();

		return data;
	}

	@Override
	public List<EventLog> findEventLogBySin(String SIN) {
		// TODO Auto-generated method stub
		return null;
	}

	// for testing only
	@Override
	public List<EventLog> getAllEventLogs() {
		TypedQuery<EventLog> query = entityManager.createQuery(SELECT_ALL_LOGS, EventLog.class);
		return query.getResultList();

	}

	@Override
	public void createEventLog(EventLog event) {
		entityManager.persist(event);
		int id = event.getId();
	}

}
