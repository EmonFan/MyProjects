package ca.gc.servicecanada.daisi.constants;

public final class DaoConstants {

	//TODO change the code to match the UI language code in use Canada.ca uses "en" and "fr"
	public static final String LANG_EN = "en";
	public static final String LANG_FR = "fr";
	public static final String DAISI_PERSISTANCE_NAME = "daisiDS";
	public static final String DATABASE_DIALECT = "org.hibernate.dialect.Oracle10gDialect";
	public static final String DAISI_JNDI_NAME = "jdbc/daisiDS";
	public static final String PACKAGES_TO_SCAN = "ca.gc.servicecanada.daisi";
}
