package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_INFORMATION_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class InformationType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "INFORMATION_TYPE_ID")
  private int informationTypeID;

  @Column(name = "INFORMATION_TYPE_CODE")
  private String informationTypeCode;

  @Column(name = "INFORMATION_TYPE_NAME_EN", length = 50)
  private String informationTypeNameEn;

  @Column(name = "INFORMATION_TYPE_NAME_FR", length = 50)
  private String informationTypeNameFr;

  @Column(name = "INFORMATION_TYPE_DESC_EN", length = 2000)
  private String informationTypeDescEn;

  @Column(name = "INFORMATION_TYPE_DESC_FR", length = 2000)
  private String informationTypeDescFr;

  @Column(name = "INFORMATION_TYPE_ABRV_EN", length = 2000)
  private String informationTypeAbrvEn;

  @Column(name = "INFORMATION_TYPE_ABRV_FR", length = 2000)
  private String informationTypeAbrvFr;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getInformationTypeID()
  {
    return informationTypeID;
  }

  public void setInformationTypeID(final int informationTypeID)
  {
    this.informationTypeID = informationTypeID;
  }

  public String getInformationTypeCode()
  {
    return informationTypeCode;
  }

  public void setInformationTypeCode(final String informationTypeCode)
  {
    this.informationTypeCode = informationTypeCode;
  }

  public String getInformationTypeNameEn()
  {
    return informationTypeNameEn;
  }

  public void setInformationTypeNameEn(final String informationTypeNameEn)
  {
    this.informationTypeNameEn = informationTypeNameEn;
  }

  public String getInformationTypeNameFr()
  {
    return informationTypeNameFr;
  }

  public void setInformationTypeNameFr(final String informationTypeNameFr)
  {
    this.informationTypeNameFr = informationTypeNameFr;
  }

  public String getInformationTypeDescEn()
  {
    return informationTypeDescEn;
  }

  public void setInformationTypeDescEn(final String informationTypeDescEn)
  {
    this.informationTypeDescEn = informationTypeDescEn;
  }

  public String getInformationTypeDescFr()
  {
    return informationTypeDescFr;
  }

  public void setInformationTypeDescFr(final String informationTypeDescFr)
  {
    this.informationTypeDescFr = informationTypeDescFr;
  }

  public String getInformationTypeAbrvEn()
  {
    return informationTypeAbrvEn;
  }

  public void setInformationTypeAbrvEn(final String informationTypeAbrvEn)
  {
    this.informationTypeAbrvEn = informationTypeAbrvEn;
  }

  public String getInformationTypeAbrvFr()
  {
    return informationTypeAbrvFr;
  }

  public void setInformationTypeAbrvFr(final String informationTypeAbrvFr)
  {
    this.informationTypeAbrvFr = informationTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("InformationType [");
    builder.append(informationTypeID);
    builder.append(", ");
    builder.append(informationTypeNameEn);
    builder.append(", ");
    builder.append(informationTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE CD_INFORMATION_TYPE (
		INFORMATION_TYPE_ID VARCHAR2(30) NOT NULL,
		INFORMATION_TYPE_CODE VARCHAR2(3) NOT NULL,
		INFORMATION_TYPE_NAME_EN VARCHAR2(50),
		INFORMATION_TYPE_NAME_FR VARCHAR2(50),
		INFORMATION_TYPE_DESC_EN VARCHAR2(2000),
		INFORMATION_TYPE_DESC_FR VARCHAR2(2000),
		INFORMATION_TYPE_ABRV_EN VARCHAR2(10),
		INFORMATION_TYPE_ABRV_FR VARCHAR2(10),
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30) NOT NULL,
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE CD_INFORMATION_TYPE ADD CONSTRAINT INFTP_PK PRIMARY KEY (INFORMATION_TYPE_ID);

ALTER TABLE CD_INFORMATION_TYPE ADD CONSTRAINT INFTP_UK UNIQUE (INFORMATION_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE CD_INFORMATION_TYPE ADD CONSTRAINT INFTP_UK2 UNIQUE (INFORMATION_TYPE_NAME_EN, EXPIRY_DATE);

ALTER TABLE CD_INFORMATION_TYPE ADD CONSTRAINT INFTP_UK3 UNIQUE (INFORMATION_TYPE_NAME_FR, EXPIRY_DATE);


</code>
 */