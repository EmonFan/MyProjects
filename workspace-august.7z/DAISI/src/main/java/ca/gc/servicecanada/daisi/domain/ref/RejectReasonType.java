package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_REJECT_REASON_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class RejectReasonType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "REJECT_REASON_TYPE_ID")
  private int rejectReasonTypeID;

  @Column(name = "REJECT_REASON_TYPE_CODE")
  private String rejectReasonTypeCode;

  @Column(name = "REJECT_REASON_TYPE_NAME_EN", length = 50)
  private String rejectReasonTypeNameEn;

  @Column(name = "REJECT_REASON_TYPE_NAME_FR", length = 50)
  private String rejectReasonTypeNameFr;

  @Column(name = "REJECT_REASON_TYPE_DESC_EN", length = 2000)
  private String rejectReasonTypeDescEn;

  @Column(name = "REJECT_REASON_TYPE_DESC_FR", length = 2000)
  private String rejectReasonTypeDescFr;

  @Column(name = "REJECT_REASON_TYPE_ABRV_EN", length = 2000)
  private String rejectReasonTypeAbrvEn;

  @Column(name = "REJECT_REASON_TYPE_ABRV_FR", length = 2000)
  private String rejectReasonTypeAbrvFr;

  @Column(name = "REJECT_REASON_TYPE_SHARE_IND")
  private int rejectReasonTypeShareInd;

  @Column(name = "EXTERNAL_CODE")
  private String externalCode;

  @Column(name = "INTERNAL_CODE")
  private String internalCode;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getRejectReasonTypeID()
  {
    return rejectReasonTypeID;
  }

  public void setRejectReasonTypeID(final int rejectReasonTypeID)
  {
    this.rejectReasonTypeID = rejectReasonTypeID;
  }

  public String getRejectReasonTypeCode()
  {
    return rejectReasonTypeCode;
  }

  public void setRejectReasonTypeCode(final String rejectReasonTypeCode)
  {
    this.rejectReasonTypeCode = rejectReasonTypeCode;
  }

  public String getRejectReasonTypeNameEn()
  {
    return rejectReasonTypeNameEn;
  }

  public void setRejectReasonTypeNameEn(final String rejectReasonTypeNameEn)
  {
    this.rejectReasonTypeNameEn = rejectReasonTypeNameEn;
  }

  public String getRejectReasonTypeNameFr()
  {
    return rejectReasonTypeNameFr;
  }

  public void setRejectReasonTypeNameFr(final String rejectReasonTypeNameFr)
  {
    this.rejectReasonTypeNameFr = rejectReasonTypeNameFr;
  }

  public String getRejectReasonTypeDescEn()
  {
    return rejectReasonTypeDescEn;
  }

  public void setRejectReasonTypeDescEn(final String rejectReasonTypeDescEn)
  {
    this.rejectReasonTypeDescEn = rejectReasonTypeDescEn;
  }

  public String getRejectReasonTypeDescFr()
  {
    return rejectReasonTypeDescFr;
  }

  public void setRejectReasonTypeDescFr(final String rejectReasonTypeDescFr)
  {
    this.rejectReasonTypeDescFr = rejectReasonTypeDescFr;
  }

  public String getRejectReasonTypeAbrvEn()
  {
    return rejectReasonTypeAbrvEn;
  }

  public void setRejectReasonTypeAbrvEn(final String rejectReasonTypeAbrvEn)
  {
    this.rejectReasonTypeAbrvEn = rejectReasonTypeAbrvEn;
  }

  public String getRejectReasonTypeAbrvFr()
  {
    return rejectReasonTypeAbrvFr;
  }

  public void setRejectReasonTypeAbrvFr(final String rejectReasonTypeAbrvFr)
  {
    this.rejectReasonTypeAbrvFr = rejectReasonTypeAbrvFr;
  }

  public int getRejectReasonTypeShareInd()
  {
    return rejectReasonTypeShareInd;
  }

  public void setRejectReasonTypeShareInd(final int rejectReasonTypeShareInd)
  {
    this.rejectReasonTypeShareInd = rejectReasonTypeShareInd;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  public String getExternalCode()
  {
    return externalCode;
  }

  public void setExternalCode(final String externalCode)
  {
    this.externalCode = externalCode;
  }

  public String getInternalCode()
  {
    return internalCode;
  }

  public void setInternalCode(final String internalCode)
  {
    this.internalCode = internalCode;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("RejectReasonType [");
    builder.append(rejectReasonTypeID);
    builder.append(", ");
    builder.append(rejectReasonTypeNameEn);
    builder.append(", ");
    builder.append(rejectReasonTypeAbrvEn);
    builder.append(", ");
    builder.append(internalCode);
    builder.append(", ");
    builder.append(externalCode);
    builder.append("]");
    return builder.toString();
  }

}
