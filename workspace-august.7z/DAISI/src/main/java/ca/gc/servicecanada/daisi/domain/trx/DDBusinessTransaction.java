package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "TRANSACTION_DD_INFO")
@DiscriminatorValue("DPT")
public class DDBusinessTransaction extends BusinessTransaction
{

  private static final long serialVersionUID = 1L;

  @Column(name = "BUSINESS_TRANS_ID", insertable = false, updatable = false)
  protected int id;

  @XmlElement(required = true)
  @Column(name = "INSTITUTION_NUMBER")
  protected String institutionNumber;

  @XmlElement(required = true)
  @Column(name = "TRANSIT_NUMBER")
  protected String transitNumber;

  @XmlElement(required = true)
  @Column(name = "ACCOUNT_NUMBER")
  protected String accountNumber;

  // ----------
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "DATE_CREATED")
  @Temporal(TemporalType.TIMESTAMP)
  private Date dateCreated_;

  @Column(name = "SYSTEM_CREATED")
  private String systemCreated_;

  @Column(name = "USER_CREATED")
  private String userCreated_;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "DATE_UPDATED")
  private Date dateUpdated;

  @Column(name = "USER_UPDATED")
  private String userUpdated_;

  @Override
  public int getId()
  {
    return id;
  }

  @Override
  public void setId(final int id)
  {
    this.id = id;
  }

  public String getInstitutionNumber()
  {
    return institutionNumber;
  }

  public void setInstitutionNumber(final String institutionNumber)
  {
    this.institutionNumber = institutionNumber;
  }

  public String getTransitNumber()
  {
    return transitNumber;
  }

  public void setTransitNumber(final String transitNumber)
  {
    this.transitNumber = transitNumber;
  }

  public String getAccountNumber()
  {
    return accountNumber;
  }

  public void setAccountNumber(final String accountNumber)
  {
    this.accountNumber = accountNumber;
  }

  // ---------------
  @Override
  public Date getDateCreated()
  {
    return dateCreated;
  }

  @Override
  public void setDateCreated(final Date dateCreated)
  {
    dateCreated_ = dateCreated;
    super.setDateCreated(dateCreated);
  }

  @Override
  public String getSystemCreated()
  {
    return systemCreated;
  }

  @Override
  public void setSystemCreated(final String systemCreated)
  {
    systemCreated_ = systemCreated;
    super.setSystemCreated(systemCreated);
  }

  @Override
  public String getUserCreated()
  {
    return userCreated;
  }

  @Override
  public void setUserCreated(final String userCreated)
  {
    userCreated_ = userCreated;
    super.setUserCreated(userCreated);
  }

  @Override
  public Date getDateUpdated()
  {
    return dateUpdated;
  }

  @Override
  public void setDateUpdated(final Date dateUpdated)
  {
    this.dateUpdated = dateUpdated;
  }

  @Override
  public String getUserUpdated()
  {
    return userUpdated;
  }

  @Override
  public void setUserUpdated(final String userUpdated)
  {
    userUpdated_ = userUpdated;
    super.setUserUpdated(userCreated);
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append(super.toString());
    builder.append("DDBusinessTransaction [id=");
    builder.append(id);
    builder.append(", institutionNumber=");
    builder.append(institutionNumber);
    builder.append(", transitNumber=");
    builder.append(transitNumber);
    builder.append(", accountNumber=");
    builder.append(accountNumber);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE ISPOWNRE9.TRANSACTION_DD_INFO
(
  BUSINESS_TRANS_ID  NUMBER (12) NOT NULL ,
  INSTITUTION_NUMBER VARCHAR2 (4 BYTE) ,
  TRANSIT_NUMBER     VARCHAR2 (5 BYTE) NOT NULL ,
  ACCOUNT_NUMBER     VARCHAR2 (12 BYTE) NOT NULL ,
  DATE_CREATED       DATE NOT NULL ,
  SYSTEM_CREATED     VARCHAR2 (30 BYTE) NOT NULL ,
  USER_CREATED       VARCHAR2 (30 BYTE) NOT NULL ,
  DATE_UPDATED       DATE ,
  USER_UPDATED       VARCHAR2 (30 BYTE)
) ;


</code>
 */