package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component; //TBD: we can use Spring.xml to avoid import from spring

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.ProgramServiceDao;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

@Component
public class ProgramServiceDaoImpl implements ProgramServiceDao {

	private final static String SELECT_ALL_PROGRAM_SERVICE_TYPE = "SELECT e FROM ProgramServiceType e";
	private final static String SELECT_ALL_ORGANIZATION_TYPE = "SELECT e FROM OrganizationType e";

	private final static String FIND_PROGRAM_BY_CODE = "SELECT e FROM ProgramServiceType e WHERE e.serviceTypeCode = :serviceTypeCode";
	private final static String FIND_ORGANIZATION_BY_CODE = "SELECT e FROM OrganizationType e WHERE e.organizationTypeCode = :organizationTypeCode";

	private final static String FIND_PROGRAM_BY_ABRV_EN = "SELECT e FROM ProgramServiceType e WHERE e.serviceTypeAbrvEn = :serviceTypeAbrvEn";
	private final static String FIND_PROGRAM_BY_ABRV_FR = "SELECT e FROM ProgramServiceType e WHERE e.serviceTypeAbrvFr = :serviceTypeAbrvFr";
	private final static String FIND_ORGANIZATION_BY_ABRV_EN = "SELECT e FROM OrganizationType e WHERE e.organizationTypeAbrvEn = :organizationTypeAbrvEn";
	private final static String FIND_ORGANIZATION_BY_ABRV_FR = "SELECT e FROM OrganizationType e WHERE e.organizationTypeAbrvFr = :organizationTypeAbrvFr";
	
	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public List<ProgramServiceType> getAllProgramServiceType() {
		TypedQuery<ProgramServiceType> query = entityManager.createQuery(SELECT_ALL_PROGRAM_SERVICE_TYPE,
				ProgramServiceType.class);
		return query.getResultList();
	}

	public ProgramServiceType findDaisiProgramServiceTypeByID(int id) {
		ProgramServiceType data = null;
		data = (ProgramServiceType) entityManager.find(ProgramServiceType.class, id);
		return data;
	}

	public int createProgramServiceType(ProgramServiceType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getServiceTypeID();
	}

	public List<OrganizationType> getAllOrganizationType() {
		TypedQuery<OrganizationType> query = entityManager.createQuery(SELECT_ALL_ORGANIZATION_TYPE,
				OrganizationType.class);

		return query.getResultList();
	}

	public int createOrganizationType(OrganizationType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getOrganizationTypeID();
	}

	public OrganizationType findOrganizationTypeByID(int id) {
		OrganizationType data = null;
		data = (OrganizationType) entityManager.find(OrganizationType.class, id);
		return data;
	}

	public ProgramServiceType findDaisiProgramServiceTypeByCode(String code) {
		TypedQuery<ProgramServiceType> query = entityManager.createQuery(FIND_PROGRAM_BY_CODE, ProgramServiceType.class);
		query.setParameter("serviceTypeCode", code);
		ProgramServiceType data = query.getSingleResult();
		return data;
	}
	
	public ProgramServiceType findDaisiProgramServiceTypeByAbrv(String abrv) {
		return findDaisiProgramServiceTypeByAbrv(abrv, DaoConstants.LANG_EN); //English by default
	}
	
	public ProgramServiceType findDaisiProgramServiceTypeByAbrv(String abrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<ProgramServiceType> query = entityManager.createQuery(FIND_PROGRAM_BY_ABRV_EN, ProgramServiceType.class);
			query.setParameter("serviceTypeAbrvEn", abrv);
			ProgramServiceType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<ProgramServiceType> query = entityManager.createQuery(FIND_PROGRAM_BY_ABRV_FR, ProgramServiceType.class);
			query.setParameter("serviceTypeAbrvFr", abrv);
			ProgramServiceType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}

	public OrganizationType findOrganizationTypeByCode(String code) {
		TypedQuery<OrganizationType> query = entityManager.createQuery(FIND_ORGANIZATION_BY_CODE, OrganizationType.class);
		query.setParameter("organizationTypeCode", code);
		OrganizationType data = query.getSingleResult();
		return data;
	}

	public OrganizationType findOrganizationTypeByAbrv(String abrv) {
		return findOrganizationTypeByAbrv(abrv, DaoConstants.LANG_EN); //English by default
	}
	
	public OrganizationType findOrganizationTypeByAbrv(String abrv, String languageCode) {
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<OrganizationType> query = entityManager.createQuery(FIND_ORGANIZATION_BY_ABRV_EN, OrganizationType.class);
			query.setParameter("organizationTypeAbrvEn", abrv);
			OrganizationType data = query.getSingleResult();
			return data;
		}
		else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<OrganizationType> query = entityManager.createQuery(FIND_ORGANIZATION_BY_ABRV_FR, OrganizationType.class);
			query.setParameter("organizationTypeAbrvFr", abrv);
			OrganizationType data = query.getSingleResult();
			return data;
		}
		// unsupported language if you make it this far
		//We really should improve upon error checking and reporting.
		return null;
	}
}
