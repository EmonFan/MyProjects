package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_PROGRAM_SERVICE_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ProgramServiceType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "PROGRAM_SERVICE_TYPE_ID")
  private int serviceTypeID;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "ORGANIZATION_TYPE_ID", nullable = false, updatable = false)
  private OrganizationType organizationType;

  @Column(name = "PROGRAM_SERVICE_TYPE_CODE", length = 3)
  private String serviceTypeCode;

  @Column(name = "PROGRAM_SERVICE_TYPE_NAME_EN", length = 50)
  private String serviceTypeNameEn;

  @Column(name = "PROGRAM_SERVICE_TYPE_NAME_FR", length = 50)
  private String serviceTypeNameFr;

  @Column(name = "PROGRAM_SERVICE_TYPE_DESC_EN", length = 2000)
  private String serviceTypeDescEn;

  @Column(name = "PROGRAM_SERVICE_TYPE_DESC_FR", length = 2000)
  private String serviceTypeDescFr;

  @Column(name = "PROGRAM_SERVICE_TYPE_ABRV_EN", length = 2000)
  private String serviceTypeAbrvEn;

  @Column(name = "PROGRAM_SERVICE_TYPE_ABRV_FR", length = 2000)
  private String serviceTypeAbrvFr;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getServiceTypeID()
  {
    return serviceTypeID;
  }

  public void setServiceTypeID(final int serviceTypeID)
  {
    this.serviceTypeID = serviceTypeID;
  }

  public OrganizationType getOrganizationType()
  {
    return organizationType;
  }

  public void setOrganizationType(final OrganizationType organizationType)
  {
    this.organizationType = organizationType;
  }

  public String getServiceTypeCode()
  {
    return serviceTypeCode;
  }

  public void setServiceTypeCode(final String serviceTypeCode)
  {
    this.serviceTypeCode = serviceTypeCode;
  }

  public String getServiceTypeNameEn()
  {
    return serviceTypeNameEn;
  }

  public void setServiceTypeNameEn(final String serviceTypeNameEn)
  {
    this.serviceTypeNameEn = serviceTypeNameEn;
  }

  public String getServiceTypeNameFr()
  {
    return serviceTypeNameFr;
  }

  public void setServiceTypeNameFr(final String serviceTypeNameFr)
  {
    this.serviceTypeNameFr = serviceTypeNameFr;
  }

  public String getServiceTypeDescEn()
  {
    return serviceTypeDescEn;
  }

  public void setServiceTypeDescEn(final String serviceTypeDescEn)
  {
    this.serviceTypeDescEn = serviceTypeDescEn;
  }

  public String getServiceTypeDescFr()
  {
    return serviceTypeDescFr;
  }

  public void setServiceTypeDescFr(final String serviceTypeDescFr)
  {
    this.serviceTypeDescFr = serviceTypeDescFr;
  }

  public String getServiceTypeAbrvEn()
  {
    return serviceTypeAbrvEn;
  }

  public void setServiceTypeAbrvEn(final String serviceTypeAbrvEn)
  {
    this.serviceTypeAbrvEn = serviceTypeAbrvEn;
  }

  public String getServiceTypeAbrvFr()
  {
    return serviceTypeAbrvFr;
  }

  public void setServiceTypeAbrvFr(final String serviceTypeAbrvFr)
  {
    this.serviceTypeAbrvFr = serviceTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("ProgramServiceType [");
    builder.append(serviceTypeID);
    builder.append(", ");
    builder.append(organizationType);
    builder.append(", ");
    builder.append(serviceTypeNameEn);
    builder.append(", ");
    builder.append(serviceTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
CREATE TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE (
		PROGRAM_SERVICE_TYPE_ID NUMBER(12 , 0) NOT NULL,
		ORGANIZATION_TYPE_ID NUMBER(12 , 0) NOT NULL,
		PROGRAM_SERVICE_TYPE_CODE VARCHAR2(3) NOT NULL,
		PROGRAM_SERVICE_TYPE_NAME_EN VARCHAR2(50) NOT NULL,
		PROGRAM_SERVICE_TYPE_NAME_FR VARCHAR2(50) NOT NULL,
		PROGRAM_SERVICE_TYPE_DESC_EN VARCHAR2(2000),
		PROGRAM_SERVICE_TYPEE_DESC_FR VARCHAR2(2000),
		PROGRAM_SERVICE_TYPE_ABRV_EN VARCHAR2(10),
		PROGRAM_SERVICE_TYPE_ABRV_FR VARCHAR2(10),
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30) NOT NULL,
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE ADD CONSTRAINT PRGMSRVC_UK2 UNIQUE (PROGRAM_SERVICE_TYPE_NAME_EN, EXPIRY_DATE);

ALTER TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE ADD CONSTRAINT PRGMSRVC_UK UNIQUE (PROGRAM_SERVICE_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE ADD CONSTRAINT PRGMSRVC_UK3 UNIQUE (PROGRAM_SERVICE_TYPE_NAME_FR, EXPIRY_DATE);

ALTER TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE ADD CONSTRAINT PRGMSRVC_PK PRIMARY KEY (PROGRAM_SERVICE_TYPE_ID);

ALTER TABLE REFOWNRE9.CD_PROGRAM_SERVICE_TYPE ADD CONSTRAINT ORGTP_PRGMSRVC_FK FOREIGN KEY (ORGANIZATION_TYPE_ID)
	REFERENCES REFOWNRE9.CD_ORGANIZATION_TYPE (ORGANIZATION_TYPE_ID);

</code>
 */