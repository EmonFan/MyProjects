package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_ACTION_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class ActionType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ACTION_TYPE_ID")
  private int actionTypeID;

  @Column(name = "ACTION_TYPE_CODE")
  private String actionTypeCode;

  @Column(name = "ACTION_TYPE_NAME_EN", length = 50)
  private String actionTypeNameEn;

  @Column(name = "ACTION_TYPE_NAME_FR", length = 50)
  private String actionTypeNameFr;

  @Column(name = "ACTION_TYPE_DESC_EN", length = 2000)
  private String actionTypeDescEn;

  @Column(name = "ACTION_TYPE_DESC_FR", length = 2000)
  private String actionTypeDescFr;

  @Column(name = "ACTION_TYPE_ABRV_EN", length = 10)
  private String actionTypeAbrvEn;

  @Column(name = "ACTION_TYPE_ABRV_FR", length = 10)
  private String actionTypeAbrvFr;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  private Date effectiveDate;

  @XmlTransient
  @Temporal(TemporalType.TIMESTAMP)
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  private Date expiryDate;

  public int getActionTypeID()
  {
    return actionTypeID;
  }

  public void setActionTypeID(final int actionTypeID)
  {
    this.actionTypeID = actionTypeID;
  }

  public String getActionTypeCode()
  {
    return actionTypeCode;
  }

  public void setActionTypeCode(final String actionTypeCode)
  {
    this.actionTypeCode = actionTypeCode;
  }

  public String getActionTypeNameEn()
  {
    return actionTypeNameEn;
  }

  public void setActionTypeNameEn(final String actionTypeNameEn)
  {
    this.actionTypeNameEn = actionTypeNameEn;
  }

  public String getActionTypeNameFr()
  {
    return actionTypeNameFr;
  }

  public void setActionTypeNameFr(final String actionTypeNameFr)
  {
    this.actionTypeNameFr = actionTypeNameFr;
  }

  public String getActionTypeDescEn()
  {
    return actionTypeDescEn;
  }

  public void setActionTypeDescEn(final String actionTypeDescEn)
  {
    this.actionTypeDescEn = actionTypeDescEn;
  }

  public String getActionTypeDescFr()
  {
    return actionTypeDescFr;
  }

  public void setActionTypeDescFr(final String actionTypeDescFr)
  {
    this.actionTypeDescFr = actionTypeDescFr;
  }

  public String getActionTypeAbrvEn()
  {
    return actionTypeAbrvEn;
  }

  public void setActionTypeAbrvEn(final String actionTypeAbrvEn)
  {
    this.actionTypeAbrvEn = actionTypeAbrvEn;
  }

  public String getActionTypeAbrvFr()
  {
    return actionTypeAbrvFr;
  }

  public void setActionTypeAbrvFr(final String actionTypeAbrvFr)
  {
    this.actionTypeAbrvFr = actionTypeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("ActionType [");
    builder.append(actionTypeID);
    builder.append(", ");
    builder.append(actionTypeNameEn);
    builder.append(", ");
    builder.append(actionTypeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>

CREATE TABLE CD_ACTION_TYPE (
	ACTION_TYPE_ID NUMBER(12 , 0) NOT NULL,
	ACTION_TYPE_CODE VARCHAR2(3) NOT NULL,
	ACTION_TYPE_NAME_EN VARCHAR2(50),
	ACTION_TYPE_NAME_FR VARCHAR2(50),
	ACTION_TYPE_DESC_EN VARCHAR2(2000),
	ACTION_TYPE_DESC_FR VARCHAR2(2000),
	ACTION_TYPE_ABRV_EN VARCHAR2(10),
	ACTION_TYPE_ABRV_FR VARCHAR2(10),
	EFFECTIVE_DATE DATE NOT NULL,
	EXPIRY_DATE DATE,
	DATE_CREATED DATE NOT NULL,
	SYSTEM_CREATED VARCHAR2(30),
	USER_CREATED VARCHAR2(30) NOT NULL,
	DATE_UPDATED DATE,
	USER_UPDATED VARCHAR2(30)
);

ALTER TABLE CD_ACTION_TYPE ADD CONSTRAINT ACTNTP_PK PRIMARY KEY (ACTION_TYPE_ID);

ALTER TABLE CD_ACTION_TYPE ADD CONSTRAINT ACTNTP_UK3 UNIQUE (ACTION_TYPE_NAME_FR, EXPIRY_DATE);

ALTER TABLE CD_ACTION_TYPE ADD CONSTRAINT ACTNTP_UK UNIQUE (ACTION_TYPE_CODE, EXPIRY_DATE);

ALTER TABLE CD_ACTION_TYPE ADD CONSTRAINT ACTNTP_UK2 UNIQUE (ACTION_TYPE_NAME_EN, EXPIRY_DATE);



</code>
 */