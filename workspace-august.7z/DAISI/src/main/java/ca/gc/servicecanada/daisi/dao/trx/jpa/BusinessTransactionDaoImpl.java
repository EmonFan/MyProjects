package ca.gc.servicecanada.daisi.dao.trx.jpa;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

@Component
public class BusinessTransactionDaoImpl implements BusinessTransactionDao {

	private Logger LOGGER = LogManager.getLogger(getClass());
	private static boolean triggerIsPrepared = false;

	private final static String SELECT_ALL_BUSINESS_TRANSATIONS = "SELECT e FROM BusinessTransaction e";

	private final static String SELECT_ALL_TECHNICAL_TRANSATIONS = "SELECT e FROM TechnicalTransaction e";

	private final static String LOOKUP_BUSINESS_TRANSATIONS_BY_SIN = "SELECT e FROM BusinessTransaction e WHERE e.sin = :sin";

	private final static String LOOKUP_BUSINESS_TRANSATION_BY_BUSINESS_TRX_ID = "SELECT e FROM BusinessTransaction e WHERE e.businessTransactionID= :businessTransactionID";

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	@Override
	public List<BusinessTransaction> getAllBusinessTransaction() {
		TypedQuery<BusinessTransaction> query = entityManager.createQuery(SELECT_ALL_BUSINESS_TRANSATIONS,
				BusinessTransaction.class);
		return query.getResultList();
	}

	public BusinessTransaction findBusinessTransactionByID(int id) {
		LOGGER.debug("lookup for BusinessTransaction ID=" + id);
		BusinessTransaction data = (BusinessTransaction) entityManager.find(BusinessTransaction.class, id);
		return data;
	}

	@Override
	public List<TechnicalTransaction> getAllTechnicalTransaction() {
		TypedQuery<TechnicalTransaction> query = entityManager.createQuery(SELECT_ALL_TECHNICAL_TRANSATIONS,
				TechnicalTransaction.class);
		return query.getResultList();
	}

	@Override
	public List<BusinessTransaction> findBusinessTransactionBySIN(String sin) {
		LOGGER.debug("lookup for BusinessTransactions for a SIN ending with " + sin.substring(7));

		TypedQuery<BusinessTransaction> query = entityManager.createQuery(LOOKUP_BUSINESS_TRANSATIONS_BY_SIN,
				BusinessTransaction.class);
		query.setParameter("sin", sin);
		List<BusinessTransaction> data = query.getResultList();

		StringBuilder b = new StringBuilder();
		if (data != null && data.size() > 0 && LOGGER.isDebugEnabled()) {
			for (BusinessTransaction item : data) {
				b.append(item.toString());
				b.append("\n");
			}
			LOGGER.debug(b.toString());
		}
		return data;
	}

	@Override
	public BusinessTransaction create(BusinessTransaction bt) {
		Session sess = entityManager.unwrap(Session.class);
		entityManager.persist(bt);
		//Commit now so we respond to the caller without having to wait for the object to go
		//out of scope. This will catch any duplicate key exceptions
		entityManager.flush(); 
		return bt;
	}

	@Override
	public BusinessTransaction findBusinessTransactionByBusinessTransactionID(String businessTransactionID) {
		TypedQuery<BusinessTransaction> query = entityManager.createQuery(LOOKUP_BUSINESS_TRANSATION_BY_BUSINESS_TRX_ID,
				BusinessTransaction.class);
		query.setParameter("businessTransactionID", businessTransactionID);
		
		//Catch and eat the no result exception. We'll handle it elsewhere. 
		BusinessTransaction trx = null;
		try {
			trx = query.getSingleResult();
		} catch (NoResultException nre) {
			//Keep going. We don't care
		}
		
		//Make sure our trigger is set up before we update.
		//Appears to be some funky hibernate stuff going on here
		//update function is not always called, this seems to fix it
		if (!triggerIsPrepared) 
			prepTrigger();
		
		return trx;
	}
	
	public void prepTrigger() {
		//NOTE THAT THE UNDERLYING TABLE HAS A TRIGGER THAT FIRES ON UPDATE AND DELETE
		//In order for the trigger to fire successfully we need a little prep to be done via
		//a stored procedure
		StoredProcedureQuery spQuery = entityManager.createStoredProcedureQuery("ODS_DATE_PKG.set_date");
		spQuery.registerStoredProcedureParameter("now", Timestamp.class, ParameterMode.IN);
		Timestamp now = new Timestamp(Calendar.getInstance().getTimeInMillis());
		spQuery.setParameter("now", now);

		//Execute the trigger
		try {
			spQuery.execute();
		} catch (Exception e) {
			LOGGER.debug("Daisi-JPA: Stored procedure call failed");
			e.printStackTrace();
		}

		triggerIsPrepared = true;
	}
	
	@Override
	public BusinessTransaction update(BusinessTransaction bt) {
		
		//WORKAROUND FOR JPA performing an insert instead of update on a detached entity.
		//Find and load the current transaction, update the found object with the target data
		//Update the retrieved object (guaranteed to be in scope)
		//Detailed explanation can be found here http://blog.xebia.com/jpa-implementation-patterns-saving-detached-entities/
		
		DDBusinessTransaction existingBT = (DDBusinessTransaction )this.findBusinessTransactionByBusinessTransactionID(bt.getBusinessTransactionID());
		DDBusinessTransaction actualBt = (DDBusinessTransaction ) bt;
		
		//Update the relevant DD fields
		existingBT.setAccountNumber(actualBt.getAccountNumber());
		existingBT.setInstitutionNumber(actualBt.getInstitutionNumber());
		existingBT.setTransitNumber(actualBt.getTransitNumber());
		
		existingBT.setBusinessTransactionStatuses(actualBt.getBusinessTransactionStatuses());
		

		LOGGER.debug("Daisi-JPA: Attempting to update a BusinessTransaction" + bt.toString());

		//Make sure our trigger is set up before we update.
		if (!triggerIsPrepared) 
			prepTrigger();
		
		//Do the real work now
		BusinessTransaction updated = entityManager.merge(existingBT);
		
		//reset our trigger flag
		triggerIsPrepared = false;
		return updated;
	}

}
