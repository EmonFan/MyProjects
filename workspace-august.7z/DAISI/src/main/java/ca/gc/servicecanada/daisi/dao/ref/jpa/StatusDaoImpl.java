package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.StatusDao;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;

@Component
public class StatusDaoImpl implements StatusDao {

	private final static String SELECT_ALL_STATUS_TYPE = "SELECT e FROM StatusType e";

	private final static String FIND_STATUS_TYPE_BY_CODE_ABRV_EN = "SELECT e FROM StatusType e WHERE e.statusCodeAbrvEn = :statusCodeAbrvEn";
	private final static String FIND_STATUS_TYPE_BY_CODE_ABRV_FR = "SELECT e FROM StatusType e WHERE e.statusCodeAbrvFr = :statusCodeAbrvFr";

	private Logger LOGGER = LogManager.getLogger(getClass());

	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	public StatusType findStatusTypeByAbrv(String eventLogTypeAbrv) {
		// English abbreviation by default
		return findStatusTypeByAbrv(eventLogTypeAbrv, DaoConstants.LANG_EN);
	}

	public StatusType findStatusTypeByAbrv(String statusTypeAbrv, String languageCode) {
		LOGGER.debug("DAISI-JPA: findEventLogTypeByAbrv: " + statusTypeAbrv + " + " + languageCode);
		if (DaoConstants.LANG_EN.equals(languageCode)) {
			TypedQuery<StatusType> query = entityManager.createQuery(FIND_STATUS_TYPE_BY_CODE_ABRV_EN,
					StatusType.class);
			query.setParameter("statusCodeAbrvEn", statusTypeAbrv);
			StatusType data = query.getSingleResult();
			return data;
		} else if (DaoConstants.LANG_FR.equals(languageCode)) {
			TypedQuery<StatusType> query = entityManager.createQuery(FIND_STATUS_TYPE_BY_CODE_ABRV_FR,
					StatusType.class);
			query.setParameter("statusCodeAbrvFr", statusTypeAbrv);
			StatusType data = query.getSingleResult();
			return data;
		} else {
			throw new IllegalArgumentException(
					"Only " + DaoConstants.LANG_FR + " or " + DaoConstants.LANG_EN + " are supported! It's CANADA!");
		}
	}

	public List<StatusType> getAllStatusType() {
		TypedQuery<StatusType> query = entityManager.createQuery(SELECT_ALL_STATUS_TYPE, StatusType.class);
		return query.getResultList();
	}

	public StatusType findStatusTypeByID(int id) {
		StatusType data = null;
		data = (StatusType) entityManager.find(StatusType.class, id);
		return data;
	}

	public int createStatusType(StatusType data) {
		entityManager.persist(data);
		entityManager.flush();
		return data.getStatusTypeID();
	}

}
