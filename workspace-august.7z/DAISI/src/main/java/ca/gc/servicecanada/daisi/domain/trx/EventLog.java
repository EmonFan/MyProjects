package ca.gc.servicecanada.daisi.domain.trx;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "EVENT_LOG")
public class EventLog extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EVNTLG_SEQ")
  @SequenceGenerator(name = "EVNTLG_SEQ", sequenceName = "EVNTLG_SEQ")
  @Column(name = "EVENT_LOG_ID")
  protected int id;

  @XmlTransient
  @JsonBackReference
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "TECHNICAL_TRANS_ID", nullable = true, updatable = false)
  private TechnicalTransaction technicalTransaction;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "EVENT_LOG_TYPE_ID", nullable = true, updatable = false)
  private EventLogType eventLogType;

  @JsonSerialize(using = CustomDateSerializer.class)
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "EVENT_DATE")
  private Date eventDate;

  public int getId()
  {
    return id;
  }

  public void setId(final int id)
  {
    this.id = id;
  }

  public TechnicalTransaction getTechnicalTransaction()
  {
    return technicalTransaction;
  }

  public void setTechnicalTransaction(final TechnicalTransaction technicalTransaction)
  {
    this.technicalTransaction = technicalTransaction;
  }

  public Date getEventDate()
  {
    return eventDate;
  }

  public void setEventDate(final Date eventDate)
  {
    this.eventDate = eventDate;
  }

  public EventLogType getEventLogType()
  {
    return eventLogType;
  }

  public void setEventLogType(final EventLogType eventLogType)
  {
    this.eventLogType = eventLogType;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("EventLog [id=");
    builder.append(id);
    builder.append(", technicalTransaction=");
    builder.append(technicalTransaction);
    builder.append(", eventDate=");
    builder.append(eventDate);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>
--------------------------------------------------------
--  DDL for Table EVENT_LOG
--------------------------------------------------------

  CREATE TABLE "EXTOWNRE9"."EVENT_LOG"
   (	"EVENT_LOG_ID" NUMBER(12,0),
	"TECHNICAL_TRANS_ID" NUMBER(12,0),
	"EVENT_LOG_TYPE_ID" NUMBER(12,0),
	"EVENT_DATE" DATE,
	"DATE_CREATED" DATE,
	"SYSTEM_CREATED" VARCHAR2(30 BYTE),
	"USER_CREATED" VARCHAR2(30 BYTE),
	"DATE_UPDATED" DATE,
	"USER_UPDATED" VARCHAR2(30 BYTE)
   ) SEGMENT CREATION DEFERRED
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
 NOCOMPRESS LOGGING
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  DDL for Index EVNTLG_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "EXTOWNRE9"."EVNTLG_PK" ON "EXTOWNRE9"."EVENT_LOG" ("EVENT_LOG_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  DDL for Index EVNTLG_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "EXTOWNRE9"."EVNTLG_UK" ON "EXTOWNRE9"."EVENT_LOG" ("TECHNICAL_TRANS_ID", "EVENT_LOG_TYPE_ID")
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA" ;
--------------------------------------------------------
--  Constraints for Table EVENT_LOG
--------------------------------------------------------

  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" MODIFY ("USER_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" MODIFY ("SYSTEM_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" MODIFY ("DATE_CREATED" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" MODIFY ("EVENT_LOG_TYPE_ID" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" MODIFY ("TECHNICAL_TRANS_ID" NOT NULL ENABLE);
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" ADD CONSTRAINT "EVNTLG_UK" UNIQUE ("TECHNICAL_TRANS_ID", "EVENT_LOG_TYPE_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA"  ENABLE;
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" ADD CONSTRAINT "EVNTLG_PK" PRIMARY KEY ("EVENT_LOG_ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS
  TABLESPACE "STG_DATA"  ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table EVENT_LOG
--------------------------------------------------------

  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" ADD CONSTRAINT "EVNTLGTP_EVNTLG_FK" FOREIGN KEY ("EVENT_LOG_TYPE_ID")
	  REFERENCES "REFOWNRE9"."CD_EVENT_LOG_TYPE" ("EVENT_LOG_TYPE_ID") ENABLE;
  ALTER TABLE "EXTOWNRE9"."EVENT_LOG" ADD CONSTRAINT "EVNTLG_TCHNLTRN_FK" FOREIGN KEY ("TECHNICAL_TRANS_ID")
	  REFERENCES "EXTOWNRE9"."TECHNICAL_TRANS" ("TECHNICAL_TRANS_ID") ENABLE;


</code>
 */
