package ca.gc.servicecanada.daisi.dao.trx.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import ca.gc.servicecanada.daisi.dao.trx.TechnicalTransactionDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction_;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction_;


@Component
public class TechnicalTransactionDaoImpl implements TechnicalTransactionDao {

	private Logger LOGGER = LogManager.getLogger(getClass());

	// for testing only
	private final static String SELECT_ALL_TECHNICAL_TRANSACTION = "SELECT e FROM TechnicalTransaction e";


	
	@PersistenceContext(unitName = "daisiDS", type = PersistenceContextType.TRANSACTION)
	private EntityManager entityManager;

	// for testing only
	@Override
	public List<TechnicalTransaction> getAllTechnicalTransactions() {
		TypedQuery<TechnicalTransaction> query = entityManager.createQuery(SELECT_ALL_TECHNICAL_TRANSACTION, TechnicalTransaction.class);
		return query.getResultList();
	}
	
	
	@Override
	public TechnicalTransaction findTechnicalTransactionByTechnicalTransID(int technicalTransID) {
		LOGGER.debug("lookup for TecnhicalTransaction for TECHNICAL_TRANS_ID = " + technicalTransID);
		
		TechnicalTransaction data = (TechnicalTransaction) entityManager.find(TechnicalTransaction.class, technicalTransID);
		return data;		
		
		
		//CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		//CriteriaQuery<TechnicalTransaction> query = criteriaBuilder.createQuery(TechnicalTransaction.class);
		//Root<TechnicalTransaction> root = query.from(TechnicalTransaction.class);
		//query.select(root);		
		//TechnicalTransaction data = (TechnicalTransaction) entityManager.find(TechnicalTransaction.class, technicalTransID);

//		Join<TechnicalTransaction, BusinessTransaction> join = root.join(TechnicalTransaction_.businessTransaction);
		//query.where(criteriaBuilder.equal(.get(TechnicalTransaction_.transactionID), technicalTransID));

		//TechnicalTransaction data = entityManager.createQuery(query).getSingleResult();

		//return data;
	}	
	
	@Override
	public List<TechnicalTransaction> findTechnicalTransactionsByBusinessTransactionId(int businessTransID) {
		LOGGER.debug("lookup for TechnicalTransaction for BUSINESS_TRANS_ID = " + businessTransID);    // caseys 201706120  - from BUSINESS_TRASNACTION_ID
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TechnicalTransaction> query = criteriaBuilder.createQuery(TechnicalTransaction.class);
		Root<TechnicalTransaction> root = query.from(TechnicalTransaction.class);
		Join<TechnicalTransaction, BusinessTransaction> join = root.join(TechnicalTransaction_.businessTransaction);
		query.where(criteriaBuilder.equal(join.get(BusinessTransaction_.id), businessTransID));
		query.select(root);
		List<TechnicalTransaction> data = entityManager.createQuery(query).getResultList();

		return data;
	}	
	
	@Override
	public List<TechnicalTransaction> findTechnicalTransactionsByTechnicalTransactionId(String technicalTransactionID) {
		LOGGER.debug("lookup for LogtechnicalTransactions for TECHNICAL_TRANSACTION_ID = " + technicalTransactionID);
	
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<TechnicalTransaction> query = criteriaBuilder.createQuery(TechnicalTransaction.class);
		Root<TechnicalTransaction> root = query.from(TechnicalTransaction.class);
		//Join<TechnicalTransaction, BusinessTransaction> join = root.join(TechnicalTransaction_.businessTransaction);
		query.where(criteriaBuilder.equal(root.get(TechnicalTransaction_.technicalTransactionID), technicalTransactionID));
		query.select(root);
		List<TechnicalTransaction> data = entityManager.createQuery(query).getResultList();

		return data;
	}

	@Override
	public TechnicalTransaction create(TechnicalTransaction technicalTransaction) {
		entityManager.persist(technicalTransaction);
		int id = technicalTransaction.getTransactionID();
		return technicalTransaction;
	}

}
