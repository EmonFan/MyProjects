package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_STATUS_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class StatusType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "STATUS_TYPE_ID")
  private int statusTypeID;

  @Column(name = "STATUS_CODE")
  private String statusCode;

  @Column(name = "STATUS_CODE_NAME_EN", length = 50)
  private String statusCodeNameEn;

  @Column(name = "STATUS_CODE_NAME_FR", length = 50)
  private String channelTypeNameFr;

  @Column(name = "STATUS_CODE_DESC_EN", length = 2000)
  private String statusCodeDescEn;

  @Column(name = "STATUS_CODE_DESC_FR", length = 2000)
  private String statusCodeDescFr;

  @Column(name = "STATUS_CODE_ABRV_EN", length = 2000)
  private String statusCodeAbrvEn;

  @Column(name = "STATUS_CODE_ABRV_FR", length = 2000)
  private String statusCodeAbrvFr;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getStatusTypeID()
  {
    return statusTypeID;
  }

  public void setStatusTypeID(final int statusTypeID)
  {
    this.statusTypeID = statusTypeID;
  }

  public String getStatusCode()
  {
    return statusCode;
  }

  public void setStatusCode(final String statusCode)
  {
    this.statusCode = statusCode;
  }

  public String getStatusCodeNameEn()
  {
    return statusCodeNameEn;
  }

  public void setStatusCodeNameEn(final String statusCodeNameEn)
  {
    this.statusCodeNameEn = statusCodeNameEn;
  }

  public String getChannelTypeNameFr()
  {
    return channelTypeNameFr;
  }

  public void setChannelTypeNameFr(final String channelTypeNameFr)
  {
    this.channelTypeNameFr = channelTypeNameFr;
  }

  public String getStatusCodeDescEn()
  {
    return statusCodeDescEn;
  }

  public void setStatusCodeDescEn(final String statusCodeDescEn)
  {
    this.statusCodeDescEn = statusCodeDescEn;
  }

  public String getStatusCodeDescFr()
  {
    return statusCodeDescFr;
  }

  public void setStatusCodeDescFr(final String statusCodeDescFr)
  {
    this.statusCodeDescFr = statusCodeDescFr;
  }

  public String getStatusCodeAbrvEn()
  {
    return statusCodeAbrvEn;
  }

  public void setStatusCodeAbrvEn(final String statusCodeAbrvEn)
  {
    this.statusCodeAbrvEn = statusCodeAbrvEn;
  }

  public String getStatusCodeAbrvFr()
  {
    return statusCodeAbrvFr;
  }

  public void setStatusCodeAbrvFr(final String statusCodeAbrvFr)
  {
    this.statusCodeAbrvFr = statusCodeAbrvFr;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("StatusType [");
    builder.append(statusTypeID);
    builder.append(", ");
    builder.append(statusCodeNameEn);
    builder.append(", ");
    builder.append(channelTypeNameFr);
    builder.append(", ");
    builder.append(statusCodeAbrvEn);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>

CREATE TABLE CD_STATUS_TYPE (
		STATUS_TYPE_ID NUMBER(12 , 0) NOT NULL,
		STATUS_CODE VARCHAR2(3) NOT NULL,
		STATUS_CODE_NAME_EN VARCHAR2(50),
		STATUS_CODE_NAME_FR VARCHAR2(50),
		STATUS_CODE_DESC_EN VARCHAR2(2000),
		STATUS_CODE_DESC_FR VARCHAR2(2000),
		STATUS_CODE_ABRV_EN VARCHAR2(10),
		STATUS_CODE_ABRV_FR VARCHAR2(10),
		EFFECTIVE_DATE DATE NOT NULL,
		EXPIRY_DATE DATE,
		DATE_CREATED DATE NOT NULL,
		SYSTEM_CREATED VARCHAR2(30) NOT NULL,
		USER_CREATED VARCHAR2(30) NOT NULL,
		DATE_UPDATED DATE,
		USER_UPDATED VARCHAR2(30)
	);

ALTER TABLE CD_STATUS_TYPE ADD CONSTRAINT STTP_UK2 UNIQUE (STATUS_CODE_NAME_EN, EXPIRY_DATE);

ALTER TABLE CD_STATUS_TYPE ADD CONSTRAINT STCD_PK PRIMARY KEY (STATUS_TYPE_ID);

ALTER TABLE CD_STATUS_TYPE ADD CONSTRAINT STTP_UK UNIQUE (STATUS_CODE, EXPIRY_DATE);

ALTER TABLE CD_STATUS_TYPE ADD CONSTRAINT STTP_UK3 UNIQUE (STATUS_CODE_NAME_FR, EXPIRY_DATE);


</code>
 */