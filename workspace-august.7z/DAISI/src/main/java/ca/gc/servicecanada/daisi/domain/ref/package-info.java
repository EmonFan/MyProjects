@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.daisi.servicecanada.ca/domain")
package ca.gc.servicecanada.daisi.domain.ref;
