package ca.gc.servicecanada.daisi.dao.trx;

import java.util.List;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

public interface BusinessTransactionDao {

	// for testing only
	List<BusinessTransaction> getAllBusinessTransaction();

	BusinessTransaction findBusinessTransactionByID(int id);
	
	BusinessTransaction findBusinessTransactionByBusinessTransactionID(String businessTransactionID);

	List<BusinessTransaction> findBusinessTransactionBySIN(String SIN);

	// for testing only
	List<TechnicalTransaction> getAllTechnicalTransaction();

	BusinessTransaction create(BusinessTransaction bt);
	
	BusinessTransaction update(BusinessTransaction bt);

}
