package ca.gc.servicecanada.daisi.domain.ref;

import ca.gc.servicecanada.daisi.domain.AuditFieldsImpl;
import ca.gc.servicecanada.daisi.service.json.CustomDateSerializer;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "CD_TRANSACTION_TYPE")
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class TransactionType extends AuditFieldsImpl implements Serializable
{

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "TRANSACTION_TYPE_ID")
  private int transactionTypeID;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "INFORMATION_TYPE_ID", nullable = false, updatable = false)
  private InformationType informationType;

  @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  @JoinColumn(name = "ACTION_TYPE_ID", nullable = false, updatable = false)
  private ActionType actionType;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EFFECTIVE_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date effectiveDate;

  @XmlTransient
  @JsonSerialize(using = CustomDateSerializer.class)
  @Column(name = "EXPIRY_DATE")
  @Temporal(TemporalType.TIMESTAMP)
  private Date expiryDate;

  public int getTransactionTypeID()
  {
    return transactionTypeID;
  }

  public void setTransactionTypeID(final int transactionTypeID)
  {
    this.transactionTypeID = transactionTypeID;
  }

  public InformationType getInformationType()
  {
    return informationType;
  }

  public void setInformationType(final InformationType informationType)
  {
    this.informationType = informationType;
  }

  public ActionType getActionType()
  {
    return actionType;
  }

  public void setActionType(final ActionType actionType)
  {
    this.actionType = actionType;
  }

  public Date getEffectiveDate()
  {
    return effectiveDate;
  }

  public void setEffectiveDate(final Date effectiveDate)
  {
    this.effectiveDate = effectiveDate;
  }

  public Date getExpiryDate()
  {
    return expiryDate;
  }

  public void setExpiryDate(final Date expiryDate)
  {
    this.expiryDate = expiryDate;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("TransactionType [transactionTypeID=");
    builder.append(transactionTypeID);
    builder.append(", informationType=");
    builder.append(informationType);
    builder.append(", actionType=");
    builder.append(actionType);
    builder.append("]");
    return builder.toString();
  }

}

/**
 * <code>

CREATE TABLE CD_TRANSACTION_TYPE (
TRANSACTION_TYPE_ID NUMBER(12 , 0) NOT NULL,
INFORMATION_TYPE_ID VARCHAR2(30) NOT NULL,
ACTION_TYPE_ID NUMBER(12 , 0) NOT NULL,
EFFECTIVE_DATE DATE NOT NULL,
EXPIRY_DATE DATE,
DATE_CREATED DATE NOT NULL,
SYSTEM_CREATED VARCHAR2(30) NOT NULL,
USER_CREATED VARCHAR2(30) NOT NULL,
DATE_UPDATED DATE,
USER_UPDATED VARCHAR2(30),
TRANS_TYPE_DISPLAY_NAME_EN VARCHAR2 (200 BYTE) NOT NULL ,
TRANS_TYPE_DISPLAY_NAME_FR VARCHAR2 (200 BYTE) NOT NULL
);

ALTER TABLE CD_TRANSACTION_TYPE ADD CONSTRAINT TRSCTNTP_PK PRIMARY KEY (TRANSACTION_TYPE_ID);

ALTER TABLE CD_TRANSACTION_TYPE ADD CONSTRAINT TRSCTNTP_UK UNIQUE (ACTION_TYPE_ID, INFORMATION_TYPE_ID, EXPIRY_DATE);

ALTER TABLE CD_TRANSACTION_TYPE ADD CONSTRAINT INFTP_TRSCTNTP_FK FOREIGN KEY (INFORMATION_TYPE_ID)
REFERENCES CD_INFORMATION_TYPE (INFORMATION_TYPE_ID);

ALTER TABLE CD_TRANSACTION_TYPE ADD CONSTRAINT ACTNTP_TRSCTNTP_FK FOREIGN KEY (ACTION_TYPE_ID)
REFERENCES CD_ACTION_TYPE (ACTION_TYPE_ID);
</code>
 */
