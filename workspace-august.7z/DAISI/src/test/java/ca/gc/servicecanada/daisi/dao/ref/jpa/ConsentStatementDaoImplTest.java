package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildChannelType;
import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildConsentStatementType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.ConsentStatementDao;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class ConsentStatementDaoImplTest {

	@Resource
	ConsentStatementDao consentDao;

	@Test
	public void getAllChannelType() {
		List<ChannelType> data = consentDao.getAllChannelType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (ChannelType item : data) {
			System.out.println(item);
		}
	}

	@Test
	public void findChannelTypeByID() {
		int id = 1;
		ChannelType data = consentDao.findChannelTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getChannelTypeID());
		System.out.println(data);
	}
	@Test
	public void findChannelTypeByCode() {
		String channelTypeCode= "ONL";
		ChannelType data = consentDao.findChannelTypeByCode(channelTypeCode); 
		assertNotNull(data);
		assertEquals(channelTypeCode, data.getChannelTypeCode());
		System.out.println(data);

	}

	@Test
	public void findConsentStatementTypeByAbrv() {
		String ConsentStatementTypeAbrv= "ABRV_EN";
		ConsentStatementType data = consentDao.findConsentStatementTypeByAbrv(ConsentStatementTypeAbrv, DaoConstants.LANG_EN); 
		assertNotNull(data);
		assertEquals(ConsentStatementTypeAbrv, data.getConsentStatementTypeAbrvEn());
		System.out.println(data.getConsentStatementTypeAbrvEn());

		ConsentStatementTypeAbrv= "ABRV_FR";
		data = consentDao.findConsentStatementTypeByAbrv(ConsentStatementTypeAbrv, DaoConstants.LANG_FR); 
		assertNotNull(data);
		assertEquals(ConsentStatementTypeAbrv, data.getConsentStatementTypeAbrvFr());
		System.out.println(data.getConsentStatementTypeAbrvFr());
	}
	
	@Test
	public void findChannelTypeByAbrv() {
		String channelTypeAbrv= "ABRV_EN";
		ChannelType data = consentDao.findChannelTypeByAbrv(channelTypeAbrv, DaoConstants.LANG_EN); 
		assertNotNull(data);
		assertEquals(channelTypeAbrv, data.getChannelTypeAbrvEn());
		System.out.println(data.getChannelTypeAbrvEn());

		channelTypeAbrv= "ABRV_FR";
		data = consentDao.findChannelTypeByAbrv(channelTypeAbrv, DaoConstants.LANG_FR); 
		assertNotNull(data);
		assertEquals(channelTypeAbrv, data.getChannelTypeAbrvFr());
		System.out.println(data.getChannelTypeAbrvFr());
	}

	
	//@Test
	public void createChannelType() {
		ChannelType data = buildChannelType();
		System.out.println(data.toString());
		int id = consentDao.createChannelType(data);
		assertNotNull(id);
	}

	@Test
	public void getAllConsentStatementType() {
		List<ConsentStatementType> data = consentDao.getAllConsentStatementType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (ConsentStatementType item : data) {
			System.out.println(item);
		}

	}

	@Test
	public void findConsentStatementTypeByID() {
		int id = 2;
		ConsentStatementType data = consentDao.findConsentStatementTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getConsentStatementTypeID());
		System.out.println(data);
	}
	@Test
	public void findConsentStatementTypeByCode() {
		String consentStatementTypeCode= "SON"; //"1"; //online push
		ConsentStatementType data = consentDao.findConsentStatementTypeByCode(consentStatementTypeCode);
		assertNotNull(data);
		assertEquals(consentStatementTypeCode, data.getConsentStatementTypeCode());
		System.out.println(data);
	}

	//@Test
	public void createConsentStatementType() {
		ConsentStatementType data = buildConsentStatementType();
		System.out.println(data.toString());
		int id = consentDao.createConsentStatementType(data);
		assertNotNull(id);

	}
	
	@Test
	public void findConsentStatementTypeAbrv() {
		String channelType = "Online";
		String consentCode = "ESS1701";
		String data = consentDao.findConsentStatementTypeAbrv(channelType, consentCode); 
		assertNotNull(data);
		//assertEquals(ConsentStatementTypeAbrv, data.getConsentStatementTypeAbrvEn());
		System.out.println(data);

	}

}
