package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildRejectReasonType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.ref.RejectReasonDao;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class RejectReasonDaoImplTest {

	@Resource
	RejectReasonDao rejectDao;

	@Test
	public void getAllRejectReasonType() {
		List<RejectReasonType> data = rejectDao.getAllRejectReasonType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (RejectReasonType item : data) {
			System.out.println(item);
		}
	}

	@Test
	public void findRejectReasonTypeByID() {
		int id = 1;
		RejectReasonType data = rejectDao.findRejectReasonTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getRejectReasonTypeID());
		System.out.println(data);

	}

	//@Test
	public void createRejectReason() {
		RejectReasonType data = buildRejectReasonType();
		System.out.println(data.toString());
		int id = rejectDao.createRejectReasonType(data);
		assertNotNull(id);
	}

}
