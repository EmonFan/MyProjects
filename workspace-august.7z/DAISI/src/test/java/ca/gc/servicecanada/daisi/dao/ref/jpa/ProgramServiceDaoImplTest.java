package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildOrganizationType;
import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildProgramServiceType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.ProgramServiceDao;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse") // -Dspring.profiles.active=development
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class ProgramServiceDaoImplTest {

	@Resource
	ProgramServiceDao referenceDao;

	//@Test
	public void createOrganizationType() {
		OrganizationType data = buildOrganizationType();

		System.out.println(data.toString());
		int id = referenceDao.createOrganizationType(data);
		assertNotNull(id);
	}

	@Test
	public void getAllOrganizationType() {
		List<OrganizationType> data = referenceDao.getAllOrganizationType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (OrganizationType item : data) {
			System.out.println(item);
		}

	}

	@Test
	public void findOrganizationTypeByID() {
		int id = 1;
		OrganizationType data = referenceDao.findOrganizationTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getOrganizationTypeID());
		System.out.println(data);
	}

	@Test
	public void getAllProgramServiceType() {
		List<ProgramServiceType> data = referenceDao.getAllProgramServiceType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (ProgramServiceType item : data) {
			System.out.println(item);
		}

	}

	@Test
	public void findDaisiProgramServiceTypeByID() {
		int id = 1;
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByID(id);
		assertNotNull(data); // FAILED
		assertEquals(id, data.getServiceTypeID());
		System.out.println(data);

	}

	// @Test
	public void createProgramServiceType() {
		ProgramServiceType data = buildProgramServiceType();
		int id = referenceDao.createProgramServiceType(data);
		assertNotNull(id);
	}

	@Test
	public void findProgramServiceTypeByCode() {
		String code = "CPP"; //"1";// "CPP";
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByCode(code);
		assertNotNull(data);
		assertEquals(code, data.getServiceTypeCode());
		System.out.println(data.getServiceTypeCode());
	}

	@Test
	public void findOrganizationTypeByCode() {
		String code = "CRA"; // "1";// "CRA";
		OrganizationType data = referenceDao.findOrganizationTypeByCode(code);
		assertNotNull(data);
		assertEquals(code, data.getOrganizationTypeCode());
		System.out.println(data.getOrganizationTypeCode());
	}

	@Test
	public void findOrganizationTypeByAbrv() {
		String abrv = "ABRV_EN";
		OrganizationType data = referenceDao.findOrganizationTypeByAbrv(abrv, DaoConstants.LANG_EN);
		assertNotNull(data);
		assertEquals(abrv, data.getOrganizationTypeAbrvEn());
		System.out.println(data.getOrganizationTypeAbrvEn());

		abrv = "ABRV_FR";
		data = referenceDao.findOrganizationTypeByAbrv(abrv, DaoConstants.LANG_FR);
		assertNotNull(data);
		assertEquals(abrv, data.getOrganizationTypeAbrvFr());
		System.out.println(data.getOrganizationTypeAbrvFr());
	}

	@Test
	public void findDaisiProgramServiceTypeByAbrv() {
		String abrv = "ABRV_EN";
		ProgramServiceType data = referenceDao.findDaisiProgramServiceTypeByAbrv(abrv, DaoConstants.LANG_EN);
		assertNotNull(data);
		assertEquals(abrv, data.getServiceTypeAbrvEn());
		System.out.println(data.getServiceTypeAbrvEn());

		abrv = "ABRV_FR";
		data = referenceDao.findDaisiProgramServiceTypeByAbrv(abrv, DaoConstants.LANG_FR);
		assertNotNull(data);
		assertEquals(abrv, data.getServiceTypeAbrvFr());
		System.out.println(data.getServiceTypeAbrvFr());
	}
}
