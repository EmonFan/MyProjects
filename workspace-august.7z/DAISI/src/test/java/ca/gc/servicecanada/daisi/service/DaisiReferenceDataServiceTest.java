package ca.gc.servicecanada.daisi.service;

import static org.junit.Assert.assertNotNull;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:services-context.xml" })
public class DaisiReferenceDataServiceTest {
	@Resource
	DaisiReferenceDataService svs;

	@Test
	public void testGetAllProgramServiceType() {
		svs.getAllProgramServiceType();
		System.out.println("\n\n -- cached? \n  ");
		svs.getAllProgramServiceType();
		System.out.println("\n\n -- done -- \n  ");

	}

	@Test
	public void findChannelTypeByCode() {
		String channelTypeCode = "ONL";
		ChannelType t1 = svs.findChannelTypeByCode(channelTypeCode);
		System.out.println("\n\n -- cached? \n  ");
		ChannelType t2 = svs.findChannelTypeByCode(channelTypeCode);
		System.out.println("\n\n -- cached? \n  ");
		ChannelType t3 = svs.findChannelTypeByCode(channelTypeCode);
		System.out.println("\n\n -- done -- \n  ");

	}

	@Test
	public void findDaisiProgramServiceTypeByCode() {
		String code = "";
		ProgramServiceType t =  svs.findDaisiProgramServiceTypeByCode(code);
		assertNotNull(t);

	}

	@Configuration
	@PropertySource("classpath:daisi.properties")
	public static class MyContextConfiguration {

	}
}