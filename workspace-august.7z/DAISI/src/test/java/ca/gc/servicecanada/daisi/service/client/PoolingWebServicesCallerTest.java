package ca.gc.servicecanada.daisi.service.client;

import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:services-context.xml" })
public class PoolingWebServicesCallerTest {

	@Resource
	PoolingWebServicesCaller  ws;
	
	@Test
	public void test() {
		String request ="http://localhost:7001/daisi-jpa-0.0.1-SNAPSHOT/DaisiReferenceData/DaisiReferenceData/ProgramServiceTypes";
		String json = ws.executeGet(request);
		assertNotNull(json);
		System.out.println("\n\n"+json);
	}

}
