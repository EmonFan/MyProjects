package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.constants.DaoConstants;
import ca.gc.servicecanada.daisi.dao.ref.EventLogTypeDao;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse") // -Dspring.profiles.active=development
//@ContextConfiguration(locations = { "classpath:test-dao-context.xml" }) //H2
@ContextConfiguration(locations = { "classpath:dao-context.xml" })   //Oracle
public class EventLogTypeDaoImplTest {

	@Resource
	EventLogTypeDao eventLogTypeDao;

	@Test
	public void findEventLogTypeByID() {
		int id = 1;
		EventLogType data = eventLogTypeDao.findEventLogTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getEventLogTypeID());
		System.out.println(data);

	}

	@Test
	public void getAllEventLogType() {
		List<EventLogType> data = eventLogTypeDao.getAllEventLogType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (EventLogType item : data) {
			System.out.println(item);

		}
	}

	@Test
	public void findEventLogTypeByCode() {
		String code = "PRO";
		EventLogType data = eventLogTypeDao.findEventLogTypeByCode(code);
		assertNotNull(data);
		assertEquals(code, data.getEventLogTypeCode());
		System.out.println(data.getEventLogTypeCode());

	}

	@Test
	public void findEventLogTypeByAbrv() {
		String EventLogTypeAbrv= "ERR";
		EventLogType data = eventLogTypeDao.findEventLogTypeByAbrv(EventLogTypeAbrv, DaoConstants.LANG_EN); 
		assertNotNull(data);
		assertEquals(EventLogTypeAbrv, data.getEventLogTypeAbrvEn());
		System.out.println(data.getEventLogTypeAbrvEn());

		EventLogTypeAbrv= "ABRV_FR";
		data = eventLogTypeDao.findEventLogTypeByAbrv(EventLogTypeAbrv, DaoConstants.LANG_FR); 
		assertNotNull(data);
		assertEquals(EventLogTypeAbrv, data.getEventLogTypeAbrvFr());
		System.out.println(data.getEventLogTypeAbrvFr());
	}
}
