package ca.gc.servicecanada.daisi.dao.ref.jpa;

import java.util.Date;
import java.util.Random;

import ca.gc.servicecanada.daisi.domain.ref.ActionType;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.InformationType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;

public class MockObjectHelper {

	static Date dateCreated = new Date();
	static Date dateUpdated = new Date();
	static Date effectiveDate = new Date();
	static Date expiryDate = new Date();

	static String serviceTypeNameEn = "Name EN";
	static String serviceTypeNameFr = "Name FR";
	static String systemCreated = "DAISI-JPA";
	static String userCreated = "Vitaly";
	static String userUpdated = "Vitaly";

	public static ConsentStatementType buildConsentStatementType() {
		ConsentStatementType data = new ConsentStatementType();
		ChannelType channelType = buildChannelType();
		data.setChannelType(channelType);
		// CONSENT_STATEMENT_TYPE_CODE

		String consentStatementTypeAbrvEn = "consAbrvE";
		String consentStatementTypeAbrvFr = "consAbrvF";
		String consentStatementTypeCode = "123";
		String consentStatementTypeDescEn = "consent Statement Type Desc ... En";
		String consentStatementTypeDescFr = "consent Statement Type Desc ... Fr";
		int consentStatementTypeID = (new Random()).nextInt(1000);
		String consentStatementTypeNameEn = "name E";
		String consentStatementTypeNameFr = "name F";

		String consentStatementTypeYear = "17";
		String consentCode = "AA";
		String consentStatementTypeVersion = "1";

		data.setConsentStatementTypeAbrvEn(consentStatementTypeAbrvEn);
		data.setConsentStatementTypeAbrvFr(consentStatementTypeAbrvFr);
		data.setConsentStatementTypeCode(consentStatementTypeCode);
		data.setConsentStatementTypeDescEn(consentStatementTypeDescEn);
		data.setConsentStatementTypeDescFr(consentStatementTypeDescFr);
		data.setConsentStatementTypeID(consentStatementTypeID);
		data.setConsentStatementTypeNameEn(consentStatementTypeNameEn);
		data.setConsentStatementTypeNameFr(consentStatementTypeNameFr);

		data.setConsentCode(consentCode);
		data.setConsentStatementTypeVersion(consentStatementTypeVersion);
		data.setConsentStatementTypeYear(consentStatementTypeYear);

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;

	}

	public static ChannelType buildChannelType() {
		String channelTypeAbrvEn = "AbrvEn";
		String channelTypeAbrvFr = "AbrvFr";
		String channelTypeCode = "ABC";
		String channelTypeDescEn = "channelTypeDescEn";
		String channelTypeDescFr = "channelTypeDescFr";
		String channelTypeNameEn = "channelTypeNameEn";
		String channelTypeNameFr = "channelTypeNameFr";

		ChannelType data = new ChannelType();
		int channelTypeID = (new Random()).nextInt(100);
		data.setChannelTypeID(channelTypeID);

		data.setChannelTypeAbrvEn(channelTypeAbrvEn);
		data.setChannelTypeAbrvFr(channelTypeAbrvFr);
		data.setChannelTypeCode(channelTypeCode);
		data.setChannelTypeDescEn(channelTypeDescEn);
		data.setChannelTypeDescFr(channelTypeDescFr);
		data.setChannelTypeNameEn(channelTypeNameEn);
		data.setChannelTypeNameFr(channelTypeNameFr);
		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;
	}

	public static ProgramServiceType buildProgramServiceType() {

		OrganizationType organizationType = buildOrganizationType();

		String serviceTypeAbrvEn = "CPP";
		String serviceTypeAbrvFr = "PPC";
		String serviceTypeCode = "CPP";
		String serviceTypeDescEn = "Canadian Pension Plan";
		String serviceTypeDescFr = "Plan Pension Canadienne";
		int serviceTypeID = 10;
		String serviceTypeNameEn = "Name EN";
		String serviceTypeNameFr = "Name FR";

		ProgramServiceType data = new ProgramServiceType();
		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		// data.setOrganizationTypeID(organizationTypeID);
		data.setOrganizationType(organizationType);
		data.setServiceTypeAbrvEn(serviceTypeAbrvEn);
		data.setServiceTypeAbrvFr(serviceTypeAbrvFr);
		data.setServiceTypeCode(serviceTypeCode);
		data.setServiceTypeDescEn(serviceTypeDescEn);
		data.setServiceTypeDescFr(serviceTypeDescFr);
		data.setServiceTypeID(serviceTypeID);
		data.setServiceTypeNameEn(serviceTypeNameEn);
		data.setServiceTypeNameFr(serviceTypeNameFr);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setUserUpdated(userUpdated);

		return data;

	}

	public static OrganizationType buildOrganizationType() {
		OrganizationType data = new OrganizationType();

		String organizationTypeAbrvEn = "CPP";
		String organizationTypeAbrvFr = "PPC";
		String organizationTypeDescEn = "Canadian Pension Plan";
		String organizationTypeDescFr = "Pension Plan Canadienne";
		int organizationTypeID = 2;
		String organizationTypeNameEn = "jhsd";
		String organizationTypeNameFr = "acasdc";
		String organiztionTypeCode = "CPP";

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);

		data.setOrganizationTypeAbrvEn(organizationTypeAbrvEn);
		data.setOrganizationTypeAbrvFr(organizationTypeAbrvFr);
		data.setOrganizationTypeDescEn(organizationTypeDescEn);
		data.setOrganizationTypeDescFr(organizationTypeDescFr);
		data.setOrganizationTypeID(organizationTypeID);
		data.setOrganizationTypeNameEn(organizationTypeNameEn);
		data.setOrganizationTypeNameFr(organizationTypeNameFr);
		data.setOrganizationTypeCode(organiztionTypeCode);

		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setUserUpdated(userUpdated);

		return data;
	}

	public static ActionType buildActionType() {
		ActionType data = new ActionType();
		String actionTypeAbrvEn = "actionAbrE";
		String actionTypeAbrvFr = "actionAbrF";
		String actionTypeDescEn = "actionTypeDescEn";
		String actionTypeDescFr = "actionTypeDescFr";
		int actionTypeID = (new Random()).nextInt(1000);
		String actionTypeNameEn = "actionTypeNameEn";
		String actionTypeNameFr = "actionTypeNameFr";
		String actionTypeCode = "22";

		data.setActionTypeAbrvEn(actionTypeAbrvEn);
		data.setActionTypeAbrvFr(actionTypeAbrvFr);
		data.setActionTypeDescEn(actionTypeDescEn);
		data.setActionTypeDescFr(actionTypeDescFr);
		data.setActionTypeID(actionTypeID);
		data.setActionTypeNameEn(actionTypeNameEn);
		data.setActionTypeNameFr(actionTypeNameFr);
		data.setActionTypeCode(actionTypeCode);

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;

	}

	public static InformationType buildInformationType() {
		InformationType data = new InformationType();
		String infoTypeAbrvEn = "infoAbrE";
		String infoTypeAbrvFr = "infoAbrF";
		String infoTypeDescEn = "infoTypeDescEn";
		String infoTypeDescFr = "infoTypeDescFr";
		int infoTypeID = (new Random()).nextInt(1000);
		String infoTypeNameEn = "infoTypeNameEn";
		String infoTypeNameFr = "infoTypeNameFr";
		String infoTypeCode = "22";

		data.setInformationTypeAbrvEn(infoTypeAbrvEn);
		data.setInformationTypeAbrvFr(infoTypeAbrvFr);
		data.setInformationTypeDescEn(infoTypeDescEn);
		data.setInformationTypeDescFr(infoTypeDescFr);
		data.setInformationTypeID(infoTypeID);
		data.setInformationTypeNameEn(infoTypeNameEn);
		data.setInformationTypeNameFr(infoTypeNameFr);
		data.setInformationTypeCode(infoTypeCode);

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;
	}
	
	
	public static RejectReasonType buildRejectReasonType() {
		RejectReasonType data = new RejectReasonType();
		String regectReasonTypeAbrvEn = "infoAbrE";
		String regectReasonTypeAbrvFr = "infoAbrF";
		String regectReasonTypeDescEn = "regectReasonTypeDescEn";
		String regectReasonTypeDescFr = "regectReasonTypeDescFr";
		int regectReasonTypeID = (new Random()).nextInt(1000);
		String infoTypeNameEn = "regectReasonTypeNameEn";
		String regectReasonTypeNameFr = "regectReasonTypeNameFr";
		String regectReasonTypeNameEn = "regectReasonTypeNameEn";
		String regectReasonTypeCode = "22";

		data.setRejectReasonTypeAbrvEn(regectReasonTypeAbrvEn);
		data.setRejectReasonTypeAbrvFr(regectReasonTypeAbrvFr);
		data.setRejectReasonTypeDescEn(regectReasonTypeDescEn);
		data.setRejectReasonTypeDescFr(regectReasonTypeDescFr);
		data.setRejectReasonTypeID(regectReasonTypeID);
		data.setRejectReasonTypeNameEn(regectReasonTypeNameEn);
		data.setRejectReasonTypeNameFr(regectReasonTypeNameFr);
		data.setRejectReasonTypeCode(regectReasonTypeCode);

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;
	}
	
	public static TransactionType buildTransactionType() {
		TransactionType data = new TransactionType();
		int transactionTypeID= (new Random()).nextInt(1000);

		InformationType informationType = buildInformationType();
		ActionType actionType= buildActionType();
		data .setActionType(actionType);
		data .setInformationType(informationType);
		data.setTransactionTypeID(transactionTypeID);

		data.setDateCreated(dateCreated);
		data.setDateUpdated(dateUpdated);
		data.setEffectiveDate(effectiveDate);
		data.setExpiryDate(expiryDate);
		data.setSystemCreated(systemCreated);
		data.setUserCreated(userCreated);
		data.setDateUpdated(dateUpdated);
		data.setUserUpdated(userUpdated);
		return data;
	}

	
	
}
