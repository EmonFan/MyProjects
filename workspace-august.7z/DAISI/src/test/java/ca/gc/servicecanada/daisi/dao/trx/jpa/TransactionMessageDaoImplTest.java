package ca.gc.servicecanada.daisi.dao.trx.jpa;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.dao.trx.TechnicalTransactionDao;
import ca.gc.servicecanada.daisi.dao.trx.TransactionMessageDao;
import ca.gc.servicecanada.daisi.domain.trx.TransactionMessage;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransactionStatus;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransactionStatus_;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction_;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;


@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class TransactionMessageDaoImplTest {
	
	@Resource
	TransactionMessageDao dao;

	@Resource
	BusinessTransactionDao businessTransactionDao;
	
	@Resource
	TechnicalTransactionDao technicalTransactionDao;	
	
	@Test
	public void getAllTransactionMessages() {
		List<TransactionMessage> data = dao.getAllTransactionMessages();
		assertNotNull(data);
		for (TransactionMessage item : data) {
			System.out.println(item);
			assertNotNull(item.getTechnicalTransaction());
		}
	}

	@Test
	public void findTransactionMessageByTransactionID() {
		int trxId = 1;
		List<TransactionMessage> data = dao.findTransactionMessageByTransactionID(trxId);
		assertNotNull(data);
		for (TransactionMessage item : data) {
			System.out.println(item);
			assertNotNull(item.getTechnicalTransaction());
		}
	}
	
	
	@Test
	public void createTransactionMessage() {
		TransactionMessage transactionMessage = new TransactionMessage();
		transactionMessage.setMessageID(null);
		
		String systemCreated = "TEST";
//		TechnicalTransaction technicalTransaction = createTechnicalTransaction();
		String userCreated = "Billy Bones";
		
		Date now = new Date();
		Date dateCreated = now;	
		Date messageDateTime = now;
		transactionMessage.setDateCreated(dateCreated);
		transactionMessage.setMessageDateTime(messageDateTime);
		transactionMessage.setDateUpdated(null);
		
		transactionMessage.setMessageID("testMessageID");
		
		transactionMessage.setSystemCreated(systemCreated);
		transactionMessage.setUserCreated(userCreated);
		
		transactionMessage.setUserUpdated(null);
//		transactionMessage.setTechnicalTransaction(technicalTransaction);
//		dao.createTransactionMessage(transactionMessage);
	}
	

	@Test
	public void findTransactionMessageBySin() {
		String sin = "111222333";
		List<TransactionMessage> data = dao.findTransactionMessageBySIN(sin);
		assertNotNull(data);
		for (TransactionMessage item : data) {
			System.out.println(item);
			assertNotNull(item.getTechnicalTransaction());
		}	
	}

	String techTransactionId = "theTechTransID";
	
	public TechnicalTransaction createTechnicalTransaction()
	{
	TechnicalTransaction technicalTransaction = new TechnicalTransaction();
	
	Date dtSys = Calendar.getInstance().getTime();
	technicalTransaction.setDateCreated(dtSys);
	DDBusinessTransaction ddBusinessTransaction = (DDBusinessTransaction) loadTransaction();
	technicalTransaction.setBusinessTransaction(ddBusinessTransaction);
	technicalTransaction.setSystemCreated("INIT");
	technicalTransaction.setUserCreated("REFOWNR");
	Date now = new Date();
	technicalTransaction.setTechnicalTransactionID(techTransactionId);
	technicalTransaction.setTechnicalTransactionDate(now);
	//TechnicalTransaction techTransDelta = (TechnicalTransaction) technicalTransactionDao.create(technicalTransaction);
	//assertNotNull(techTransDelta);
	//System.out.println(techTransDelta);	
	return technicalTransaction;
			
	}
	
	private BusinessTransaction loadTransaction() {
		List<BusinessTransaction> allBusinessTransactions = businessTransactionDao.getAllBusinessTransaction();
		DDBusinessTransaction ddBusinessTransaction = null;
		if(allBusinessTransactions.size()>0){
			ddBusinessTransaction  = (DDBusinessTransaction) allBusinessTransactions.get(0); 
		}else{
			String sin = "111222333";
			ddBusinessTransaction = new DDBusinessTransaction();
			ddBusinessTransaction.setInstitutionNumber("099");
			ddBusinessTransaction.setTransitNumber("3456");
			ddBusinessTransaction.setAccountNumber("2233445");
			ddBusinessTransaction.setSin(sin);
			Date dt = Calendar.getInstance().getTime();
			ddBusinessTransaction.setDateCreated(dt);
			ddBusinessTransaction.setSystemCreated("JUNIT");
			ddBusinessTransaction.setUserCreated("REFOWNR");
		}
		return ddBusinessTransaction;
	}	
	
	
	
//	private TechnicalTransaction loadTechnicalTransaction() {
//		List<TechnicalTransaction> allTechnicalTransactions = businessTransactionDao.getAllTechnicalTransaction();
//		TechnicalTransaction  technicalTransaction = null;
//		if(allTechnicalTransactions.size()>0){
//			technicalTransaction = allTechnicalTransactions.get(0); 
//		}else{
//			String sin = "111222333";
//			DDBusinessTransaction ddBusinesTransaction = new DDBusinessTransaction();
//			ddBusinesTransaction.setBusinessTransactionID(""+(new java.util.Random()).nextInt(10000));
//			ddBusinesTransaction.setInstitutionNumber("099");
//			ddBusinesTransaction.setTransitNumber("3456");
//			ddBusinesTransaction.setAccountNumber("2233445");
//			ddBusinesTransaction.setSin(sin);
//			Date dt = Calendar.getInstance().getTime();
//			ddBusinesTransaction.setDateCreated(dt);
//			ddBusinesTransaction.setSystemCreated("JUNIT");
//			ddBusinesTransaction.setUserCreated("REFOWNR");
//			
//			technicalTransaction = new TechnicalTransaction();
//			technicalTransaction.setBusinessTransaction(ddBusinesTransaction);
//			technicalTransaction.setDateCreated(new Date());
//			technicalTransaction.setSystemCreated("JUNIT");
//		}
//		return technicalTransaction;
//	}
		
}
