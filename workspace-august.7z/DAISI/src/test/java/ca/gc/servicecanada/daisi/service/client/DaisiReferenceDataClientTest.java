package ca.gc.servicecanada.daisi.service.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:services-context.xml" })
public class DaisiReferenceDataClientTest {

	@Resource
	DaisiReferenceDataClient daisiReferenceDataClient;

	// @Test
	public void test() {
		List<ProgramServiceType> data = daisiReferenceDataClient.getProgramServiceTypes();
		assertNotNull(data);
		assertTrue(data.size() > 0);

		for (ProgramServiceType item : data) {
			System.out.println(item);
		}
	}

	//@Test
	public void transfromProgramServiceTypes() {

		List<ProgramServiceType> data = daisiReferenceDataClient.transfromProgramServiceTypes(json);
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (ProgramServiceType item : data) {
			System.out.println(item);
		}
	}

	@Test
	public void transfromProgramServiceType() {

		ProgramServiceType data = daisiReferenceDataClient.transfromProgramServiceType(json2);
		assertNotNull(data);
		System.out.println(data);
	}
	

	@Configuration
	@PropertySource("classpath:daisi.properties")
	public static class MyContextConfiguration {

	}

	String json = "[{\"serviceTypeID\":1,\"organizationType\":{\"organizationTypeID\":1,\"organiztionTypeCode\":\"1\",\"organizationTypeNameEn\":\"ESDC\",\"organizationTypeNameFr\":\"EDSC\",\"organizationTypeDescEn\":null,\"organizationTypeDescFr\":null,\"organizationTypeAbrvEn\":null,\"organizationTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},\"serviceTypeCode\":\"1\",\"serviceTypeNameEn\":\"EI - Employment Insurance Benefits\",\"serviceTypeNameFr\":\"French EI\",\"serviceTypeDescEn\":null,\"serviceTypeDescFr\":null,\"serviceTypeAbrvEn\":null,\"serviceTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},{\"serviceTypeID\":2,\"organizationType\":{\"organizationTypeID\":1,\"organiztionTypeCode\":\"1\",\"organizationTypeNameEn\":\"ESDC\",\"organizationTypeNameFr\":\"EDSC\",\"organizationTypeDescEn\":null,\"organizationTypeDescFr\":null,\"organizationTypeAbrvEn\":null,\"organizationTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},\"serviceTypeCode\":\"2\",\"serviceTypeNameEn\":\"CPP - Canada Pension Plan\",\"serviceTypeNameFr\":\"French CPP\",\"serviceTypeDescEn\":null,\"serviceTypeDescFr\":null,\"serviceTypeAbrvEn\":null,\"serviceTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},{\"serviceTypeID\":3,\"organizationType\":{\"organizationTypeID\":1,\"organiztionTypeCode\":\"1\",\"organizationTypeNameEn\":\"ESDC\",\"organizationTypeNameFr\":\"EDSC\",\"organizationTypeDescEn\":null,\"organizationTypeDescFr\":null,\"organizationTypeAbrvEn\":null,\"organizationTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},\"serviceTypeCode\":\"3\",\"serviceTypeNameEn\":\"OAS - Old Age Security\",\"serviceTypeNameFr\":\"French OAS\",\"serviceTypeDescEn\":null,\"serviceTypeDescFr\":null,\"serviceTypeAbrvEn\":null,\"serviceTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},{\"serviceTypeID\":4,\"organizationType\":{\"organizationTypeID\":2,\"organiztionTypeCode\":\"2\",\"organizationTypeNameEn\":\"CRA\",\"organizationTypeNameFr\":\"CRA\",\"organizationTypeDescEn\":null,\"organizationTypeDescFr\":null,\"organizationTypeAbrvEn\":null,\"organizationTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},\"serviceTypeCode\":\"4\",\"serviceTypeNameEn\":\"CRA\",\"serviceTypeNameFr\":\"CRA-french\",\"serviceTypeDescEn\":null,\"serviceTypeDescFr\":null,\"serviceTypeAbrvEn\":null,\"serviceTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null}][\r][\n]";

	String json2 = "{\"serviceTypeID\":1,\"organizationType\":{\"organizationTypeID\":1,\"organiztionTypeCode\":\"1\",\"organizationTypeNameEn\":\"ESDC\",\"organizationTypeNameFr\":\"EDSC\",\"organizationTypeDescEn\":null,\"organizationTypeDescFr\":null,\"organizationTypeAbrvEn\":null,\"organizationTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null},\"serviceTypeCode\":\"1\",\"serviceTypeNameEn\":\"EI - Employment Insurance Benefits\",\"serviceTypeNameFr\":\"French EI\",\"serviceTypeDescEn\":null,\"serviceTypeDescFr\":null,\"serviceTypeAbrvEn\":null,\"serviceTypeAbrvFr\":null,\"effectiveDate\":1495684800000,\"expiryDate\":null,\"dateCreated\":1495736467000,\"systemCreated\":\"INIT\",\"userCreated\":\"REFOWNR\",\"dateUpdated\":null,\"userUpdated\":null}";

}
