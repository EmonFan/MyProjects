package ca.gc.servicecanada.daisi.dao.ref.jpa;

import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildActionType;
import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildInformationType;
import static ca.gc.servicecanada.daisi.dao.ref.jpa.MockObjectHelper.buildTransactionType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.ref.TransactionTypeDao;
import ca.gc.servicecanada.daisi.domain.ref.ActionType;
import ca.gc.servicecanada.daisi.domain.ref.InformationType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class TransactionTypeDaoImplTest {

	@Resource
	TransactionTypeDao trxTypeDao;

	@Test
	public void findTransactionTypeByActionInfoCodes() {
		String actionCode = "Send";
		String InfoCode = "Direct Deposit";
		TransactionType data = trxTypeDao.findTransactionTypeByActionAndInfoTypeNames(actionCode, InfoCode);
		assertNotNull(data);
		System.out.println(data);
	}

	@Test
	public void getAllActionType() {
		List<ActionType> data = trxTypeDao.getAllActionType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (ActionType item : data) {
			System.out.println(item);
		}

	}

	@Test
	public void findActionTypeByID() {
		int id = 1;
		ActionType data = trxTypeDao.findActionTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getActionTypeID());
		System.out.println(data);

	}

	// @Test
	public void createActionType() {
		ActionType data = buildActionType();
		System.out.println(data.toString());
		int id = trxTypeDao.createActionType(data);
		assertNotNull(id);
	}

	// ------------- InformationType

	@Test
	public void getAllInformationType() {
		List<InformationType> data = trxTypeDao.getAllInformationType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (InformationType item : data) {
			System.out.println(item);
		}

	}

	@Test
	public void findInformationTypeByID() {
		int id = 1;
		InformationType data = trxTypeDao.findInformationTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getInformationTypeID());
		System.out.println(data);

	}

	// @Test
	public void createInformationType() {
		InformationType data = buildInformationType();
		System.out.println(data.toString());
		int id = trxTypeDao.createInformationType(data);
		assertNotNull(id);
	}

	// ------------- TransactionType

	@Test
	public void getAllTransactionType() {
		List<TransactionType> data = trxTypeDao.getAllTransactionType();
		assertNotNull(data);
		assertTrue(data.size() > 0);
		for (TransactionType item : data) {
			System.out.println(item);
		}
	}

	@Test
	public void findTransactionTypeByID() {
		int id = 1;
		TransactionType data = trxTypeDao.findTransactionTypeByID(id);
		assertNotNull(data);
		assertEquals(id, data.getTransactionTypeID());
		System.out.println("\n\n" + data);

	}

	// @Test
	public void createTransactionType() {
		TransactionType data = buildTransactionType();
		System.out.println(data.toString());
		int id = trxTypeDao.createTransactionType(data);
		assertNotNull(id);
	}

}
