package ca.gc.servicecanada.daisi.service.json;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.ref.ProgramServiceDao;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:services-context.xml" })
public class JsonSerializerTest {

	@Resource
	JsonSerializer jsonSerializer;

	@Resource
	ProgramServiceDao referenceDao;

	@Test
	public void testSerialize() {
		List<ProgramServiceType> data = referenceDao.getAllProgramServiceType();
		String json = jsonSerializer.serialize(data);

		System.out.println(json);
	}

	@Configuration
	@PropertySource("classpath:daisi.properties")
	public static class MyContextConfiguration {

	}

}
