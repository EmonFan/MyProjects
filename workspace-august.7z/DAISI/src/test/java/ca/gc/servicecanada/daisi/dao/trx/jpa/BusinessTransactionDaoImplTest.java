package ca.gc.servicecanada.daisi.dao.trx.jpa;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.ref.StatusDao;
import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransactionStatus;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
// @ContextConfiguration(locations = { "classpath:test-dao-context.xml" })
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
// @ContextConfiguration(locations = { "classpath:db-context.xml" })
public class BusinessTransactionDaoImplTest {

	@Resource
	BusinessTransactionDao dao;

	@Resource
	StatusDao statusDao;


	@Test
	public void getAllBusinessTransaction() {
		List<BusinessTransaction> trx = null;
		trx = dao.findBusinessTransactionBySIN("111222333");
		Assert.assertNotNull(trx);
	}

	@Test
	public void getAllTechnicalTransaction() {

		final List<TechnicalTransaction> data = dao.getAllTechnicalTransaction();
		Assert.assertNotNull(data);
		System.out.println(data);
	}

	@Test
	public void findBusinessTransactionByID() {
		final int id = 50;
		final BusinessTransaction trx = dao.findBusinessTransactionByID(id);
		Assert.assertNotNull(trx);
		System.out.println(trx);
	}

	@Test
	public void findBusinessTransactionBySIN() {
		final String sin = "111222333";
		final List<BusinessTransaction> data = dao.findBusinessTransactionBySIN(sin);
		Assert.assertNotNull(data);
		for (final BusinessTransaction item : data) {
			System.out.println(item);
		}
	}

	@Test
	public void create() {

		DDBusinessTransaction bt = init();
		final DDBusinessTransaction btDelta = (DDBusinessTransaction) dao.create(bt);
		Assert.assertNotNull(btDelta);
		System.out.println(btDelta);
	}
	
	
	@Test
	public void update() {	
		DDBusinessTransaction bt = init();
		DDBusinessTransaction created  = (DDBusinessTransaction) dao.create(bt);
		
		created.setAccountNumber("777");
		created.setUserUpdated("UPDATE");
		created.setDateUpdated(new Date());
		BusinessTransaction  updated = dao.update(created);
		
		
	}
	
	DDBusinessTransaction init(){
		final String sin = "111222333";
		final DDBusinessTransaction bt = new DDBusinessTransaction();
		bt.setBusinessTransactionID("" + (new java.util.Random()).nextInt(10000));
		bt.setInstitutionNumber("003");
		bt.setTransitNumber("3456");
		bt.setAccountNumber("2233445");
		bt.setSin(sin);
		final Date dt = Calendar.getInstance().getTime();
		bt.setDateCreated(dt);
		bt.setSystemCreated("JUNIT");
		bt.setUserCreated("VITALY");

		final List<TechnicalTransaction> tTrxs = new ArrayList<>();

		final TechnicalTransaction tt = new TechnicalTransaction();

		tt.setBusinessTransaction(bt);

		tt.setDateCreated(new Date());
		tt.setSystemCreated("JUNIT");
		tt.setUserCreated("VITALY");

		final String technicalTransactionID = "" + (new java.util.Random()).nextInt(10000);
		tt.setTechnicalTransactionID(technicalTransactionID);

		tTrxs.add(tt);

		bt.setTechnicalTransactions(tTrxs);

		Set<BusinessTransactionStatus> trxStatuses = new HashSet<>();

		final BusinessTransactionStatus bts = new BusinessTransactionStatus();

		trxStatuses.add(bts);

		//bts.setBusinessTransaction(bt);
		final Date now = new Date();
		final Date dateCreated = now;
		bts.setEffectiveDate(now);

		bts.setDateCreated(dateCreated);
		bts.setSystemCreated("JUNITSYS");
		bts.setUserCreated("JUNITUSR");

		bts.setDateUpdated(null);
		bts.setUserUpdated(null);

		bt.setBusinessTransactionStatuses(trxStatuses);

		final StatusType statusType = statusDao.findStatusTypeByID(1);
		bts.setStatusType(statusType);
		return bt;
		
	}

}
