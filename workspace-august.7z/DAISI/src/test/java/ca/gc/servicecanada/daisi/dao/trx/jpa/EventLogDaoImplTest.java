package ca.gc.servicecanada.daisi.dao.trx.jpa;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.dao.trx.EventLogDao;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:dao-context.xml" })
public class EventLogDaoImplTest {

	@Resource
	EventLogDao dao;

	// @Test
	public void getAllEventLogs() {
		List<EventLog> data = dao.getAllEventLogs();
		assertNotNull(data);
		for (EventLog item : data) {
			System.out.println(item);
			assertNotNull(item.getTechnicalTransaction());
		}

	}

	@Test
	public void findEventLogByTransactionID() {
		int trxId = 1;
		List<EventLog> data = dao.findEventLogByTransactionID(trxId);
		assertNotNull(data);
		for (EventLog item : data) {
			System.out.println(item);
			assertNotNull(item.getTechnicalTransaction());
		}
	}

	@Test
	public void createEventLog() {
		EventLog event = new EventLog();
		EventLogType eventLogType = new EventLogType();

		Date now = new Date();
		Date dateCreated = now;
		Date eventDate = now;
		String systemCreated = "TEST";
		TechnicalTransaction techTransaction = loadTransaction();
		String userCreated = "Billy Bones";

		event.setDateCreated(dateCreated);
		event.setDateUpdated(null);
		event.setEventDate(eventDate);
		event.setSystemCreated(systemCreated);
		event.setTechnicalTransaction(techTransaction);
		event.setUserCreated(userCreated);
		event.setUserUpdated(null);

		// ------
		eventLogType.setEventLogTypeID(1);
		event.setEventLogType(eventLogType);

		//Don't commit until we can get the memory database working. This tries
		//to create a duplicate key and fails
//		dao.createEventLog(event);

	}

	@Resource
	BusinessTransactionDao trxDao;

	TechnicalTransaction loadTransaction() {
		List<TechnicalTransaction> allTechnicalTransactions = trxDao.getAllTechnicalTransaction();
		TechnicalTransaction  technicalTransaction = null;
		if(allTechnicalTransactions.size()>0){
			technicalTransaction  = allTechnicalTransactions.get(0); 
		}else{
			String sin = "111222333";
			DDBusinessTransaction ddBusinessTransaction = new DDBusinessTransaction();
			ddBusinessTransaction.setBusinessTransactionID(""+(new java.util.Random()).nextInt(10000));
			ddBusinessTransaction.setInstitutionNumber("099");
			ddBusinessTransaction.setTransitNumber("3456");
			ddBusinessTransaction.setAccountNumber("2233445");
			ddBusinessTransaction.setSin(sin);
			Date dt = Calendar.getInstance().getTime();
			ddBusinessTransaction.setDateCreated(dt);
			ddBusinessTransaction.setSystemCreated("JUNIT");
			ddBusinessTransaction.setUserCreated("REFOWNR");
			
			technicalTransaction = new TechnicalTransaction();
			technicalTransaction.setBusinessTransaction(ddBusinessTransaction);
			technicalTransaction.setDateCreated(new Date());
			technicalTransaction.setSystemCreated("JUNIT");
			String technicalTransactionID = ""+(new java.util.Random()).nextInt(10000);
			technicalTransaction.setTechnicalTransactionID(technicalTransactionID);

		}
		return technicalTransaction;
	}

	// @Test
	public void findEventLogBySin() {
		fail("Not yet implemented");
	}

}
