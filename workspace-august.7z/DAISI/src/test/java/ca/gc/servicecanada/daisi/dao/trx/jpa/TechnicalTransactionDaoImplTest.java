package ca.gc.servicecanada.daisi.dao.trx.jpa;

import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.dao.trx.BusinessTransactionDao;
import ca.gc.servicecanada.daisi.dao.trx.TechnicalTransactionDao;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;

@RunWith(SpringJUnit4ClassRunner.class)
//@ActiveProfiles("eclipse")
//@Import(DaisiDataSourceConfiguration.class)
//@ContextConfiguration(classes = {ApplicationContextConfig.class})
@Transactional
public class TechnicalTransactionDaoImplTest {

	@Resource
	TechnicalTransactionDao technicalTransactionDao;
	
	@Resource
	BusinessTransactionDao businessTransactionDao;
	
	String techTransactionId = "theTechTransID";
	
	//TechnicalTransaction create(TechnicalTransaction technicalTransaction);
	@Test
	public void create()
	{
	TechnicalTransaction technicalTransaction = new TechnicalTransaction();
	
//	Date dtSys = Calendar.getInstance().getTime();
//	technicalTransaction.setDateCreated(dtSys);
//	DDBusinessTransaction ddBusinessTransaction = (DDBusinessTransaction) loadTransaction();
//	technicalTransaction.setBusinessTransaction(ddBusinessTransaction);
//	technicalTransaction.setSystemCreated("INIT");
//	technicalTransaction.setUserCreated("REFOWNR");
//	Date now = new Date();
//	technicalTransaction.setTechnicalTransactionID(techTransactionId);
//	technicalTransaction.setTechnicalTransactionDate(now);
//	TechnicalTransaction techTransDelta = (TechnicalTransaction) technicalTransactionDao.create(technicalTransaction);
//	assertNotNull(techTransDelta);
//	System.out.println(techTransDelta);			
	}
	
	
	//List<TechnicalTransaction> getAllTechnicalTransactions();
	@Test
	public void  getAllTechnicalTransactions()  
	{
		List<TechnicalTransaction> techincalTransactions = technicalTransactionDao.getAllTechnicalTransactions();
		assertNotNull(techincalTransactions);		
	}


	//TechnicalTransaction findTechnicalTransactionByTransID(int id);
	@Test
	public void findTechnicalTransactionByTransID()  
	{

		List<TechnicalTransaction> technicalTransactions = technicalTransactionDao.getAllTechnicalTransactions();
		if (technicalTransactions.size() > 0)
		{
			TechnicalTransaction technicalTransaction = technicalTransactions.get(0);
			int id  = technicalTransaction.getTransactionID();
			TechnicalTransaction technicalTransactionByTechnicalTransId = technicalTransactionDao.findTechnicalTransactionByTechnicalTransID(id);
			assertNotNull(technicalTransactionByTechnicalTransId);	
		}
		else
		{
			fail("Nothing to test against");
		}			
	}
	
	//List<TechnicalTransaction> findTechnicalTransactionByBusinessTransactionId(int id);
	@Test  
	public void findTechnicalTransactionByBusinessTransactionId()  
	{
		List<TechnicalTransaction> technicalTransactions = technicalTransactionDao.getAllTechnicalTransactions();
		if (technicalTransactions.size() > 0)
		{
			TechnicalTransaction technicalTransaction = technicalTransactions.get(0);
			int id  = technicalTransaction.getBusinessTransaction().getId();
			List<TechnicalTransaction> technicalTransactionsById = technicalTransactionDao.findTechnicalTransactionsByBusinessTransactionId(id);
			assertNotNull(technicalTransactionsById);	
		}
		else
		{
			fail("Nothing to test against");
		}		
	}

	//List<TechnicalTransaction> findTechnicalTransactionByTechnicalTransactionId(int id);	
	@Test
	public void findTechnicalTransactionByTechnicalTransactionId()
	{
		List<TechnicalTransaction> technicalTransactions = technicalTransactionDao.findTechnicalTransactionsByTechnicalTransactionId(techTransactionId);
		assertNotNull(technicalTransactions);			
	}
	
	private BusinessTransaction loadTransaction() {
		List<BusinessTransaction> allBusinessTransactions = businessTransactionDao.getAllBusinessTransaction();
		DDBusinessTransaction ddBusinessTransaction = null;
		if(allBusinessTransactions.size()>0){
			ddBusinessTransaction  = (DDBusinessTransaction) allBusinessTransactions.get(0); 
		}else{
			String sin = "111222333";
			ddBusinessTransaction = new DDBusinessTransaction();
			ddBusinessTransaction.setInstitutionNumber("099");
			ddBusinessTransaction.setTransitNumber("3456");
			ddBusinessTransaction.setAccountNumber("2233445");
			ddBusinessTransaction.setSin(sin);
			Date dt = Calendar.getInstance().getTime();
			ddBusinessTransaction.setDateCreated(dt);
			ddBusinessTransaction.setSystemCreated("JUNIT");
			ddBusinessTransaction.setUserCreated("REFOWNR");
		}
		return ddBusinessTransaction;
	}
	
}
