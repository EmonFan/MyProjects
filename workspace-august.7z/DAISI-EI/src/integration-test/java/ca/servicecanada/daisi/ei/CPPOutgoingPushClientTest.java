package ca.servicecanada.daisi.ei;

import org.junit.Test;

public class CPPOutgoingPushClientTest {

	public final static String QUEUE = "jms/daisi-outgoing-CPP-push-DD-Queue";

	@Test
	public void CPPOutgoingPushClientTest() {
		//String json = "{\"sin\":\"800000002\",\"surname\":\"COFFIN222\",\"birthDate\":\"1943-12-08\",\"channelTypeID\":\"ONL\",\"consentStatementTypeID\":\"STL\"}";	

		String json = "{\"sin\":\"800000002\",\"surname\":\"PeterZhu\",\"birthDate\":\"1933-02-25\",\"channelTypeID\":\"ONL\",\"consentCode\":\"ESS1701\","
		+ "\"accountNumber\":\"50061022222\",\"institution\":\"0003\",\"transitNumber\":\"04080\"}";
		
		
		
		MQClient mqClient = new MQClient(QUEUE);
		mqClient.send(json);
	}

}
