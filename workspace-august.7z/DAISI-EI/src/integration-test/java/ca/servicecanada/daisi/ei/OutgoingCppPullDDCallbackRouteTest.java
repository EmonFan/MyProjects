package ca.servicecanada.daisi.ei;

import java.io.Serializable;
import java.util.Calendar;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;

import org.junit.Test;

import ca.servicecanada.daisi.ei.endpoint.dsb.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.NotificationIDCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINResponseDataAreaType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINResponseDataAreaType.BankAccount;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINResponseType;

public class OutgoingCppPullDDCallbackRouteTest {

	public final static String QUEUE = "jms/daisi-outgoing-CPP-pull-DD-callback-Queue";
	
	private RetrieveBankAccountBySINResponseType ddFromDSB;

	@Test
	public void OutgoingCppPullDDCallbackRouteTest() {
		RetrieveBankAccountBySINResponseType ddFromDSB = new RetrieveBankAccountBySINResponseType();
		
		MessageManifestTransactionalCT messageManifest = new MessageManifestTransactionalCT();
		//Generate a random transaction ID
		NotificationIDCT notification = new  NotificationIDCT();
		String id = "ID:<717546.";
		long now = Calendar.getInstance().getTimeInMillis();
		
		id += now;
		notification.setValue(id);
		messageManifest.setBusinessTransactionID(notification);		
		
		RetrieveBankAccountBySINResponseDataAreaType dataArea = new RetrieveBankAccountBySINResponseDataAreaType();
		
		BankAccount account = new BankAccount();
		dataArea.setBankAccount(account);
		
		dataArea.getBankAccount().setAccountNumber("123");
		dataArea.getBankAccount().setInstitution("678");
		dataArea.getBankAccount().setTransit("789");
		
		ddFromDSB.setMessageManifest(messageManifest);
		ddFromDSB.setDataArea(dataArea);
		
		MQClient mqClient = new MQClient(QUEUE);
		ObjectMessage objMessage = null;
		
		try {
			objMessage = mqClient.getQsession().createObjectMessage();
			objMessage.setObject((Serializable) ddFromDSB);
			mqClient.getQsender().send(objMessage);
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}