package ca.servicecanada.daisi.ei;

import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

import org.junit.Test;

import java.util.Calendar;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;

public class IncomingCppPullDDRouteTest
{

  private static final String SURNAME = "BEACOM";

  private static final String DOB = "1933-02-25";

  private static final String SIN = "800000002";

  private final static String QUEUE = "jms/daisi-incoming-CPP-pull-DD-Queue";

  @SuppressWarnings("static-method")
  @Test
  public void isCraTransactionTypeCorrect()
  {

    // Generate a random transaction ID
    String transactionID = "717546.";
    final long now = Calendar.getInstance().getTimeInMillis();
    transactionID += now;

    final DaisiExchangeRequest request = new DaisiExchangeRequest();

    request.setId(transactionID);
    request.setSin(IncomingCppPullDDRouteTest.SIN);
    request.setBirthDate(IncomingCppPullDDRouteTest.DOB);
    request.setSurname(IncomingCppPullDDRouteTest.SURNAME);
    request.setChannelType("TEL");
    request.setConsentStatementType("SON");

    final MQClient mqClient = new MQClient(IncomingCppPullDDRouteTest.QUEUE);
    ObjectMessage objMessage = null;

    try
    {
      objMessage = mqClient.getQsession().createObjectMessage();
      objMessage.setObject(request);
      mqClient.getQsender().send(objMessage);
    }
    catch (final JMSException e)
    {
      e.printStackTrace();
    }
  }
}