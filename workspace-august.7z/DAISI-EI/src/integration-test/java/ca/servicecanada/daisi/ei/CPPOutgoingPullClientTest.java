package ca.servicecanada.daisi.ei;

import org.junit.Test;

public class CPPOutgoingPullClientTest {

	public final static String QUEUE = "jms/daisi-outgoing-CPP-pull-DD-Queue";

	@Test
	public void CPPOutgoingPushClientTest() {
		//String json = "{\"sin\":\"800000002\",\"surname\":\"BEACO\",\"birthDate\":\"12-12-2017\",\"channelTypeID\":\"ONL\",\"consentCode\":\"ESS1701\",\"consentStatementTypeID\":\"STL\"}";
		String json = "{\"sin\":\"800000002\",\"surname\":\"PeterZhu\",\"birthDate\":\"1933-02-25\",\"channelTypeID\":\"ONL\",\"consentCode\":\"ESS1701\"}";
			
		MQClient mqClient = new MQClient(QUEUE);
		mqClient.send(json);
	}
}
