package ca.servicecanada.daisi.ei;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Random;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class MQClient {

	public final static String JNDI_FACTORY = "weblogic.jndi.WLInitialContextFactory";
	public final static String JMS_FACTORY = "jms/DaisiMessageConnectionFactory"; 
	
	private QueueConnectionFactory qconFactory;
	private QueueConnection qcon;
	private QueueSession qsession;
	
	private QueueSender qsender;
	private Queue queue;
	private TextMessage msg;

	String userName = "weblogic";
	//String password = "Welcome1";
	//String serverUrl = "t3://10.56.47.76:9007";

	String password = "Password1";
	String serverUrl = "t3://localhost:7001";

	private InitialContext getInitialContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, JNDI_FACTORY);
		env.put(Context.PROVIDER_URL, serverUrl);
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);

		InitialContext context = new InitialContext(env);
		return context;
	}

	public QueueSender getQsender() {
		return qsender;
	}

	public void setQsender(QueueSender qsender) {
		this.qsender = qsender;
	}

	public Queue getQueue() {
		return queue;
	}

	public void setQueue(Queue queue) {
		this.queue = queue;
	}

	public TextMessage getMsg() {
		return msg;
	}

	public void setMsg(TextMessage msg) {
		this.msg = msg;
	}

	public MQClient(String queue) {
		InitialContext ic;

		try {
			ic = getInitialContext();
			init(ic, queue);
		} catch (Exception e) {
			System.out.println("**** LOOKS LIKE AN ERROR IN HERE. CHECK QUEUE NAME? SERVER STARTED? ***");
			System.out.println("****  DID YOU REMEMBER TO CHANGE CREDENTIALS IN MQClient ?  ****");
			throw new RuntimeException(e);
		}
	}

	public void send(String message) {

		try {
			msg.setText(message);
			qsender.send(msg);
			msg.getJMSMessageID();
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
	

	public void run() {
		String message = "Message #" + ((new Random()).nextInt(100));
		send(message);
	}

	public void init(Context ctx, String queueName) throws NamingException, JMSException {
		qconFactory = (QueueConnectionFactory) ctx.lookup(JMS_FACTORY);
		qcon = qconFactory.createQueueConnection();
		qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
		queue = (Queue) ctx.lookup(queueName);
		qsender = qsession.createSender(queue);
		msg = qsession.createTextMessage();
		
		qcon.start();
	}

	public void close() throws JMSException {
		qsender.close();
		qsession.close();
		qcon.close();
	}

	private void readAndSend() throws IOException, JMSException {

		BufferedReader msgStream = new BufferedReader(new InputStreamReader(System.in));
		String line = null;
		boolean quitNow = false;
		do {

			System.out.print("Enter message (\"quit\" to quit): \n");
			line = msgStream.readLine();
			if (line != null && line.trim().length() != 0) {
				send(line);
				System.out.println("JMS Message Sent: " + line + "\n");
				quitNow = line.equalsIgnoreCase("quit");
			}
		} while (!quitNow);
	}

	public QueueSession getQsession() {
		return qsession;
	}


}