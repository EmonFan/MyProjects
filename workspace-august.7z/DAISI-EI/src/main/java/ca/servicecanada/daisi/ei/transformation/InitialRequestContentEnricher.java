package ca.servicecanada.daisi.ei.transformation;

import static ca.servicecanada.daisi.ei.DaisiConstants.JMS_MESSAGE_ID;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;
import ca.servicecanada.daisi.ei.model.DaisiMessageID;

import static ca.servicecanada.daisi.ei.util.EiUtils.cleanUpMessageID;

import javax.annotation.Resource;

public class InitialRequestContentEnricher implements Processor {

	private Logger LOGGER = LogManager.getLogger();

	private InitialRequestContentEnricherHelper contentEnricherHelper;

	@Resource
	private DaisiMessageID daisiMessageID;

	@Override
	public void process(Exchange exchange) throws Exception {
		DaisiExchangeRequest request = exchange.getIn().getBody(DaisiExchangeRequest.class);
		LOGGER.trace("InitialRequestEnricher  for SIN " + request.getSin());
		contentEnricherHelper.initRequest(request);

		String ID = request.getId();
		String jmsMessageID = exchange.getIn().getHeader(JMS_MESSAGE_ID, String.class);

		if (jmsMessageID == null) {
			jmsMessageID = exchange.getIn().getMessageId();
		}

		jmsMessageID = cleanUpMessageID(jmsMessageID);
		daisiMessageID.setMessageID(jmsMessageID);

		String businessTransactionID = null;

		if (ID != null) {
			businessTransactionID = ID;
		} else if (jmsMessageID != null) {
			businessTransactionID = jmsMessageID;
		} else {
			LOGGER.warn("Bus Transaction ID can't be inilized - something is wrong");
			throw new RuntimeException("Bus Transaction ID is missing from request!");
		}

		request.setId(businessTransactionID);

		exchange.getIn().setBody(request);
	}

	public void setContentEnricherHelper(InitialRequestContentEnricherHelper contentEnricherHelper) {
		this.contentEnricherHelper = contentEnricherHelper;
	}

}
