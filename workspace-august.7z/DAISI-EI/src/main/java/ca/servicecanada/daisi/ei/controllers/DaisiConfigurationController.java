package ca.servicecanada.daisi.ei.controllers;

import ca.servicecanada.daisi.ei.config.DaisiConfigurationBean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DaisiConfigurationController
{
  @Autowired
  protected DaisiConfigurationBean bean;

  @RequestMapping(value = "/daisiconfigurations", method = RequestMethod.GET)
  public ModelAndView getConfigurations()
  {
    final ModelAndView model = new ModelAndView("configuration2");
    model.addObject("configurationBean", bean);

    return model;

  }
}
