package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.soap.AddressingFeature;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sun.xml.ws.api.addressing.AddressingVersion;
import com.sun.xml.ws.api.addressing.OneWayFeature;
import com.sun.xml.ws.api.addressing.WSEndpointReference;
import com.sun.xml.ws.client.ClientTransportException;

import ca.servicecanada.daisi.ei.endpoint.dsb.generated.ClientProfileAsyncServices;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.ExecutePtt;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINRequestType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINRequestType;

//WS Client to call DSB WS Async, includes ReplyTo SOAP Header
@Component
public class OutboundWsCallsClient extends DsbWsClient {

	private String SERVICE_NAME = "ClientProfileAsyncServices";

	@Value("${daisi.service.protocol}${daisi.service.url}${daisi.service.replyToLocation}")
	private String replyToLocation;

	private ClientProfileAsyncServices service;
	private ExecutePtt port;

	private AddressingFeature addressingfeature;
	private OneWayFeature onewayfeature;
	private WSEndpointReference replyTo;

	@Resource
	private HttpExceptionFactory httpExceptionFactory;

	// DAISI outgoing - CPP push to CRA
	public int setBankAccountBySIN(SetBankAccountBySINRequestType setBankAccountBySIN) {
		LOGGER.debug("sending SOAP");
		int responseCode = 0;

		Map<String, Object> responseContext;
		if (requestsEnabled) {
			try {
				port.setBankAccountBySIN(setBankAccountBySIN);
				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				responseContext = ((BindingProvider) port).getResponseContext();
	
				httpExceptionFactory.throwException(responseContext, e);
	
			}
	
			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			if (responseCode < 200 || responseCode >= 400) {
				//throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		}
		else
			LOGGER.debug("DSB Not called. Disabled in configuration file");

		LOGGER.debug("sent!");
		return responseCode;
	}

	// DAISI outgoing - CPP pull from CRA
	public int retrieveBankAccountBySINFromDSB(RetrieveBankAccountBySINRequestType retrieveBankAccountBySINRequest) {
		int responseCode = 0;
		Map<String, Object> responseContext;
		LOGGER.debug("sending SOAP");
		
		if (requestsEnabled) {
			try {
				port.retrieveBankAccountBySIN(retrieveBankAccountBySINRequest);
				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				responseContext = ((BindingProvider) port).getResponseContext();
				httpExceptionFactory.throwException(responseContext, e);
			}
	
			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			if (responseCode < 200 || responseCode >= 400) {
				//throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		}
		else
			LOGGER.debug("DSB Not called. Disabled in configuration file");
		
		LOGGER.debug("sent!");
		return responseCode;
	}

	@Override
	void initPort() {
		try {
			qName = new QName(NS, SERVICE_NAME);
			service = new ClientProfileAsyncServices(SOASERVICE_WSDL_LOCATION, qName);
		} catch (javax.xml.ws.WebServiceException e) {
			throw new RuntimeException(e);
		}
		service.setHandlerResolver(handlerResolver);

		addressingfeature = new AddressingFeature();
		replyTo = new WSEndpointReference(replyToLocation, AddressingVersion.W3C);
		onewayfeature = new OneWayFeature(true, replyTo);
		port = service.getExecuteAsyncPt(addressingfeature, onewayfeature);

		setDsbEndpontAddress();
	}

	// set the live URL of the service, which will be used during service
	void setDsbEndpontAddress() {
		BindingProvider bp = ((BindingProvider) port);
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);

		LOGGER.debug("DSB endpoint set to " + endpoint);
	}

	
	@Override
	URL initWsdl(URL baseUrl) throws MalformedURLException {
		URL url = new URL(baseUrl, wsdl);
		return url;
		
	}


}
