package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.BIRTH_DATE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CHANNEL;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINRequestDataAreaType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINRequestType;

@Component(value = "retrieveBankAccountBySINRequestTranslator")
public class RetrieveBankAccountBySINRequestTranslator extends AbstractDaisiDomainToDsbModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	@Override
	public DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("to DSB for ID = " + trx.getBusinessTransactionID());

		RetrieveBankAccountBySINRequestType request = new RetrieveBankAccountBySINRequestType();

		MessageManifestTransactionalCT mf = buildManifest(trx);
		mf = setTestIndicatr(mf);

		RetrieveBankAccountBySINRequestDataAreaType dataArea = buildDataArea(trx);

		request.setDataArea(dataArea);
		request.setMessageManifest(mf);

		DsbModelPlaceholder placeholder = new DsbModelPlaceholder();
		placeholder.setDsb(request);

		return placeholder;

	}

	public RetrieveBankAccountBySINRequestDataAreaType buildDataArea(BusinessTransaction trx) {
		RetrieveBankAccountBySINRequestDataAreaType d = new RetrieveBankAccountBySINRequestDataAreaType();
		String birthDate = trx.getBirthDate();
		String channel = trx.getChannelType().getChannelTypeAbrvEn();

		// the Program identifies the destination, not the source.
		String program = trx.getProgramServiceTypeTarget().getServiceTypeAbrvEn();
		String sin = trx.getSin();
		String surname = trx.getSurname();
		String sharingAgreementID = trx.getConsentCode();

		// fix jira PEN-205
		//birthDate = adapt(BIRTH_DATE, birthDate);
		channel = adapt(CHANNEL, channel);

		d.setBirthDate(birthDate);
		d.setChannel(channel);
		d.setProgram(program);
		d.setSocialInsuranceNumber(sin);
		d.setSurname(surname);
		d.setSharingAgreementID(sharingAgreementID);

		return d;
	}

}
