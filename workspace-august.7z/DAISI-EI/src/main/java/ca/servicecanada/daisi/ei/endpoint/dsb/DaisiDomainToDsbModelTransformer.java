package ca.servicecanada.daisi.ei.endpoint.dsb;

import static ca.servicecanada.daisi.ei.DaisiConstants.FAULT;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.support.DaisiDomainToDsbModelTranslator;
import ca.servicecanada.daisi.ei.endpoint.dsb.support.DaisiDomainToDsbModelTranslatorFactory;

@Component(value = "daisiDomainToDsbModelTransformer")
public class DaisiDomainToDsbModelTransformer implements Processor {
	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDomainToDsbModelTranslatorFactory translatorFactory;

	@Override
	public void process(Exchange exchange) throws Exception {

		BusinessTransaction trx = (BusinessTransaction) exchange.getIn().getBody();

		Map<String, String> context = buildContextMap(exchange);

		DsbModelPlaceholder dsbModelPlaceholder = null;
		try {
			dsbModelPlaceholder = transform(trx, context);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		// dsbModelPlaceholder.setFaultDetails(faultDetails);
		// dsbModelPlaceholder.setRejectReasonCode(rejectReasonCode);
		// dsbModelPlaceholder.setResultCode(resultCode);
		// dsbModelPlaceholder.setStatusType(statusType);

		exchange.getIn().setBody(dsbModelPlaceholder);
	}

	public DsbModelPlaceholder transform(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("transforming... ");

		DaisiDomainToDsbModelTranslator translator = translatorFactory.getDaisiDomainToDsbModelTranslator(trx);

		DsbModelPlaceholder placeholder = translator.translate(trx, context);
		return placeholder;
	}

	Map<String, String> buildContextMap(Exchange exchange) {
		Map<String, String> context = new HashMap<String, String>();
		String statusType = null;
		String faultDetails = null;
		String rejectReasonCode = null;
		String resultCode = null;
		try {
			statusType = (String) exchange.getIn().getHeader(STATUS_TYPE);
			faultDetails = (String) exchange.getIn().getHeader(FAULT);
			rejectReasonCode = (String) exchange.getIn().getHeader(REJECT_REASON_CODE);
			resultCode = (String) exchange.getIn().getHeader(RESULT_CODE);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		context.put(STATUS_TYPE, statusType);
		context.put(FAULT, faultDetails);
		context.put(REJECT_REASON_CODE, rejectReasonCode);
		context.put(RESULT_CODE, resultCode);

		Collection<String> values = context.values();
		while (values.remove(null)) {
		}

		return context;
	}

}
