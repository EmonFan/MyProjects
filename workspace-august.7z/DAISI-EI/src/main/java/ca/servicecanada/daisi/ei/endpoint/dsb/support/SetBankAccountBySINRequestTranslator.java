package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.ACCOUNT_NUMBER;
import static ca.servicecanada.daisi.ei.DaisiConstants.BIRTH_DATE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CHANNEL;
import static ca.servicecanada.daisi.ei.DaisiConstants.INSTITUTION;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINRequestDataAreaType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINRequestDataAreaType.BankAccount;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINRequestType;

@Component(value = "setBankAccountBySINRequestTranslator")
public class SetBankAccountBySINRequestTranslator extends AbstractDaisiDomainToDsbModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	@Override
	public DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("to DSB for ID = " + trx.getBusinessTransactionID());

		SetBankAccountBySINRequestType request = new SetBankAccountBySINRequestType();

		SetBankAccountBySINRequestDataAreaType dataArea = buildSetBankAccountBySINRequestDataAreaType(trx);
		MessageManifestTransactionalCT mf = buildManifest(trx);
		mf = setTestIndicatr(mf);

		request.setDataArea(dataArea);
		request.setMessageManifest(mf);

		DsbModelPlaceholder placeholder = new DsbModelPlaceholder();
		placeholder.setDsb(request);
		return placeholder;
	}

	SetBankAccountBySINRequestDataAreaType buildSetBankAccountBySINRequestDataAreaType(BusinessTransaction trx) {
		SetBankAccountBySINRequestDataAreaType d = new SetBankAccountBySINRequestDataAreaType();

		String birthDate = trx.getBirthDate();
		//ITRDS now sends correct date format
		//birthDate = adapt(BIRTH_DATE, birthDate);

		String channel = trx.getChannelType().getChannelTypeAbrvEn();
		String program = trx.getProgramServiceTypeTarget().getServiceTypeAbrvEn();
		String sin = trx.getSin();
		String surname = trx.getSurname();
		String consentCode = trx.getConsentCode();

		String accountNumber = ((DDBusinessTransaction) trx).getAccountNumber();
		String institutionNumber = ((DDBusinessTransaction) trx).getInstitutionNumber();
		String transitNumber = ((DDBusinessTransaction) trx).getTransitNumber();

		channel = adapt(CHANNEL, channel);

		d.setBirthDate(birthDate);
		d.setChannel(channel);
		d.setProgram(program);
		d.setSocialInsuranceNumber(sin);
		d.setSurname(surname);
		d.setSharingAgreementID(consentCode);

		BankAccount bankAccount = new BankAccount();

		accountNumber = adapt(ACCOUNT_NUMBER, accountNumber);
		bankAccount.setAccountNumber(accountNumber);

		institutionNumber = adapt(INSTITUTION, institutionNumber);
		bankAccount.setInstitution(institutionNumber);
		bankAccount.setTransit(transitNumber);
		d.setBankAccount(bankAccount);

		return d;
	}

	// Map<String, String> elementsToAdapt = new HashMap() {
	// {
	// elementsToAdapt.put(CHANNEL, null);
	// elementsToAdapt.put(ACCOUNT_NUMBER, null);
	// elementsToAdapt.put(INSTITUTION, null);
	//
	// }
	// };

}
