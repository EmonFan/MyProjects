package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.util.DaisiDateTimeUtils;

@Component(value = "birthDateAdapter")
public class BirthDateAdapter implements DsbElementAdapter {

	/**
	 * ITRDS sends DoB � YYYYMM
	 */
	@Override
	public String adaptToDsb(String originalValue) {
		String adaptedValue = DaisiDateTimeUtils.itrdsBirthDateToDsbFormat(originalValue);
		return adaptedValue;
	}

	@Override
	public String adaptFromDsb(String originalValue) {
		return originalValue;
	}

}