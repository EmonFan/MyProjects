package ca.servicecanada.daisi.ei.transformation;

import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;

@Component(value = "itrdsClientDataUpdateProcessor")
public class ClientDataUpdateProcessor extends AbstractDataEnricher {

	protected void execute(BusinessTransaction trx) {
		dataAccessService.updateDirectDeposit(trx);
	}

}
