package ca.servicecanada.daisi.ei.transformation;

import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

public interface DaisiDataServiceClient {

	OrganizationType getOrganizationTypeTarget(DaisiExchangeRequest request);

	OrganizationType getOrganizationTypeSource(DaisiExchangeRequest request);

	ProgramServiceType getProgramServiceTypeTarget(DaisiExchangeRequest request);

	ProgramServiceType getProgramServiceTypeSource(DaisiExchangeRequest request);

	TransactionType getTransactionType(DaisiExchangeRequest request);

	ConsentStatementType getConsentStatementType(DaisiExchangeRequest request);

	ChannelType getChannelType(DaisiExchangeRequest request);

	BusinessTransaction createBusinessTransaction(BusinessTransaction trx);

	BusinessTransaction updateBusinessTransaction(BusinessTransaction trx);

	BusinessTransaction findBusinessTransactionByTransactionID(String businessTransactionID);

	BusinessTransaction findBusinessTransactionByID(int ID);

	void createEventLog(EventLog event);

	EventLogType findEventLogTypeByCode(String eventLogTypeCode);

	EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv);
	
	StatusType findStatusTypeByAbrv(String statusTypeAbrv);

	RejectReasonType findRejectReasonTypeByAbrv(String rejectReasonTypeAbrv);

	RejectReasonType findRejectReasonTypeByID(int rejectReasonTypeID);
	
	RejectReasonType findRejectReasonTypeByextErnalCode(String rejectReasonCode);

}
