package ca.servicecanada.daisi.ei.endpoint.dsb;

import static ca.servicecanada.daisi.ei.DaisiConstants.EVENT_LOG_TYPE;
import static ca.servicecanada.daisi.ei.DaisiConstants.SOAP_HEADER_RELATES_TO;
import static ca.servicecanada.daisi.ei.DaisiConstants.SOAP_HEADER_REPLY_TO;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component(value = "dsbOutboundProcessor")
public class DSBOutboundProcessor implements Processor {

	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DSBOutboundProcessorHelper dsbOutboundProcessorHelper;

	@Override
	public void process(Exchange exchange) throws Exception {

		DsbModelPlaceholder dsbModelPlaceholder = (DsbModelPlaceholder) exchange.getIn().getBody();// DsbModelPlasholder
		String statusType = (String) exchange.getIn().getHeader(STATUS_TYPE);

		String replyTo = (String) exchange.getIn().getHeader(SOAP_HEADER_REPLY_TO);
		dsbModelPlaceholder.setReplyTo(replyTo);
		
		String relatesTo = (String) exchange.getIn().getHeader(SOAP_HEADER_RELATES_TO);
		dsbModelPlaceholder.setRelatesTo(relatesTo);


		dsbModelPlaceholder.setStatusType(statusType);

		LOGGER.debug("DSB endpoint to be used for calback " + replyTo);

		String eventLogType = dsbOutboundProcessorHelper.process(dsbModelPlaceholder);

		exchange.getIn().setHeader(EVENT_LOG_TYPE, eventLogType);

	}

}
