package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundCallbackWsClient;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINAsyncResponseType;

//@Component(value = "retrieveBankAccountBySINAsyncResponseCommand")
public class RetrieveBankAccountBySINAsyncResponseCommand implements DsbEndpointCommand {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private OutboundCallbackWsClient callbackWsClient;

	@Override
	public int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder) {
		RetrieveBankAccountBySINAsyncResponseType dsbData = (RetrieveBankAccountBySINAsyncResponseType) dsbModelPlaceholder
				.getDsb();
		int httpResponseCode = callbackWsClient.callbackRetrieveBankAccountBySINAsyncResponse(dsbData,
				dsbModelPlaceholder.getReplyTo());
		LOGGER.debug("Sent to DSB!");
		return httpResponseCode;
	}

}
