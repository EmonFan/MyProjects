package ca.servicecanada.daisi.ei.channel.ws;

import java.io.ByteArrayOutputStream;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SOAPLoggingHandler implements SOAPHandler<SOAPMessageContext> {

	public static final String DIRECTION_OUT = "OUTGOING SOAP TO ";
	public static final String DIRECTION_IN = "INCOMING SOAP FROM ";
	public static final String DECORATION_LINE = " ******** ";


	private Logger LOGGER = LogManager.getLogger("XML");

	public boolean handleMessage(SOAPMessageContext context) {
		logSOAP(context);
		return true;
	}

	private void logSOAP(SOAPMessageContext context) {
		boolean isOutbound = ((Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue();
		String direction = (isOutbound) ? DIRECTION_OUT : DIRECTION_IN;
		
		String source = "Not available";
        // retrieve the client information
        HttpServletRequest httpServletRequest = 
            (HttpServletRequest)context.get(MessageContext.SERVLET_REQUEST);
//        String addr = httpServletRequest.getRemoteAddr();
        if (httpServletRequest != null)
        	source = (httpServletRequest.getRemoteHost());

		StringBuffer sbuf = new StringBuffer();
		sbuf.append("\n");
		sbuf.append(DECORATION_LINE);
		sbuf.append(direction);
		sbuf.append(source);
		sbuf.append(" START (ei) ->");
		sbuf.append("\n");
		sbuf.append(buildXML(context));
		sbuf.append("\n");
		sbuf.append(direction);
		sbuf.append(source);
		sbuf.append(" <- (ei) END");
		sbuf.append(DECORATION_LINE);
		sbuf.append("\n");

		LOGGER.info(sbuf.toString());
	}
	
	private StringBuffer buildXML(SOAPMessageContext context) {
		SOAPMessage message = null;
		try {
			message = context.getMessage();
		} catch (Exception e1) {
			LOGGER.error(e1.getMessage());
		}
		StringBuffer sbuf = new StringBuffer();
		try {
			sbuf.append("\n");
			// sbuf.append(message.toString());
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			message.writeTo(baos);
			sbuf.append("\n");
			sbuf.append(baos.toString());
			sbuf.append("\n");

		} catch (Exception e) {
			sbuf.append("Exception in SOAP Handler: " + e);
		}

		return sbuf;
	}

	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
