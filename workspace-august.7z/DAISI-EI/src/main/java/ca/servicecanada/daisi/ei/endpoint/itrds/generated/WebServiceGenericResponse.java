
package ca.servicecanada.daisi.ei.endpoint.itrds.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for webServiceGenericResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="webServiceGenericResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://isp.sdc.gc.ca/ws/cs/jaxws/impl}potentialForErrors">
 *       &lt;sequence>
 *         &lt;element name="confirmationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SuccessStatus" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="transcationTimeStamp" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "webServiceGenericResponse", propOrder = {
    "confirmationNumber",
    "successStatus",
    "transcationTimeStamp"
})
@XmlSeeAlso({
    DaisiPushDDServiceResponse.class
})
public class WebServiceGenericResponse
    extends PotentialForErrors
{

    protected String confirmationNumber;
    @XmlElement(name = "SuccessStatus")
    protected boolean successStatus;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar transcationTimeStamp;

    /**
     * Gets the value of the confirmationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConfirmationNumber() {
        return confirmationNumber;
    }

    /**
     * Sets the value of the confirmationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConfirmationNumber(String value) {
        this.confirmationNumber = value;
    }

    /**
     * Gets the value of the successStatus property.
     * 
     */
    public boolean isSuccessStatus() {
        return successStatus;
    }

    /**
     * Sets the value of the successStatus property.
     * 
     */
    public void setSuccessStatus(boolean value) {
        this.successStatus = value;
    }

    /**
     * Gets the value of the transcationTimeStamp property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTranscationTimeStamp() {
        return transcationTimeStamp;
    }

    /**
     * Sets the value of the transcationTimeStamp property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTranscationTimeStamp(XMLGregorianCalendar value) {
        this.transcationTimeStamp = value;
    }

}
