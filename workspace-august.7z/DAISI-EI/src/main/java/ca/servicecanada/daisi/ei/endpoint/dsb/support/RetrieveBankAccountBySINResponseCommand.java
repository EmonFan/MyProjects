package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundWsCallsClient;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINRequestType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundCallbackWsClient2;


@Component(value = "retrieveBankAccountBySINResponseCommand")
public class RetrieveBankAccountBySINResponseCommand implements DsbEndpointCommand {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private OutboundCallbackWsClient2 outboundWsCallsClient;

	@Override
	public int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder) {
		RetrieveBankAccountBySINResponseType data = (RetrieveBankAccountBySINResponseType) dsbModelPlaceholder
				.getDsb();
		int httpResponseCode = outboundWsCallsClient.callbackRetrieveBankAccountBySINAsyncResponse(data, dsbModelPlaceholder.getReplyTo(), dsbModelPlaceholder.getRelatesTo());
		LOGGER.debug("Sent to DSB! httpResponseCode =" + httpResponseCode);
		return httpResponseCode;

		
	}

}
