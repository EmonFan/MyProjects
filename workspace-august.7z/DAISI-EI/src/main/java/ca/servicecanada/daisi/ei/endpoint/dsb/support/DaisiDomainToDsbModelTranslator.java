package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import java.util.Map;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;

public interface DaisiDomainToDsbModelTranslator {

	DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context);

}
