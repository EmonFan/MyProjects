@javax.xml.bind.annotation.XmlSchema(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ca.servicecanada.daisi.ei.endpoint.dsb.generated;
