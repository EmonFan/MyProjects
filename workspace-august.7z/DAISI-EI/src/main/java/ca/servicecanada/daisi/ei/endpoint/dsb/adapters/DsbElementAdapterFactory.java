package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

@Component
public class DsbElementAdapterFactory {

	@Resource(name = "dsbElementAdaptersMap")
	protected Map<String, DsbElementAdapter> dsbElementAdaptersMap;

	public DsbElementAdapter getDsbElementAdapter(String dsbElementName) {
		if (dsbElementAdaptersMap.containsKey(dsbElementName)) {
			return dsbElementAdaptersMap.get(dsbElementName);
		} else {
			return null;
		}
	}

	// protected Map<String, DsbElementAdapter> initDsbElementAdapters() {
	// dsbElementAdaptersMap = new HashMap<String, DsbElementAdapter>();
	//
	// dsbElementAdaptersMap.put(CHANNEL, new ChannelAdapter());
	// dsbElementAdaptersMap.put(SYSTEM_ID, new SystemIDAdapter());
	// dsbElementAdaptersMap.put(ACCOUNT_NUMBER, new
	// BankAccountNumberAdapter());
	// dsbElementAdaptersMap.put(INSTITUTION, new
	// BankAccountInstitutionAdapter());
	//
	// dsbElementAdaptersMap.put(BIRTH_DATE, new BirthDateAdapter());
	//
	// return dsbElementAdaptersMap;
	// }

}
