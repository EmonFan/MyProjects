package ca.servicecanada.daisi.ei.exception;

public class DataSharingRejectException extends RuntimeException {

	private String rejectReasonCode;

	public void setRejectReasonCode(String rejectReasonCode) {
		this.rejectReasonCode = rejectReasonCode;
	}

	public DataSharingRejectException(String rejectReasonCode) {
		super(rejectReasonCode);
		this.rejectReasonCode = rejectReasonCode;
	}

	public String getRejectReasonCode() {
		return rejectReasonCode;
	}

}
