package ca.servicecanada.daisi.ei.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

@Component
@PropertySources({ @PropertySource("classpath:version.properties"),
    @PropertySource(value = "classpath:daisiOverride.properties", ignoreResourceNotFound = true) })
public class DaisiConfigurationBean implements InitializingBean
{

  // DAISI build version
  @Value("${build.name}")
  protected String buildVersion;

  // Accessing ITRDS WS ->ITRDS
  @Value("${itrds.ws.user}")
  protected String itrdsWSUser;

  @Value("${itrds.ws.password}")
  protected String itrdsWSUserPassword;

  @Value("${itrds.ws.pull-dd.url}")
  protected String endpointItrdsWSPullDD;

  @Value("${itrds.ws.push-dd.url}")
  protected String endpointItrdsWSPushDD;

  @Value("${itrds.requests.enabled}")
  protected boolean itrdsWSCallRequestsEnabled;

  // DSB Access
  @Value("${dsb.user}")
  protected String dsbUser;

  @Value("${dsb.password}")
  protected String dsbUserPassword;

  @Value("${dsb.url}")
  protected String dsbClientProfileURL;

  @Value("${dsb.wsdl}")
  protected String dsbClientProfileWsdl;

  @Value("${dsb.url.callback}")
  protected String dsbCallBackURL;

  @Value("${dsb.wsdl.callback}")
  protected String dsbCallBackWsdl;

  @Value("${dsb.testIndicator}")
  protected boolean dsbCallTestIndicator;

  @Value("${dsb.requests.enabled}")
  protected boolean dsbCallRequestsEnabled;

  // validate DSB user
  @Value("${ws.username}")
  protected String daisiUser;

  @Value("${ws.password}")
  protected String daisiUserPassword;
  
  @Value("${message.queue.timeout}")
  protected String queueTimeout;

  // private static DaisiConfigurationBean instance = new
  // DaisiConfigurationBean();

  public String getQueueTimeout() {
	return queueTimeout;
}

public DaisiConfigurationBean()
  {

  }

  /*
   * public static DaisiConfigurationBean DaisiConfigurationBean() { return
   * DaisiConfigurationBean.instance; }
   */

  public String getBuildVersion()
  {
    return buildVersion;
  }

  public String getItrdsWSUser()
  {
    return itrdsWSUser;
  }

  public String getItrdsWSUserPassword()
  {
    return itrdsWSUserPassword;
  }

  public String getEndpointItrdsWSPullDD()
  {
    return endpointItrdsWSPullDD;
  }

  public String getEndpointItrdsWSPushDD()
  {
    return endpointItrdsWSPushDD;
  }

  public boolean isItrdsWSCallRequestsEnabled()
  {
    return itrdsWSCallRequestsEnabled;
  }

  public String getDsbUser()
  {
    return dsbUser;
  }

  public String getDsbUserPassword()
  {
    return dsbUserPassword;
  }

  public String getDsbClientProfileURL()
  {
    return dsbClientProfileURL;
  }

  public String getDsbClientProfileWsdl()
  {
    return dsbClientProfileWsdl;
  }

  public String getDsbCallBackURL()
  {
    return dsbCallBackURL;
  }

  public String getDsbCallBackWsdl()
  {
    return dsbCallBackWsdl;
  }

  public boolean isDsbCallTestIndicator()
  {
    return dsbCallTestIndicator;
  }

  public boolean isDsbCallRequestsEnabled()
  {
    return dsbCallRequestsEnabled;
  }

  public String getDaisiUser()
  {
    return daisiUser;
  }

  public String getDaisiUserPassword()
  {
    return daisiUserPassword;
  }

  @Override
  public void afterPropertiesSet() throws Exception
  {
    // TODO Auto-generated method stub

  }

}
