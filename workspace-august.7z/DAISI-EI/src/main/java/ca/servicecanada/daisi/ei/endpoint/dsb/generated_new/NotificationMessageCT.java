
package ca.servicecanada.daisi.ei.endpoint.dsb.generated_new;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for NotificationMessageCT complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="NotificationMessageCT">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="NotificationMessageManifest" type="{http://interoperability.gc.ca/core/1.0}MessageManifest-NonTransactional-CT"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NotificationMessageCT", namespace = "http://interoperability.gc.ca/core/1.0", propOrder = {
    "notificationMessageManifest"
})
public class NotificationMessageCT implements Serializable {

    @XmlElement(name = "NotificationMessageManifest", required = true)
    protected MessageManifestNonTransactionalCT notificationMessageManifest;

    /**
     * Gets the value of the notificationMessageManifest property.
     * 
     * @return
     *     possible object is
     *     {@link MessageManifestNonTransactionalCT }
     *     
     */
    public MessageManifestNonTransactionalCT getNotificationMessageManifest() {
        return notificationMessageManifest;
    }

    /**
     * Sets the value of the notificationMessageManifest property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageManifestNonTransactionalCT }
     *     
     */
    public void setNotificationMessageManifest(MessageManifestNonTransactionalCT value) {
        this.notificationMessageManifest = value;
    }

}
