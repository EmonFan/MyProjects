package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import static ca.servicecanada.daisi.ei.DaisiConstants.ORGANIZATION_TYPE_CRA;
import static ca.servicecanada.daisi.ei.DaisiConstants.ORGANIZATION_TYPE_ESDC;

import org.springframework.stereotype.Component;

/** SystemID - sender Organization */
@Component(value = "systemIDAdapter")
public class SystemIDAdapter extends AbstractDsbElementAdapter {

	public SystemIDAdapter() {
		toDsbMapping.put(ORGANIZATION_TYPE_CRA, "CRA");
		toDsbMapping.put(ORGANIZATION_TYPE_ESDC, "ESDC");

		fromDsbMapping.put("CRA", ORGANIZATION_TYPE_CRA);
		fromDsbMapping.put("ESDC", ORGANIZATION_TYPE_ESDC);

		dsbElementName = "SystemID";

	}

}
