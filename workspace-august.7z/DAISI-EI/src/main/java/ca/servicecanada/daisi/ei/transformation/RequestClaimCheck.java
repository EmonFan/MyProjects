package ca.servicecanada.daisi.ei.transformation;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import org.springframework.context.annotation.Import;
import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import static ca.servicecanada.daisi.ei.DaisiConstants.BUSINESS_TRANSACTION_ID;

@Component(value = "requestClaimCheck")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class RequestClaimCheck {

	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDataServiceClient daisiDataService;

	public void onNewRequest(Exchange exchange) {

		BusinessTransaction trx = (BusinessTransaction) exchange.getIn().getBody();

		LOGGER.debug("processing RequestClaimCheck...request for  SIN  " + trx.getSin());

		trx = daisiDataService.updateBusinessTransaction(trx);

		exchange.getIn().setBody(trx);
		exchange.getIn().setHeader("ID", trx.getId());
		exchange.getIn().setHeader(BUSINESS_TRANSACTION_ID, trx.getBusinessTransactionID());
	}
}
