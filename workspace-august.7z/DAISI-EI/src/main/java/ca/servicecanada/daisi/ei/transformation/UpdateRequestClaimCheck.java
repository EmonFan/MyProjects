package ca.servicecanada.daisi.ei.transformation;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.context.annotation.Import;


import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;

//update an existing row in BUSINESS_TRX table
@Component(value = "updateRequestClaimCheck")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class UpdateRequestClaimCheck {
	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDataServiceClient daisiDataService;

	public void updateRequest(Exchange exchange) {

		// get BusTrx
		DDBusinessTransaction trx = (DDBusinessTransaction) exchange.getIn().getBody();

		LOGGER.debug("updating RequestClaimCheck...request for  SIN  " + trx.getSin());

		// udate BusTrx
		daisiDataService.updateBusinessTransaction(trx);
		LOGGER.debug("updated RequestClaimCheck...request for  SIN  " + trx.getSin());

	}
}
