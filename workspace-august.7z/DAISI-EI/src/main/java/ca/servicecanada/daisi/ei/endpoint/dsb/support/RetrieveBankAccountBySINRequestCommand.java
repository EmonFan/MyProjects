package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundWsCallsClient;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINRequestType;

@Component(value = "retrieveBankAccountBySINRequestCommand")
public class RetrieveBankAccountBySINRequestCommand implements DsbEndpointCommand {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private OutboundWsCallsClient outboundWsCallsClient;

	@Override
	public int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder) {
		RetrieveBankAccountBySINRequestType retrieveBankAccountBySINRequest = (RetrieveBankAccountBySINRequestType) dsbModelPlaceholder
				.getDsb();
		int httpResponseCode = outboundWsCallsClient.retrieveBankAccountBySINFromDSB(retrieveBankAccountBySINRequest);
		LOGGER.debug("Sent to DSB! httpResponseCode =" + httpResponseCode);
		return httpResponseCode;

	}

}
