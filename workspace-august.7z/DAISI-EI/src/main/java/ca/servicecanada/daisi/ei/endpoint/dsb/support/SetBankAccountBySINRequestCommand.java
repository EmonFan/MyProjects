package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundWsCallsClient;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINRequestType;

@Component(value = "setBankAccountBySINRequestCommand")
public class SetBankAccountBySINRequestCommand implements DsbEndpointCommand {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private OutboundWsCallsClient outboundWsCallsClient;

	@Override
	public int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder) {
		SetBankAccountBySINRequestType dsbData = (SetBankAccountBySINRequestType) dsbModelPlaceholder.getDsb();
		int httpResponseCode = outboundWsCallsClient.setBankAccountBySIN(dsbData);
		LOGGER.debug("Sent to DSB! httpResponseCode =" + httpResponseCode);
		return httpResponseCode;
	}

}
