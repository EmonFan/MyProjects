package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.MessageContext;

import org.springframework.stereotype.Component;

import com.sun.xml.ws.client.ClientTransportException;

import ca.servicecanada.daisi.ei.endpoint.dsb.generated.ClientProfileAsyncCallbackServices;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.ExecuteCallbackPtt;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.RetrieveBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINAsyncResponseType;

//@Component
public class OutboundCallbackWsClient extends DsbWsClient {

	private String SERVICE_NAME = "ClientProfileAsyncCallbackServices";
	// private String SERVICE_NAME = "execute_callback_ptt";
	private ClientProfileAsyncCallbackServices callbackService;
	private ExecuteCallbackPtt port;

	@Resource
	private HttpExceptionFactory httpExceptionFactory;

	// DAISI outgoing - CPP pull from CRA
	public int callbackRetrieveBankAccountBySINAsyncResponse(RetrieveBankAccountBySINAsyncResponseType data,
			String replyTo) {
		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		int responseCode = 0;
		
		if (requestsEnabled) {
			try {
				setEndpointAddressingFromReplyTo(replyTo);
	 
				port.retrieveBankAccountBySINResponse(data);
				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				LOGGER.error(e.getMessage());
				responseContext = ((BindingProvider) port).getResponseContext();
				httpExceptionFactory.throwException(responseContext, e);
			}
	
			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			
			if (responseCode < 200 || responseCode >= 400) {
				//throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		}
		else
			LOGGER.debug("DSB Not called. Disabled in configuration file");
		
		LOGGER.debug("sent!");
		return responseCode;

	}

	// DAISI outgoing - CPP pull from CRA
	public int callbackSetBankAccountBySINAsyncResponse(SetBankAccountBySINAsyncResponseType data, String replyTo) {
		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		int responseCode = 0;
		
		if (requestsEnabled) {
			try {
				setEndpointAddressingFromReplyTo(replyTo);
	
				port.setBankAccountBySINResponse(data);
				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				LOGGER.error(e.getMessage());
				responseContext = ((BindingProvider) port).getResponseContext();
				httpExceptionFactory.throwException(responseContext, e);
	
			}
	
			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			if (responseCode < 200 || responseCode >= 400) {
				//throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		}
		else
			LOGGER.debug("DSB Not called. Disabled in configuration file");

		LOGGER.debug("sent!");
		return responseCode;
	}

	@Override
	void initPort() {
		try {
			qName = new QName(NS, SERVICE_NAME);
			callbackService = new ClientProfileAsyncCallbackServices(SOASERVICE_WSDL_LOCATION, qName);
		} catch (javax.xml.ws.WebServiceException e) {
			throw new RuntimeException(e);
		}
		callbackService.setHandlerResolver(handlerResolver);

		port = callbackService.getExecuteCallbackPtt();
		setDsbEndpontAddress();

	}

	void setDsbEndpontAddress() {
		BindingProvider bp = ((BindingProvider) port);
		Map<String, Object> context = bp.getRequestContext();
		try {
			context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		LOGGER.debug("DSB endpoint set to " + endpoint);
	}

	void setEndpointAddressingFromReplyTo(String replyTo) {
		BindingProvider bp = ((BindingProvider) port);
		Map<String, Object> context = bp.getRequestContext();
		try {
			context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, replyTo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

	}

	
	@Override
	URL initWsdl(URL baseUrl) throws MalformedURLException {
		URL url = new URL(baseUrl, wsdl);
		return url;
		
	}


}
