package ca.servicecanada.daisi.ei.transformation;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import org.springframework.context.annotation.Import;
import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;
import ca.gc.servicecanada.daisi.service.DaisiEventLogService;
import ca.gc.servicecanada.daisi.service.DaisiReferenceDataService;
import ca.gc.servicecanada.daisi.service.DaisiTransactionDataService;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

//DaisiExchangeRequest has ref. code values from the endpoints' translators/initial  (JSON to Canonical)
@Component
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class DaisiDataServiceClientApiImpl implements DaisiDataServiceClient {

	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiReferenceDataService refSvs;

	@Resource
	private DaisiTransactionDataService trxSvs;

	@Resource
	private DaisiEventLogService eventSvs;

	@Override
	public RejectReasonType findRejectReasonTypeByAbrv(String rejectReasonTypeAbrv) {
		RejectReasonType rejectReasonType = refSvs.findRejectReasonTypeByAbrv(rejectReasonTypeAbrv);
		return rejectReasonType;
	}
	
	@Override
	public RejectReasonType findRejectReasonTypeByextErnalCode(String rejectReasonCode) {
		RejectReasonType rejectReasonType = refSvs.findRejectReasonTypeByextErnalCode(rejectReasonCode);
		return rejectReasonType;
	}

	@Override
	public RejectReasonType findRejectReasonTypeByID(int rejectReasonTypeID) {
		RejectReasonType rejectReasonType = refSvs.findRejectReasonTypeByID(rejectReasonTypeID);
		return rejectReasonType;
	}

	@Override
	public StatusType findStatusTypeByAbrv(String statusTypeAbrv) {
		StatusType statusType = refSvs.findStatusTypeByAbrv(statusTypeAbrv);
		return statusType;
	}

	@Override
	public EventLogType findEventLogTypeByCode(String eventLogTypeCode) {
		EventLogType eventLogType = eventSvs.findEventLogTypeByCode(eventLogTypeCode);
		return eventLogType;
	}

	@Override
	public EventLogType findEventLogTypeByAbrv(String eventLogTypeAbrv) {
		EventLogType eventLogType = eventSvs.findEventLogTypeByAbrv(eventLogTypeAbrv);
		return eventLogType;
	}

	public void createEventLog(EventLog event) {
		eventSvs.createEventLog(event);
	}

	public BusinessTransaction findBusinessTransactionByTransactionID(String businessTransactionID) {
		return trxSvs.findBusinessTransactionByTrxId(businessTransactionID);
	}

	@Override
	public BusinessTransaction findBusinessTransactionByID(int ID) {
		return trxSvs.findBusinessTransactionById(ID);
	}

	public BusinessTransaction createBusinessTransaction(BusinessTransaction trx) {
		return trxSvs.create(trx);
	}

	// ------ ref data lookups ---------

	public ChannelType getChannelType(DaisiExchangeRequest request) {
		String channelTypeAbrv = request.getChannelType();
		LOGGER.debug("lookup ChannelType by channelTypeAbrv : " + channelTypeAbrv);
		ChannelType channelType = refSvs.findChannelTypeByAbrv(channelTypeAbrv);
		return channelType;
	}

	public ConsentStatementType getConsentStatementType(DaisiExchangeRequest request) {
		String consentStatementTypeAbrv = request.getConsentStatementType();
		LOGGER.debug("lookup ChannelType by consentStatementTypeAbrv : " + consentStatementTypeAbrv);
		ConsentStatementType consentStatementType = refSvs.findConsentStatementTypeByAbrv(consentStatementTypeAbrv);
		return consentStatementType;
	}

	public TransactionType getTransactionType(DaisiExchangeRequest request) {
		String actionTypeCode = request.getActionType();
		String informationTypeCode = request.getInfoType();

		LOGGER.debug("lookup by actionTypeCode=" + actionTypeCode + ", informationTypeCode= " + informationTypeCode);

		TransactionType trxType = refSvs.findTransactionTypeByActionAndInfoTypeCode(actionTypeCode,
				informationTypeCode);
		return trxType;
	}

	public ProgramServiceType getProgramServiceTypeSource(DaisiExchangeRequest request) {
		String abrv = request.getProgramServiceTypeSource();
		LOGGER.debug("lookup ProgramServiceTypeSource by  " + abrv);
		ProgramServiceType data = refSvs.findDaisiProgramServiceTypeByAbrv(abrv);
		return data;
	}

	public ProgramServiceType getProgramServiceTypeTarget(DaisiExchangeRequest request) {
		String abrv = request.getProgramServiceTypeTarget();
		LOGGER.debug("lookup ProgramServiceTypeTarget by  " + abrv);

		ProgramServiceType data = refSvs.findDaisiProgramServiceTypeByAbrv(abrv);
		return data;
	}

	public OrganizationType getOrganizationTypeSource(DaisiExchangeRequest request) {
		String abrv = request.getOrganizationTypeSource();
		LOGGER.debug("lookup OrganizationTypeSource by " + abrv);
		OrganizationType data = refSvs.findOrganizationTypeByAbrv(abrv);
		return data;
	}

	public OrganizationType getOrganizationTypeTarget(DaisiExchangeRequest request) {
		String abrv = request.getOrganizationTypeTarget();
		LOGGER.debug("lookup OrganizationTypeSource by " + abrv);
		OrganizationType data = refSvs.findOrganizationTypeByAbrv(abrv);
		return data;
	}

	// ----------- end of Ref. data lookups --------

	public BusinessTransaction updateBusinessTransaction(BusinessTransaction trx) {
		BusinessTransaction data = trxSvs.update(trx);
		return data;
	}

}
