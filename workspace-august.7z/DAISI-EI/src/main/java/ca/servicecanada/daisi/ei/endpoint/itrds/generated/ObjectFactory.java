
package ca.servicecanada.daisi.ei.endpoint.itrds.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the ca.servicecanada.daisi.ei.endpoint.itrds.generated package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SetDDFromDAISIResponse_QNAME = new QName("http://isp.sdc.gc.ca/ws/cs/jaxws/impl", "setDDFromDAISIResponse");
    private final static QName _SetDDFromDAISI_QNAME = new QName("http://isp.sdc.gc.ca/ws/cs/jaxws/impl", "setDDFromDAISI");
    private final static QName _PotentialErrors_QNAME = new QName("http://isp.sdc.gc.ca/ws/cs/jaxws/impl", "PotentialErrors");
    private final static QName _CsSystemException_QNAME = new QName("http://isp.sdc.gc.ca/ws/cs/jaxws/impl", "CsSystemException");
    private final static QName _SetDDFromDAISIServiceResponse_QNAME = new QName("http://isp.sdc.gc.ca/ws/cs/jaxws/impl", "setDDFromDAISIServiceResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: ca.servicecanada.daisi.ei.endpoint.itrds.generated
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link WebServiceGenericResponse }
     * 
     */
    public WebServiceGenericResponse createWebServiceGenericResponse() {
        return new WebServiceGenericResponse();
    }

    /**
     * Create an instance of {@link CsSystemException }
     * 
     */
    public CsSystemException createCsSystemException() {
        return new CsSystemException();
    }

    /**
     * Create an instance of {@link DaisiPushDDRequest }
     * 
     */
    public DaisiPushDDRequest createDaisiPushDDRequest() {
        return new DaisiPushDDRequest();
    }

    /**
     * Create an instance of {@link DaisiPushDDServiceResponse }
     * 
     */
    public DaisiPushDDServiceResponse createDaisiPushDDServiceResponse() {
        return new DaisiPushDDServiceResponse();
    }

    /**
     * Create an instance of {@link SetDDFromDAISIResponse }
     * 
     */
    public SetDDFromDAISIResponse createSetDDFromDAISIResponse() {
        return new SetDDFromDAISIResponse();
    }

    /**
     * Create an instance of {@link PotentialForErrors.ErrorList }
     * 
     */
    public PotentialForErrors.ErrorList createPotentialForErrorsErrorList() {
        return new PotentialForErrors.ErrorList();
    }

    /**
     * Create an instance of {@link SetDDFromDAISI }
     * 
     */
    public SetDDFromDAISI createSetDDFromDAISI() {
        return new SetDDFromDAISI();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDDFromDAISIResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl", name = "setDDFromDAISIResponse")
    public JAXBElement<SetDDFromDAISIResponse> createSetDDFromDAISIResponse(SetDDFromDAISIResponse value) {
        return new JAXBElement<SetDDFromDAISIResponse>(_SetDDFromDAISIResponse_QNAME, SetDDFromDAISIResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDDFromDAISI }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl", name = "setDDFromDAISI")
    public JAXBElement<SetDDFromDAISI> createSetDDFromDAISI(SetDDFromDAISI value) {
        return new JAXBElement<SetDDFromDAISI>(_SetDDFromDAISI_QNAME, SetDDFromDAISI.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PotentialForErrors }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl", name = "PotentialErrors")
    public JAXBElement<PotentialForErrors> createPotentialErrors(PotentialForErrors value) {
        return new JAXBElement<PotentialForErrors>(_PotentialErrors_QNAME, PotentialForErrors.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CsSystemException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl", name = "CsSystemException")
    public JAXBElement<CsSystemException> createCsSystemException(CsSystemException value) {
        return new JAXBElement<CsSystemException>(_CsSystemException_QNAME, CsSystemException.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DaisiPushDDServiceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl", name = "setDDFromDAISIServiceResponse")
    public JAXBElement<DaisiPushDDServiceResponse> createSetDDFromDAISIServiceResponse(DaisiPushDDServiceResponse value) {
        return new JAXBElement<DaisiPushDDServiceResponse>(_SetDDFromDAISIServiceResponse_QNAME, DaisiPushDDServiceResponse.class, null, value);
    }

}
