package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.FAULT;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_REJECTED;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.Fault;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.ProcessingStatusType;

import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.SetBankAccountBySINResponseDataAreaType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.SetBankAccountBySINResponseType;

@Component(value = "setBankAccountBySINResponseTranslator")
public class SetBankAccountBySINResponseTranslator extends AbstractDaisiDomainToDsbModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	@Override
	public DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("to DSB for ID = " + trx.getBusinessTransactionID());

		SetBankAccountBySINResponseType dsbData = new SetBankAccountBySINResponseType();

		MessageManifestTransactionalCT mf = MessageManifestBuilder.buildManifest(trx);
		//mf = setTestIndicatr(mf);
		dsbData.setMessageManifest(mf);

		// TODO: move to parent
		if (context.containsKey(FAULT)) {
			String faultstring = context.get(FAULT);
			Fault fault = buildFault_new(faultstring);
			dsbData.setFault(fault);
		} else {
			SetBankAccountBySINResponseDataAreaType dataArea = buildDataArea(trx, context);
			dsbData.setDataArea(dataArea);
		}

		DsbModelPlaceholder placeholder = new DsbModelPlaceholder();
		placeholder.setDsb(dsbData);

		return placeholder;
	}

	SetBankAccountBySINResponseDataAreaType buildDataArea(BusinessTransaction trx, Map<String, String> context) {
		SetBankAccountBySINResponseDataAreaType d = new SetBankAccountBySINResponseDataAreaType();

		if (context.containsKey(REJECT_REASON_CODE)) {
			ProcessingStatusType processingStatus = new ProcessingStatusType();
			String rejectedCode = context.get(REJECT_REASON_CODE);
			processingStatus.setRejectedCode(rejectedCode);

			// <ResultCode>Rejected</ResultCode
			processingStatus.setResultCode(RESULT_CODE_REJECTED);
			d.setProcessingStatus(processingStatus);
		} else if (context.containsKey(RESULT_CODE)) {
			String resultCode = context.get(RESULT_CODE);
			ProcessingStatusType processingStatus = new ProcessingStatusType();
			processingStatus.setResultCode(resultCode);
			d.setProcessingStatus(processingStatus);

		} else {
			// shouldn'r be here
		}
		return d;
	}

}
