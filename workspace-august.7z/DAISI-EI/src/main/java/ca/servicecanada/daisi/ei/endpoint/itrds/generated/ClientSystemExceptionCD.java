
package ca.servicecanada.daisi.ei.endpoint.itrds.generated;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for clientSystemExceptionCD.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="clientSystemExceptionCD">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NO_DATA_RETURNED"/>
 *     &lt;enumeration value="CS_SERVICE_NOT_AVAILABLE"/>
 *     &lt;enumeration value="UNEXPECTED_THROWABLE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "clientSystemExceptionCD")
@XmlEnum
public enum ClientSystemExceptionCD {

    NO_DATA_RETURNED,
    CS_SERVICE_NOT_AVAILABLE,
    UNEXPECTED_THROWABLE;

    public String value() {
        return name();
    }

    public static ClientSystemExceptionCD fromValue(String v) {
        return valueOf(v);
    }

}
