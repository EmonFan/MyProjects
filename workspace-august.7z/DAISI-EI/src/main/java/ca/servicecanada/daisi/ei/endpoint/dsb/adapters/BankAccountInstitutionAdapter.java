package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.truncateLeadingZeros4Institution;

import org.springframework.stereotype.Component;

@Component(value="bankAccountInstitutionAdapter")
public class BankAccountInstitutionAdapter implements DsbElementAdapter {

	@Override
	public String adaptToDsb(String originalValue) {
		return truncateLeadingZeros4Institution(originalValue);
	}

	@Override
	public String adaptFromDsb(String originalValue) {
		return originalValue;
	}

}
