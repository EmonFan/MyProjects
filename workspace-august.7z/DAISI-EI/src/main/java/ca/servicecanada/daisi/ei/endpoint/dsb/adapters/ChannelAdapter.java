package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import static ca.servicecanada.daisi.ei.DaisiConstants.CHANNEL_TYPE_FORM;
import static ca.servicecanada.daisi.ei.DaisiConstants.CHANNEL_TYPE_ONLINE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CHANNEL_TYPE_PHONE;

import org.springframework.stereotype.Component;

/**
 * CRA will send to ITRDS string "Online", "Phone", and "Form". We need to map
 * into our code table.
 */
@Component(value = "channelAdapter")
public class ChannelAdapter extends AbstractDsbElementAdapter {

	private final String CRA_CHANNEL_TYPE_ONLINE = "Online";
	private final String CRA_CHANNEL_TYPE_PHONE = "Phone";
	private final String CRA_CHANNEL_TYPE_FORM = "Form";

	public ChannelAdapter() {
		toDsbMapping.put(CHANNEL_TYPE_PHONE, CRA_CHANNEL_TYPE_PHONE);
		toDsbMapping.put(CHANNEL_TYPE_ONLINE, CRA_CHANNEL_TYPE_ONLINE);
		toDsbMapping.put(CHANNEL_TYPE_FORM, CRA_CHANNEL_TYPE_FORM);

		fromDsbMapping.put(CRA_CHANNEL_TYPE_FORM, CHANNEL_TYPE_FORM);
		fromDsbMapping.put(CRA_CHANNEL_TYPE_ONLINE, CHANNEL_TYPE_ONLINE);
		fromDsbMapping.put(CRA_CHANNEL_TYPE_PHONE, CHANNEL_TYPE_PHONE);

		dsbElementName = "Channel";
	}

}
