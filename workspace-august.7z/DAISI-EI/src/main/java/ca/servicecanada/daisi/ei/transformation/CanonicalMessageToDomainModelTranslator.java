package ca.servicecanada.daisi.ei.transformation;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.ref.ChannelType;
import ca.gc.servicecanada.daisi.domain.ref.OrganizationType;
import ca.gc.servicecanada.daisi.domain.ref.ProgramServiceType;
import ca.gc.servicecanada.daisi.domain.ref.TransactionType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.servicecanada.daisi.ei.exception.NewRequestCreateException;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;
import ca.servicecanada.daisi.ei.transformation.support.BusinessTransactionStatusBuilder;
import ca.servicecanada.daisi.ei.util.DaisiDateTimeUtils;

import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.*;

import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_PENDING;

/**
 * an 'event' message to be translated into DAISI JPA POJO class before
 * persisted
 */

@Component(value = "canonicalMessageToDomainModelTranslator")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class CanonicalMessageToDomainModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	// new request, no updates yet
	private static Date DEFAULT_DATE_UPDATED = null;
	private static String DEFAULT_USER_UPDATED = null;

	@Resource
	private DaisiDataServiceClient refSvs;

	@Resource
	private BusinessTransactionStatusBuilder trxStatusBuilder;

	private Date dateCreated;

	@Value("${db.audit.user.created}")
	private String userCreated;

	@Value("${db.audit.system.created}")
	private String systemCreated;

	private Date dateUpdated = DEFAULT_DATE_UPDATED;
	private String userUpdated = DEFAULT_USER_UPDATED;

	public BusinessTransaction transform(DaisiExchangeRequest request) {
		// FIXME: use factory
		DDBusinessTransaction trx = new DDBusinessTransaction();

		enrichUserInput(request, trx);

		enrichTransactionInfo(request, trx);

		enrichTechnicalTransactionInfo(request, trx);

		enrichRefData(request, trx);

		enrichAuditInfo(request, trx);

		enrichDDInfo(request, trx);

		enrichStatusInfo(request, trx);

		LOGGER.debug(trx.toString());
		return trx;
	}

	/** sin, surname, dob */
	void enrichUserInput(DaisiExchangeRequest request, DDBusinessTransaction trx) {
		//
		String sin = request.getSin();
		String surname = request.getSurname();
		String birthDate = request.getBirthDate();
		String consentCode = request.getConsentCode();

		trx.setBirthDate(birthDate);
		trx.setSin(sin);
		trx.setSurname(surname);
		trx.setConsentCode(consentCode);

	}

	void enrichTransactionInfo(DaisiExchangeRequest request, DDBusinessTransaction trx) {
		String businessTransactionID = request.getId();
		trx.setBusinessTransactionID(businessTransactionID);
		if ("ESD".equalsIgnoreCase(request.getOrganizationTypeSource())){
			trx.setBusinessTransactionDate(new Date());
		} else {
			trx.setBusinessTransactionDate(DaisiDateTimeUtils.toDate(request.getBusinessTransactionDateTime()));
		}
		
	}

	void enrichTechnicalTransactionInfo(DaisiExchangeRequest request, BusinessTransaction trx) {
		TechnicalTransaction techTrx = new TechnicalTransaction();
		techTrx.setBusinessTransaction(trx);
		Date technicalTransactionDate = new Date();
		techTrx.setTechnicalTransactionDate(technicalTransactionDate);

		// TODO: move to util
		String technicalTransactionID = UUID.randomUUID().toString();
		techTrx.setTechnicalTransactionID(technicalTransactionID);

		// --------- Audit
		dateCreated = new Date();

		techTrx.setDateCreated(dateCreated);
		techTrx.setUserCreated(userCreated);
		techTrx.setSystemCreated(systemCreated);
		techTrx.setUserUpdated(userUpdated);
		techTrx.setDateUpdated(dateUpdated);
		// ---------

		List<TechnicalTransaction> technicalTransactions = new ArrayList<TechnicalTransaction>();
		technicalTransactions.add(techTrx);
		trx.setTechnicalTransactions(technicalTransactions);

	}

	void enrichAuditInfo(DaisiExchangeRequest request, BusinessTransaction trx) {
		dateCreated = new Date();

		trx.setDateCreated(dateCreated);
		trx.setUserCreated(userCreated);
		trx.setSystemCreated(systemCreated);
		trx.setUserUpdated(userUpdated);
		trx.setDateUpdated(dateUpdated);
	}

	void enrichRefData(DaisiExchangeRequest request, BusinessTransaction trx) {
		ChannelType channelType = null;
		OrganizationType organizationTypeSender;
		OrganizationType organizationTypeTarget;
		ProgramServiceType programServiceTypeSource;
		ProgramServiceType programServiceTypeTarget;
		TransactionType transactionType;

		try {
			if (request.getChannelType() != null)
				channelType = refSvs.getChannelType(request);
			
			organizationTypeSender = refSvs.getOrganizationTypeSource(request);
			organizationTypeTarget = refSvs.getOrganizationTypeTarget(request);
			programServiceTypeSource = refSvs.getProgramServiceTypeSource(request);
			programServiceTypeTarget = refSvs.getProgramServiceTypeTarget(request);
			transactionType = refSvs.getTransactionType(request);
		} catch (javax.persistence.NoResultException e) {
			// javax.persistence.NoResultException: No entity found for query
			LOGGER.error(e.getMessage());
			throw new NewRequestCreateException(e.getMessage());
		}

		trx.setChannelType(channelType);
		trx.setOrganizationTypeSource(organizationTypeSender);
		trx.setOrganizationTypeTarget(organizationTypeTarget);
		trx.setProgramServiceTypeSource(programServiceTypeSource);
		trx.setProgramServiceTypeTarget(programServiceTypeTarget);
		trx.setTransactionType(transactionType);

	}

	void enrichDDInfo(DaisiExchangeRequest request, DDBusinessTransaction trx) {
		// Account Number has to be 5 to 12 digits
		String accountNumber = null;
		try {
			accountNumber = request.getAccountNumber();

			if (accountNumber != null && accountNumber.length() > 12) {
				accountNumber = truncateLeadingZeros4AccountNumber(accountNumber);
			}

		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}

		trx.setAccountNumber(accountNumber);
		trx.setInstitutionNumber(request.getInstitution());
		trx.setTransitNumber(request.getTransitNumber());

	}

	void enrichStatusInfo(DaisiExchangeRequest request, BusinessTransaction trx) {
		trx = trxStatusBuilder.buildBusinessTransactionStatus(trx, STATUS_TYPE_PENDING);
	}

	// for Junit test
	public void setRefSvs(DaisiDataServiceClient refSvs) {
		this.refSvs = refSvs;
	}

}
