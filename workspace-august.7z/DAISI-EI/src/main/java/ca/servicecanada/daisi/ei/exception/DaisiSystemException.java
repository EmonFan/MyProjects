package ca.servicecanada.daisi.ei.exception;

/** connection errors etc */
public class DaisiSystemException extends RuntimeException {

	public DaisiSystemException() {
		super();
	}

	public DaisiSystemException(String err) {
		super(err);
	}

	public DaisiSystemException(Exception e) {
		super(e);
	}

}
