package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.util.EiUtils.toXMLGregorianCalendar;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPConstants;

import org.springframework.beans.factory.annotation.Value;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.adapters.DsbElementAdapter;
import ca.servicecanada.daisi.ei.endpoint.dsb.adapters.DsbElementAdapterFactory;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.Fault;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.NotificationIDCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SystemIDCT;

public abstract class AbstractDaisiDomainToDsbModelTranslator implements DaisiDomainToDsbModelTranslator {

	@Value("${dsb.testIndicator}")
	protected boolean testIndicator;

	@Resource
	protected DsbElementAdapterFactory dsbElementAdapterFactory;

	// FIXME: - weird
	protected MessageManifestTransactionalCT setTestIndicatr(MessageManifestTransactionalCT mf) {
		mf.setTestIndicator(testIndicator);
		return mf;
	}

	protected Fault buildFault(String faultstring) {

		Fault fault = new Fault();
		QName faultName = new QName(SOAPConstants.URI_NS_SOAP_ENVELOPE, "Server");
		fault.setFaultcode(faultName);
		fault.setDetail(faultstring);
		fault.setFaultstring(faultstring);
		return fault;
	}
	
	//FIXME: clean up to only keep buildFault_new
	protected ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.Fault buildFault_new(String faultstring) {

		ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.Fault fault = 
				new ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.Fault();
		QName faultName = new QName(SOAPConstants.URI_NS_SOAP_ENVELOPE, "Server");
		fault.setFaultcode(faultName);
		fault.setFaultstring("500");
		fault.setDetail(faultstring);		
		return fault;
	}

	protected Map<String, String> adapt(Map<String, String> elementsToAdapt) {
		String originalValue;
		String adaptedValue;
		for (String dsbElementName : elementsToAdapt.keySet()) {
			originalValue = elementsToAdapt.get(dsbElementName);
			DsbElementAdapter adapter = dsbElementAdapterFactory.getDsbElementAdapter(dsbElementName);
			if (adapter != null) {
				adaptedValue = adapter.adaptToDsb(originalValue);
			} else {
				adaptedValue = originalValue;
			}
			elementsToAdapt.put(dsbElementName, adaptedValue);
		}

		return elementsToAdapt;
	}

	protected String adapt(String dsbElementName, String originalValue) {
		String adaptedValue;
		DsbElementAdapter adapter = dsbElementAdapterFactory.getDsbElementAdapter(dsbElementName);
		if (adapter != null) {
			adaptedValue = adapter.adaptToDsb(originalValue);
		} else {
			adaptedValue = originalValue;
		}
		return adaptedValue;
	}

	protected MessageManifestTransactionalCT buildManifest(BusinessTransaction trx) {

		XMLGregorianCalendar date = toXMLGregorianCalendar(trx.getBusinessTransactionDate());
		MessageManifestTransactionalCT mf = new MessageManifestTransactionalCT();

		NotificationIDCT businessTrxIDvalue = new NotificationIDCT();
		businessTrxIDvalue.setValue(trx.getBusinessTransactionID());
		mf.setBusinessTransactionID(businessTrxIDvalue);

		mf.setBusinessTransactionDateTime(date);

		NotificationIDCT messageIDvalue = new NotificationIDCT();
		messageIDvalue.setValue(UUID.randomUUID().toString());
		mf.setMessageID(messageIDvalue);
		mf.setMessageDateTime(date);

		// When CRA sends a request it will be set to CRA.
		// When CPP sends a request it will be set to CPP.
		// Organization Source

		// SystemID must be set to CPP. When OAS and
		// EI come on board, they will be setting it to OAS and EI respectively.
		// for now we set it to ESDC
		String systemID = trx.getOrganizationTypeSource().getOrganizationTypeNameEn();
		SystemIDCT systemValue = new SystemIDCT();

		// systemID = adapt(SYSTEM_ID, systemID);

		systemValue.setValue(systemID);

		mf.setSystemID(systemValue);

		// TODO: fix the case for a collection size >1

		String technicalTransactionID;
		Date technicalTransactionDate;
		List<TechnicalTransaction> technicalTrxs = trx.getTechnicalTransactions();
		if (technicalTrxs == null || technicalTrxs.size() < 1) {
			// error
			technicalTransactionID = "UNDEFINED_" + UUID.randomUUID().toString();
			technicalTransactionDate = new Date();
		} else {
			TechnicalTransaction techTrx = technicalTrxs.get(0);
			technicalTransactionID = techTrx.getTechnicalTransactionID();
			technicalTransactionID = techTrx.getTechnicalTransactionID();
			technicalTransactionDate = techTrx.getTechnicalTransactionDate();
		}

		NotificationIDCT techTrxIDValue = new NotificationIDCT();
		techTrxIDValue.setValue(technicalTransactionID);
		mf.setTechnicalTransactionID(techTrxIDValue);
		mf.setTechnicalTransactionDateTime(toXMLGregorianCalendar(technicalTransactionDate));
		// mf.setTestIndicator(true);
		return mf;
	}

}
