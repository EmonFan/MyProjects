package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component(value = "bankAccountNumberAdapter")
public class BankAccountNumberAdapter implements DsbElementAdapter {
	
	private Logger LOGGER = LogManager.getLogger(getClass());

	@Override
	public String adaptToDsb(String originalValue) {
		String result = null;
		String removeDashCharacter = null;
		
		try {
			removeDashCharacter = removeDashCharacter(originalValue);
		
			if (removeDashCharacter.length() > 12){
				result = truncateLeadingZeros4AccountNumber(removeDashCharacter);
			} else if (removeDashCharacter.length() < 5){
				result = padWithZeros4AccountNumber(removeDashCharacter);
			} else {
				result = removeDashCharacter;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		return result;
	}

	@Override
	public String adaptFromDsb(String originalValue) {
		// TODO Auto-generated method stub
		return originalValue;
	}

}
