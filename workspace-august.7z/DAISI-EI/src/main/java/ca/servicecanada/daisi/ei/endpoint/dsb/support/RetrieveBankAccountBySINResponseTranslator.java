package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.FAULT;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_ACCEPTED;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_REJECTED;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.Fault;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.ProcessingStatusType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.RetrieveBankAccountBySINResponseDataAreaType;

import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.padWithZeros4AccountNumber;
import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.removeDashCharacter;
import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.truncateLeadingZeros4AccountNumber;
import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.truncateLeadingZeros4Institution;

@Component(value = "retrieveBankAccountBySINResponseTranslator")
public class RetrieveBankAccountBySINResponseTranslator extends AbstractDaisiDomainToDsbModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	@Override
	public DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("to DSB for ID = " + trx.getBusinessTransactionID());
		
		RetrieveBankAccountBySINResponseType dsbData = new RetrieveBankAccountBySINResponseType();
		MessageManifestTransactionalCT mf = MessageManifestBuilder.buildManifest(trx);
		//mf = setTestIndicatr(mf);
		dsbData.setMessageManifest(mf);

		// TODO: move to parent
		if (context.containsKey(FAULT)) {
			String faultstring = context.get(FAULT);
			Fault fault = buildFault_new(faultstring);
			dsbData.setFault(fault);
		} else {
			RetrieveBankAccountBySINResponseDataAreaType dataArea = buildDataArea(trx, context);
			dsbData.setDataArea(dataArea);
		}

		DsbModelPlaceholder placeholder = new DsbModelPlaceholder();
		placeholder.setDsb(dsbData);

		return placeholder;
	}

	/**
	 * <code>
	context.put(STATUS_TYPE, statusType);
	context.put(FAULT, faultDetails);
	context.put(REJECT_REASON_CODE, rejectReasonCode);
	context.put(RESULT_CODE, resultCode);
	</code>
	 */
	RetrieveBankAccountBySINResponseDataAreaType buildDataArea(BusinessTransaction trx, Map<String, String> context) {
		RetrieveBankAccountBySINResponseDataAreaType d = new RetrieveBankAccountBySINResponseDataAreaType();

		if (context.containsKey(REJECT_REASON_CODE)) {
			ProcessingStatusType processingStatus = new ProcessingStatusType();
			String rejectedCode = context.get(REJECT_REASON_CODE);
			processingStatus.setRejectedCode(rejectedCode);

			// <ResultCode>Rejected</ResultCode
			processingStatus.setResultCode(RESULT_CODE_REJECTED);
			d.setProcessingStatus(processingStatus);
		} else if (context.containsKey(RESULT_CODE)) {
			String resultCode = context.get(RESULT_CODE);
			ProcessingStatusType processingStatus = new ProcessingStatusType();
			processingStatus.setResultCode(resultCode);
			d.setProcessingStatus(processingStatus);

			if (resultCode.equals(RESULT_CODE_ACCEPTED)) {
				d.setBankAccount(buildDataAreaBankAccount(trx));
			} else {
				// do nothing
			}

		} else {
			// shouldn'r be here
		}
		return d;
	}

	private RetrieveBankAccountBySINResponseDataAreaType.BankAccount buildDataAreaBankAccount(BusinessTransaction trx) {

		String accountNumber = ((DDBusinessTransaction) trx).getAccountNumber();

		String removeDashCharacter = null;
		
		try {
			removeDashCharacter = removeDashCharacter(accountNumber);
		
			if (removeDashCharacter.length() > 12){
				accountNumber = truncateLeadingZeros4AccountNumber(removeDashCharacter);
			} else if (removeDashCharacter.length() < 5){
				accountNumber = padWithZeros4AccountNumber(removeDashCharacter);
			} else {
				accountNumber = removeDashCharacter;
			}
			
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
		}
		
		String institutionNumber = ((DDBusinessTransaction) trx).getInstitutionNumber();
		String transitNumber = ((DDBusinessTransaction) trx).getTransitNumber();

		RetrieveBankAccountBySINResponseDataAreaType.BankAccount bankAccount = new RetrieveBankAccountBySINResponseDataAreaType.BankAccount();
		bankAccount.setAccountNumber(accountNumber);
		bankAccount.setInstitution(truncateLeadingZeros4Institution(institutionNumber));
		bankAccount.setTransit(transitNumber);

		return bankAccount;

	}

}
