package ca.servicecanada.daisi.ei.endpoint.itrds;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.DataAccessService;
import ca.servicecanada.daisi.ei.model.DirectDepositInfo;

@Component(value = "itrdsDataAccessService")
public class ITRDSDataAccessService implements DataAccessService {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private ITRDSClient client;

	@Override
	public void retrieveDirectDeposit(BusinessTransaction data) {

		String sin = data.getSin();
		String surname = data.getSurname();
		String birthDate = data.getBirthDate();
		String channelType = data.getChannelType().getChannelTypeAbrvEn();
		String consentCode = data.getConsentCode();
		String businessTranscationId = data.getBusinessTransactionID();

		LOGGER.debug("Retriving DD from ITRDS for SIN *** *** " + sin.substring(7));
		DirectDepositInfo dd = client.retrieveDirectDeposit(sin, surname, birthDate, channelType, consentCode, businessTranscationId);
		String accountNumber = dd.getAccountNumber();
		String institutionNumber = dd.getInstitutionNumber();
		String transitNumber = dd.getTransitNumber();

		LOGGER.debug("Retrived DD from ITRDS for SIN *** *** " + sin.substring(7));

		// FIXME: DD vs Abstract
		DDBusinessTransaction ddData = (DDBusinessTransaction) data;
		ddData.setAccountNumber(accountNumber);
		ddData.setInstitutionNumber(institutionNumber);
		ddData.setTransitNumber(transitNumber);

	}

	@Override
	public void updateDirectDeposit(BusinessTransaction data) {
		client.updateDirectDeposit(data);
	}

}
