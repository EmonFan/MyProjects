package ca.servicecanada.daisi.ei.transformation;

import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;

/** BusinessTransaction is enriched with data from another resource */

@Component(value = "directDepostCPPcontentEnricher")
public class BusinessTransactionContentEnricher extends AbstractDataEnricher {

	protected void execute(BusinessTransaction trx) {
		dataAccessService.retrieveDirectDeposit(trx);
	}

}
