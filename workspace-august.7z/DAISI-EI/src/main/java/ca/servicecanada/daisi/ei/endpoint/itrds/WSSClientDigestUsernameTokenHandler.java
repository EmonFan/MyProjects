package ca.servicecanada.daisi.ei.endpoint.itrds;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;

import java.io.ByteArrayOutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/**
 * A cient-side handler for a WS-Security UsernameToken header with password
 * digest. Nothing fancy for now, very simple implementation.
 */
public class WSSClientDigestUsernameTokenHandler implements SOAPHandler<SOAPMessageContext> {
	private static final String WSSE_PREFIX = "wsse";

	private static final String WSSE_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd";

	private static final String WSU_PREFIX = "wsu";

	private static final String WSU_NS = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd";

	private static final String dateFormat = "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'SSS'Z'";
	private final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	
	@Value("${itrds.ws.user}")
	protected String username;
	
	@Value("${itrds.ws.password}")
	protected String daisiClientPassWord;


	public WSSClientDigestUsernameTokenHandler() {
		
	}

	public WSSClientDigestUsernameTokenHandler(final String username, final String password) {
		this.username = username;
		this.daisiClientPassWord = password;
	}

	@Override
	public boolean handleMessage(final SOAPMessageContext context) {
		final boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

		ByteArrayOutputStream mstream;
		MessageDigest md;

		SOAPEnvelope envelope;
		SOAPFactory factory;
		SOAPHeader header;
		SOAPElement securityElem;
		SOAPElement tokenElem;
		SOAPElement tmpElem;

		String password;
		String created;
		byte[] nonceBytes;
		byte[] digestBytes;

		// --[ We only care when it is a request/outbound
		if (outboundProperty) {
			try {

				envelope = context.getMessage().getSOAPPart().getEnvelope();
				factory = SOAPFactory.newInstance();

				// ---[ Get the needed pieces of information to be put in header
				password = daisiClientPassWord;
				created = sdf.format(new java.util.Date());
				
				// 20 byte nonce was used during R&D and works
				nonceBytes = new byte[20]; 
				
				// NOTE: SecureRandom is obviou slower (and may block is it runs out of entropy)
				// but simpler Random should be used for securty purposes
				new SecureRandom().nextBytes(nonceBytes); 
																													
				// ---[ Create the digest with user's password to be sent to
				// server
				mstream = new ByteArrayOutputStream();
				md = MessageDigest.getInstance("SHA-1");
				md.reset();

				mstream.write(nonceBytes);
				mstream.write(created.getBytes("UTF-8"));
				mstream.write(password.getBytes("UTF-8"));

				digestBytes = md.digest(mstream.toByteArray());
				mstream.close();

				// ---[ Add the UsernameToken header
				securityElem = factory.createElement("Security", WSSClientDigestUsernameTokenHandler.WSSE_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSSE_NS);
				securityElem.addAttribute(QName.valueOf(envelope.getPrefix() + ":mustUnderstand"), "1");

				tokenElem = factory.createElement("UsernameToken", WSSClientDigestUsernameTokenHandler.WSSE_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSSE_NS);
				tokenElem.addAttribute(
						new QName(WSSClientDigestUsernameTokenHandler.WSU_NS, "Id",
								WSSClientDigestUsernameTokenHandler.WSU_PREFIX),
						java.util.UUID.randomUUID().toString());

				tmpElem = factory.createElement("Username", WSSClientDigestUsernameTokenHandler.WSSE_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSSE_NS);
				tmpElem.addTextNode(username);
				tokenElem.addChildElement(tmpElem);

				tmpElem = factory.createElement("Password", WSSClientDigestUsernameTokenHandler.WSSE_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSSE_NS);
				tmpElem.addAttribute(QName.valueOf("Type"),
						"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest");
				// tmpElem.setAttribute("Type",
				// "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest");
				tmpElem.addTextNode(new String(Base64.encodeBase64(digestBytes), "UTF-8"));
				tokenElem.addChildElement(tmpElem);

				tmpElem = factory.createElement("Nonce", WSSClientDigestUsernameTokenHandler.WSSE_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSSE_NS);
				tmpElem.addAttribute(QName.valueOf("EncodingType"),
						"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary");
				// tmpElem.setAttribute("EncodingType",
				// "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary");
				tmpElem.addTextNode(new String(Base64.encodeBase64(nonceBytes), "UTF-8"));
				tokenElem.addChildElement(tmpElem);

				tmpElem = factory.createElement("Created", WSSClientDigestUsernameTokenHandler.WSU_PREFIX,
						WSSClientDigestUsernameTokenHandler.WSU_NS);
				tmpElem.addTextNode(created);
				tokenElem.addChildElement(tmpElem);

				securityElem.addChildElement(tokenElem);

				// ---[ Add header to envelope
				header = envelope.getHeader();
				if (header == null) {
					header = envelope.addHeader();
				}
				header.addChildElement(securityElem);
			} catch (final Exception ex) {
				// Simply propagate as an un-checked exception (good enough for
				// now/unit testing)
				throw new RuntimeException("An error occured injecting WS-Security UsernameToken into SOAP mesage.",
						ex);
			}
		}

		return true; // true => continue processing
	}

	@Override
	public boolean handleFault(final SOAPMessageContext context) {
		// Just return true, handler/chain processing will continue for the
		// current message
		// (ie no need for authentication on faults).
		return true;
	}

	@Override
	public void close(final MessageContext context) {
	}

	@Override
	public Set<QName> getHeaders() {
		// no real need to indicate which headers we support on client side
		return null;
	}

	/**
	 * Returns the password for the user with the specified username (to be used
	 * in re-creating the password digest).
	 */
	//protected String getUserPassword(final String sourceUsername) {
		// TODO:PL: To be confirmed
		// NOTE:
		// Could build a factory-style thing to dynamically instantiate the
		// proper password provider (kind of like what the smtp mail client
		// does)
		// Or could make this method abstract and create a sub-class specified
		// to ITRDS, to make this class more generic (also see constructor...
		// user name acquisition would also follow the same route)

		// (The following code is adapted from the original Axis
		// "ClientPWCallback" class)

//		if ("wss4j".equals(sourceUsername)) {
//			return "security";
//		} else if ("ISLD11".equals(sourceUsername)) {
//			return "ISLD";
//		} else if ("WEBSER1".equals(sourceUsername)) {
//			return "WEBSER";
//		} else if ("GOLSOCV".equals(sourceUsername)) {
//			return "NOTUSED";
//		} else if ("GOLRTRA".equals(sourceUsername)) {
//			return "NOTUSED";
//		} else if ("DAISI".equals(sourceUsername)){
//			return "DAISI";
//		}
		// TODO:PL: Re-test using a bad password... getting a DOMException when
		// running test cases instead of expected Access denied SOAP fault
		//throw new RuntimeException("Invalid user [" + sourceUsername + "]");
	//}

}
