package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;

@Component
public class DaisiDomainToDsbModelTranslatorFactory {
	private Logger LOGGER = LogManager.getLogger();

	public final static String PIPE = "|";

	@Resource(name = "daisiDomainToDsbModelTranslatorMap2")
	private Map<String, DaisiDomainToDsbModelTranslator> daisiDomainToDsbModelTranslatorMap;

	public DaisiDomainToDsbModelTranslatorFactory() {
		// initFactory();
	}

	public DaisiDomainToDsbModelTranslator getDaisiDomainToDsbModelTranslator(BusinessTransaction trx) {

		DaisiDomainToDsbModelTranslator translator;
		String key = buildKey(trx);
		LOGGER.info("lookup DaisiDomainToDsbModelTranslator for " + key);

		if (daisiDomainToDsbModelTranslatorMap.containsKey(key)) {
			translator = daisiDomainToDsbModelTranslatorMap.get(key);
		} else {
			LOGGER.warn("Can't find a DaisiDomainToDsbModelTranslator for  " + key);
			throw new IllegalArgumentException("Can't find a DaisiDomainToDsbModelTranslator for  " + key);
		}
		return translator;
	}

	private String buildKey(BusinessTransaction trx) {
		String actionType = trx.getTransactionType().getActionType().getActionTypeAbrvEn();
		String infoType = trx.getTransactionType().getInformationType().getInformationTypeAbrvEn();
		String programSource = trx.getProgramServiceTypeSource().getServiceTypeAbrvEn();
		String programTarget = trx.getProgramServiceTypeTarget().getServiceTypeAbrvEn();

		StringBuilder b = new StringBuilder();
		b.append(programSource);
		b.append(PIPE);
		b.append(actionType);
		b.append(PIPE);
		b.append(infoType);
		b.append(PIPE);
		b.append(programTarget);

		String tmp = b.toString();
		LOGGER.debug(tmp);
		return tmp;

	}

	public void setDaisiDomainToDsbModelTranslatorMap(
			Map<String, DaisiDomainToDsbModelTranslator> daisiDomainToDsbModelTranslatorMap) {
		this.daisiDomainToDsbModelTranslatorMap = daisiDomainToDsbModelTranslatorMap;
	}

}
