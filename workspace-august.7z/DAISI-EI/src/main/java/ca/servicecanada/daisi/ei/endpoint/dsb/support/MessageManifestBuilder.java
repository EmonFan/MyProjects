package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.util.EiUtils.toXMLGregorianCalendar;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.xml.datatype.XMLGregorianCalendar;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.NotificationIDCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.SystemIDCT;

public class MessageManifestBuilder {

	static public MessageManifestTransactionalCT buildManifest(BusinessTransaction trx) {

		XMLGregorianCalendar date = toXMLGregorianCalendar(trx.getBusinessTransactionDate());
		MessageManifestTransactionalCT mf = new MessageManifestTransactionalCT();

		NotificationIDCT businessTrxIDvalue = new NotificationIDCT();
		businessTrxIDvalue.setValue(trx.getBusinessTransactionID());
		mf.setBusinessTransactionID(businessTrxIDvalue);

		mf.setBusinessTransactionDateTime(date);

		NotificationIDCT messageIDvalue = new NotificationIDCT();
		messageIDvalue.setValue(UUID.randomUUID().toString());
		mf.setMessageID(messageIDvalue);
		mf.setMessageDateTime(date);

		// When CRA sends a request it will be set to CRA.
		// When CPP sends a request it will be set to CPP.
		// Organization Source

		// SystemID must be set to CPP. When OAS and
		// EI come on board, they will be setting it to OAS and EI respectively.
		// for now we set it to ESDC
		String systemID = trx.getOrganizationTypeSource().getOrganizationTypeNameEn();
		SystemIDCT systemValue = new SystemIDCT();

		// systemID = adapt(SYSTEM_ID, systemID);

		systemValue.setValue(systemID);

		mf.setSystemID(systemValue);

		// TODO: fix the case for a collection size >1

		String technicalTransactionID;
		Date technicalTransactionDate;
		List<TechnicalTransaction> technicalTrxs = trx.getTechnicalTransactions();
		if (technicalTrxs == null || technicalTrxs.size() < 1) {
			// error
			technicalTransactionID = "UNDEFINED_" + UUID.randomUUID().toString();
			technicalTransactionDate = new Date();
		} else {
			TechnicalTransaction techTrx = technicalTrxs.get(0);
			technicalTransactionID = techTrx.getTechnicalTransactionID();
			technicalTransactionID = techTrx.getTechnicalTransactionID();
			technicalTransactionDate = techTrx.getTechnicalTransactionDate();
		}

		NotificationIDCT techTrxIDValue = new NotificationIDCT();
		techTrxIDValue.setValue(technicalTransactionID);
		mf.setTechnicalTransactionID(techTrxIDValue);
		mf.setTechnicalTransactionDateTime(toXMLGregorianCalendar(technicalTransactionDate));
		// mf.setTestIndicator(true);
		return mf;
	}
}
