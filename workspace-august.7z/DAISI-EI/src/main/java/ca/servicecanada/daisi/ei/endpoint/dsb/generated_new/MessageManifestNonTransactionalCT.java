
package ca.servicecanada.daisi.ei.endpoint.dsb.generated_new;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for MessageManifest-NonTransactional-CT complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MessageManifest-NonTransactional-CT">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MessageDateTime" type="{http://interoperability.gc.ca/core/1.0}DateTimeST" minOccurs="0"/>
 *         &lt;element name="MessageID" type="{http://interoperability.gc.ca/core/1.0}NotificationIDCT"/>
 *         &lt;element name="SystemID" type="{http://interoperability.gc.ca/core/1.0}SystemIDCT"/>
 *         &lt;element name="TestIndicator" type="{http://interoperability.gc.ca/core/1.0}IndicatorST"/>
 *         &lt;element name="LanguageCode" type="{http://interoperability.gc.ca/core/1.0}LanguageCodeCT"/>
 *         &lt;element name="Confidentiality" type="{http://interoperability.gc.ca/core/1.0}ConfidentialityST" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MessageManifest-NonTransactional-CT", namespace = "http://interoperability.gc.ca/core/1.0", propOrder = {
    "messageDateTime",
    "messageID",
    "systemID",
    "testIndicator",
    "languageCode",
    "confidentiality"
})
public class MessageManifestNonTransactionalCT implements Serializable {

    @XmlElement(name = "MessageDateTime")
    protected XMLGregorianCalendar messageDateTime;
    @XmlElement(name = "MessageID", required = true)
    protected NotificationIDCT messageID;
    @XmlElement(name = "SystemID", required = true)
    protected SystemIDCT systemID;
    @XmlElement(name = "TestIndicator", defaultValue = "false")
    protected boolean testIndicator;
    @XmlElement(name = "LanguageCode", required = true)
    protected LanguageCodeCT languageCode;
    @XmlElement(name = "Confidentiality")
    protected ConfidentialityST confidentiality;

    /**
     * Gets the value of the messageDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMessageDateTime() {
        return messageDateTime;
    }

    /**
     * Sets the value of the messageDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMessageDateTime(XMLGregorianCalendar value) {
        this.messageDateTime = value;
    }

    /**
     * Gets the value of the messageID property.
     * 
     * @return
     *     possible object is
     *     {@link NotificationIDCT }
     *     
     */
    public NotificationIDCT getMessageID() {
        return messageID;
    }

    /**
     * Sets the value of the messageID property.
     * 
     * @param value
     *     allowed object is
     *     {@link NotificationIDCT }
     *     
     */
    public void setMessageID(NotificationIDCT value) {
        this.messageID = value;
    }

    /**
     * Gets the value of the systemID property.
     * 
     * @return
     *     possible object is
     *     {@link SystemIDCT }
     *     
     */
    public SystemIDCT getSystemID() {
        return systemID;
    }

    /**
     * Sets the value of the systemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link SystemIDCT }
     *     
     */
    public void setSystemID(SystemIDCT value) {
        this.systemID = value;
    }

    /**
     * Gets the value of the testIndicator property.
     * 
     */
    public boolean isTestIndicator() {
        return testIndicator;
    }

    /**
     * Sets the value of the testIndicator property.
     * 
     */
    public void setTestIndicator(boolean value) {
        this.testIndicator = value;
    }

    /**
     * Gets the value of the languageCode property.
     * 
     * @return
     *     possible object is
     *     {@link LanguageCodeCT }
     *     
     */
    public LanguageCodeCT getLanguageCode() {
        return languageCode;
    }

    /**
     * Sets the value of the languageCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link LanguageCodeCT }
     *     
     */
    public void setLanguageCode(LanguageCodeCT value) {
        this.languageCode = value;
    }

    /**
     * Gets the value of the confidentiality property.
     * 
     * @return
     *     possible object is
     *     {@link ConfidentialityST }
     *     
     */
    public ConfidentialityST getConfidentiality() {
        return confidentiality;
    }

    /**
     * Sets the value of the confidentiality property.
     * 
     * @param value
     *     allowed object is
     *     {@link ConfidentialityST }
     *     
     */
    public void setConfidentiality(ConfidentialityST value) {
        this.confidentiality = value;
    }

}
