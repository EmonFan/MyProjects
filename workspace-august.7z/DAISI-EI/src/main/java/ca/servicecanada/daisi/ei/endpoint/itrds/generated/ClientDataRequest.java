
package ca.servicecanada.daisi.ei.endpoint.itrds.generated;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for clientDataRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="clientDataRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="individualId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="sin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="stubTestInd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "clientDataRequest", propOrder = {
    "individualId",
    "sin",
    "stubTestInd"
})
@XmlSeeAlso({
    DaisiDDInfoPullRequest.class
})
public class ClientDataRequest {

    protected Long individualId;
    protected String sin;
    protected String stubTestInd;

    /**
     * Gets the value of the individualId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getIndividualId() {
        return individualId;
    }

    /**
     * Sets the value of the individualId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setIndividualId(Long value) {
        this.individualId = value;
    }

    /**
     * Gets the value of the sin property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSin() {
        return sin;
    }

    /**
     * Sets the value of the sin property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSin(String value) {
        this.sin = value;
    }

    /**
     * Gets the value of the stubTestInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStubTestInd() {
        return stubTestInd;
    }

    /**
     * Sets the value of the stubTestInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStubTestInd(String value) {
        this.stubTestInd = value;
    }

}
