package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_REQUEST_FORM;
import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_REQUEST_ONLINE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_REQUEST_PHONE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_SEND_FORM;
import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_SEND_ONLINE;
import static ca.servicecanada.daisi.ei.DaisiConstants.CONSENT_TYPE_DD_SEND_PHONE;
import static ca.servicecanada.daisi.ei.DaisiConstants.DSB_CHANNEL_TYPE_FORM;
import static ca.servicecanada.daisi.ei.DaisiConstants.DSB_CHANNEL_TYPE_ONLINE;
import static ca.servicecanada.daisi.ei.DaisiConstants.DSB_CHANNEL_TYPE_PHONE;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class DataAreaAdapterStringComputing implements DataAreaAdapter {

	private Logger LOGGER = LogManager.getLogger();

	/**
	 * {S|PHONE=STL, R|PHONE=RTL, S|FORM=SFO, S|ONLINE=SON, R|ONLINE=RON,
	 * R|FORM=UNDEFINED}
	 */
	private Map<String, String> map;

	private static final String ACTION_TYPE_REQUEST = "R";
	private static final String ACTION_TYPE_SEND = "S";

	private static final String SEPARATOR = "|";

	private static final String DD_SEND_ONLINE = ACTION_TYPE_SEND + SEPARATOR + DSB_CHANNEL_TYPE_ONLINE;
	private static final String DD_SEND_PHONE = ACTION_TYPE_SEND + SEPARATOR + DSB_CHANNEL_TYPE_PHONE;
	private static final String DD_SEND_FORM = ACTION_TYPE_SEND + SEPARATOR + DSB_CHANNEL_TYPE_FORM;

	private static final String DD_REQUEST_ONLINE = ACTION_TYPE_REQUEST + SEPARATOR + DSB_CHANNEL_TYPE_ONLINE;
	private static final String DD_REQUEST_PHONE = ACTION_TYPE_REQUEST + SEPARATOR + DSB_CHANNEL_TYPE_PHONE;
	private static final String DD_REQUEST_FORM = ACTION_TYPE_REQUEST + SEPARATOR + DSB_CHANNEL_TYPE_FORM;

	public DataAreaAdapterStringComputing() {
		map = new HashMap<String, String>();
		buildDaisiToCraConsentMap();

	}

	void buildDaisiToCraConsentMap() {
		map.put(DD_SEND_ONLINE, CONSENT_TYPE_DD_SEND_ONLINE);
		map.put(DD_SEND_PHONE, CONSENT_TYPE_DD_SEND_PHONE);
		map.put(DD_SEND_FORM, CONSENT_TYPE_DD_SEND_FORM);

		map.put(DD_REQUEST_ONLINE, CONSENT_TYPE_DD_REQUEST_ONLINE);
		map.put(DD_REQUEST_PHONE, CONSENT_TYPE_DD_REQUEST_PHONE);
		map.put(DD_REQUEST_FORM, CONSENT_TYPE_DD_REQUEST_FORM);

	}

	@Override
	public String toConsentStatementType(String sharingAgreementID, String channel) {
		LOGGER.debug("Adapting  sharingAgreementID = " + sharingAgreementID + ", channel = " + channel);

		if (sharingAgreementID == null || sharingAgreementID.length() < 3) {
			throw new IllegalArgumentException("sharingAgreementID is null or too short");
		}

		String transactionType = sharingAgreementID.substring(2, 3).toUpperCase();

		String key = transactionType + SEPARATOR + channel.toUpperCase();

		String consentType;

		if (map.containsKey(key)) {
			consentType = map.get(key);
		} else {
			LOGGER.error("Can't find consent Statement Type for input " + key);
			throw new IllegalArgumentException("Can't find consent Statement Type for input " + key);
		}

		return consentType;
	}

	@Override
	public String toSharingAgreementID(String channel, String consentStatementType) {

		return null;
	}

}
