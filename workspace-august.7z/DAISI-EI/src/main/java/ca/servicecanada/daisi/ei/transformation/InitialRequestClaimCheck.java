package ca.servicecanada.daisi.ei.transformation;

import static ca.servicecanada.daisi.ei.DaisiConstants.*;

import java.util.Iterator;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.camel.Exchange;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import org.springframework.context.annotation.Import;
import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransactionStatus;
import ca.servicecanada.daisi.ei.exception.NewRequestCreateException;

//insert a new row into BUSINESS_TRX table
@Component(value = "newRequestClaimCheck")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class InitialRequestClaimCheck {
	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDataServiceClient daisiDataService;

	public void onNewRequest(Exchange exchange) {

		BusinessTransaction trx = (BusinessTransaction) exchange.getIn().getBody();

		LOGGER.debug("processing NewRequestClaimCheck...request for  SIN  " + trx.getSin());
		String eventLogType = null;

		// First things first. Let's handle the case where we receive an ID for
		// a transaction
		// that was already started but is currently in the PeNDing state. If
		// this is, then continue
		// without trying to create an already existing ID.
		BusinessTransaction existingTrx = null;
		existingTrx = daisiDataService.findBusinessTransactionByTransactionID(trx.getBusinessTransactionID());
		if (existingTrx != null) { // OK, we found a match
									// We need to make sure it is Pending and
									// NOT INComplete

			boolean validTransObject = false;
			boolean PendingState = false;
			boolean IncompleteState = false;

			Iterator<?> iter = (existingTrx.getBusinessTransactionStatuses()).iterator();

			while (iter.hasNext()) {
				BusinessTransactionStatus businessTransactionStatus = (BusinessTransactionStatus) iter.next();
				StatusType statusType = businessTransactionStatus.getStatusType();
				String statusCodeAbrvEn = statusType.getStatusCodeAbrvEn();

				if ("INC".equalsIgnoreCase(statusCodeAbrvEn)) {
					IncompleteState = true;
				}
				if ("PND".equalsIgnoreCase(statusCodeAbrvEn)) {
					PendingState = true;
				}
			}

			if (PendingState && !IncompleteState)
				validTransObject = true;

			if (validTransObject) {
				trx = existingTrx; // Assign the found trx to the current trx
				LOGGER.info("Found a pending BusinessTransaction. Moving forward with it.\n");
			} else {
				LOGGER.error("Error while creating a new BusinessTransaction\n Already exists and is INComplete.");
				// Let Camel handle - move to dead letter queue
				// exchange.getIn().setBody(existingTrx);
				throw new NewRequestCreateException();
			}
		} else {
			try {
				trx = daisiDataService.createBusinessTransaction(trx);
			} catch (Exception e) {
				LOGGER.error("Error while creating a new BusinessTransaction\n" + e.getMessage());
				// Let Camel handle - move to dead letter queue

				exchange.getIn().setBody(trx);
				throw new NewRequestCreateException(e);
			}
		}
		exchange.getIn().setHeader("ID", trx.getId());
		exchange.getIn().setHeader(BUSINESS_TRANSACTION_ID, trx.getBusinessTransactionID());

		// If this is CRA pull/push DD we set it to SNT
		String organizationTypeSource = trx.getOrganizationTypeSource().getOrganizationTypeAbrvEn();
		if ("CRA".equalsIgnoreCase(organizationTypeSource)) {
			eventLogType = EVENT_LOG_TYPE_SENT;
		} else {
			eventLogType = EVENT_LOG_TYPE_NEW;
		}
		
		exchange.getIn().setBody(trx);
		exchange.getIn().setHeader(EVENT_LOG_TYPE, eventLogType);
	}
}
