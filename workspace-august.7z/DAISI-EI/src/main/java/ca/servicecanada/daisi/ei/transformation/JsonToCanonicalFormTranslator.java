package ca.servicecanada.daisi.ei.transformation;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

@Component(value = "jsonToDaisiCanonicalFormTranslator")
public class JsonToCanonicalFormTranslator {

	private Logger LOGGER = LogManager.getLogger();
	private ObjectMapper mapper = new ObjectMapper();

	public DaisiExchangeRequest transform(String jsonInput) {

		LOGGER.info("\n"+jsonInput);

		DaisiExchangeRequest request = null;
		try {
			request = mapper.readValue(jsonInput, DaisiExchangeRequest.class);
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return request;
	}

}
