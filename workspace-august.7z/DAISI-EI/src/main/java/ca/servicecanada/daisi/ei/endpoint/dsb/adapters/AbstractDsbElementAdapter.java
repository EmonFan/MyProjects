package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import java.util.HashMap;
import java.util.Map;

public abstract class AbstractDsbElementAdapter implements DsbElementAdapter {

	protected Map<String, String> toDsbMapping = new HashMap<String, String>();

	protected Map<String, String> fromDsbMapping = new HashMap<String, String>();

	protected String dsbElementName;

	@Override
	public String adaptToDsb(String originalValue) {
		if (toDsbMapping.containsKey(originalValue)) {
			return toDsbMapping.get(originalValue);
		} else {
			throw new IllegalArgumentException("Unsuppodrted value for " + dsbElementName + " [" + originalValue + "]");
		}
	}

	@Override
	public String adaptFromDsb(String originalValue) {
		if (fromDsbMapping.containsKey(originalValue)) {
			return fromDsbMapping.get(originalValue);
		} else {
			throw new IllegalArgumentException("Unsuppodrted value for " + dsbElementName + " [" + originalValue + "]");
		}
	}

	public String getDsbElementName() {
		return dsbElementName;
	}

}
