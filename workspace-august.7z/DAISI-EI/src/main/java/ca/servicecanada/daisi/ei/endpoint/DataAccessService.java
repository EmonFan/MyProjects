package ca.servicecanada.daisi.ei.endpoint;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;

/** interface for any Program System to retrieve DD, Address, or Email data */
public interface DataAccessService {

	public void retrieveDirectDeposit(BusinessTransaction data);

	public void updateDirectDeposit(BusinessTransaction data);
}
