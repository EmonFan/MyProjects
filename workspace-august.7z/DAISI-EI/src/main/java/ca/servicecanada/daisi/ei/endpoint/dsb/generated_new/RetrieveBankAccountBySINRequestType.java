
package ca.servicecanada.daisi.ei.endpoint.dsb.generated_new;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RetrieveBankAccountBySINRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrieveBankAccountBySINRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://interoperability.gc.ca/core/1.0}MessageManifest"/>
 *         &lt;element name="DataArea" type="{http://interoperability.gc.ca/entity/citizenprofile/1.0}RetrieveBankAccountBySINRequestDataAreaType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveBankAccountBySINRequestType", propOrder = {
    "messageManifest",
    "dataArea"
})
public class RetrieveBankAccountBySINRequestType implements Serializable {

    @XmlElement(name = "MessageManifest", namespace = "http://interoperability.gc.ca/core/1.0", required = true)
    protected MessageManifestTransactionalCT messageManifest;
    @XmlElement(name = "DataArea", required = true)
    protected RetrieveBankAccountBySINRequestDataAreaType dataArea;

    /**
     * Gets the value of the messageManifest property.
     * 
     * @return
     *     possible object is
     *     {@link MessageManifestTransactionalCT }
     *     
     */
    public MessageManifestTransactionalCT getMessageManifest() {
        return messageManifest;
    }

    /**
     * Sets the value of the messageManifest property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageManifestTransactionalCT }
     *     
     */
    public void setMessageManifest(MessageManifestTransactionalCT value) {
        this.messageManifest = value;
    }

    /**
     * Gets the value of the dataArea property.
     * 
     * @return
     *     possible object is
     *     {@link RetrieveBankAccountBySINRequestDataAreaType }
     *     
     */
    public RetrieveBankAccountBySINRequestDataAreaType getDataArea() {
        return dataArea;
    }

    /**
     * Sets the value of the dataArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link RetrieveBankAccountBySINRequestDataAreaType }
     *     
     */
    public void setDataArea(RetrieveBankAccountBySINRequestDataAreaType value) {
        this.dataArea = value;
    }

}
