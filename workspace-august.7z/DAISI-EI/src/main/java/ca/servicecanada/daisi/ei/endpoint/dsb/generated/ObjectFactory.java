
package ca.servicecanada.daisi.ei.endpoint.dsb.generated;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the ca.servicecanada.daisi.stubs package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AccountNumber_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "AccountNumber");
    private final static QName _BirthDate_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "BirthDate");
    private final static QName _Institution_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "Institution");
    private final static QName _PublishBankAccountBySINResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "PublishBankAccountBySINResponse");
    private final static QName _SetBankAccountBySINRequest_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "SetBankAccountBySINRequest");
    private final static QName _Transit_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "Transit");
    private final static QName _ClientStatus_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "ClientStatus");
    private final static QName _RetrieveClientStatusBySINAsyncResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveClientStatusBySINAsyncResponse");
    private final static QName _Fault_QNAME = new QName("http://interoperability.gc.ca/core/1.0", "Fault");
    private final static QName _PublishBankAccountAppliedBySINResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "PublishBankAccountAppliedBySINResponse");
    private final static QName _PublishBankAccountAppliedBySINRequest_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "PublishBankAccountAppliedBySINRequest");
    private final static QName _RejectedCode_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RejectedCode");
    private final static QName _Surname_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "Surname");
    private final static QName _SocialInsuranceNumber_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "SocialInsuranceNumber");
    private final static QName _PublishBankAccountBySINRequest_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "PublishBankAccountBySINRequest");
    private final static QName _SharingAgreementID_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "SharingAgreementID");
    private final static QName _RetrieveBankAccountBySINResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveBankAccountBySINResponse");
    private final static QName _Channel_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "Channel");
    private final static QName _RetrieveBankAccountBySINFromCPPResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveBankAccountBySINFromCPPResponse");
    private final static QName _MessageManifest_QNAME = new QName("http://interoperability.gc.ca/core/1.0", "MessageManifest");
    private final static QName _RetrieveBankAccountBySINAsyncResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveBankAccountBySINAsyncResponse");
    private final static QName _SetBankAccountBySINAsyncResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "SetBankAccountBySINAsyncResponse");
    private final static QName _SetBankAccountBySINResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "SetBankAccountBySINResponse");
    private final static QName _RetrieveClientStatusBySINRequest_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveClientStatusBySINRequest");
    private final static QName _RetrieveClientStatusBySINResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveClientStatusBySINResponse");
    private final static QName _Program_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "Program");
    private final static QName _RetrieveBankAccountBySINRequest_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "RetrieveBankAccountBySINRequest");
    private final static QName _PublishBankAccountAppliedBySINAsyncResponse_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "PublishBankAccountAppliedBySINAsyncResponse");
    private final static QName _ResultCode_QNAME = new QName("http://interoperability.gc.ca/entity/citizenprofile/1.0", "ResultCode");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: ca.servicecanada.daisi.stubs
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PublishBankAccountBySINRequestDataAreaType }
     * 
     */
    public PublishBankAccountBySINRequestDataAreaType createPublishBankAccountBySINRequestDataAreaType() {
        return new PublishBankAccountBySINRequestDataAreaType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINResponseDataAreaType }
     * 
     */
    public RetrieveBankAccountBySINResponseDataAreaType createRetrieveBankAccountBySINResponseDataAreaType() {
        return new RetrieveBankAccountBySINResponseDataAreaType();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINRequestDataAreaType }
     * 
     */
    public SetBankAccountBySINRequestDataAreaType createSetBankAccountBySINRequestDataAreaType() {
        return new SetBankAccountBySINRequestDataAreaType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINResponseType }
     * 
     */
    public RetrieveBankAccountBySINResponseType createRetrieveBankAccountBySINResponseType() {
        return new RetrieveBankAccountBySINResponseType();
    }

    /**
     * Create an instance of {@link PublishBankAccountBySINRequestType }
     * 
     */
    public PublishBankAccountBySINRequestType createPublishBankAccountBySINRequestType() {
        return new PublishBankAccountBySINRequestType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINAsyncResponseType }
     * 
     */
    public RetrieveBankAccountBySINAsyncResponseType createRetrieveBankAccountBySINAsyncResponseType() {
        return new RetrieveBankAccountBySINAsyncResponseType();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINAsyncResponseType }
     * 
     */
    public SetBankAccountBySINAsyncResponseType createSetBankAccountBySINAsyncResponseType() {
        return new SetBankAccountBySINAsyncResponseType();
    }

    /**
     * Create an instance of {@link PublishBankAccountBySINResponseType }
     * 
     */
    public PublishBankAccountBySINResponseType createPublishBankAccountBySINResponseType() {
        return new PublishBankAccountBySINResponseType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINFromCPPResponseType }
     * 
     */
    public RetrieveBankAccountBySINFromCPPResponseType createRetrieveBankAccountBySINFromCPPResponseType() {
        return new RetrieveBankAccountBySINFromCPPResponseType();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINRequestType }
     * 
     */
    public SetBankAccountBySINRequestType createSetBankAccountBySINRequestType() {
        return new SetBankAccountBySINRequestType();
    }

    /**
     * Create an instance of {@link RetrieveClientStatusBySINAsyncResponseType }
     * 
     */
    public RetrieveClientStatusBySINAsyncResponseType createRetrieveClientStatusBySINAsyncResponseType() {
        return new RetrieveClientStatusBySINAsyncResponseType();
    }

    /**
     * Create an instance of {@link PublishBankAccountAppliedBySINResponseType }
     * 
     */
    public PublishBankAccountAppliedBySINResponseType createPublishBankAccountAppliedBySINResponseType() {
        return new PublishBankAccountAppliedBySINResponseType();
    }

    /**
     * Create an instance of {@link PublishBankAccountAppliedBySINRequestType }
     * 
     */
    public PublishBankAccountAppliedBySINRequestType createPublishBankAccountAppliedBySINRequestType() {
        return new PublishBankAccountAppliedBySINRequestType();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINResponseType }
     * 
     */
    public SetBankAccountBySINResponseType createSetBankAccountBySINResponseType() {
        return new SetBankAccountBySINResponseType();
    }

    /**
     * Create an instance of {@link RetrieveClientStatusBySINRequestType }
     * 
     */
    public RetrieveClientStatusBySINRequestType createRetrieveClientStatusBySINRequestType() {
        return new RetrieveClientStatusBySINRequestType();
    }

    /**
     * Create an instance of {@link RetrieveClientStatusBySINResponseType }
     * 
     */
    public RetrieveClientStatusBySINResponseType createRetrieveClientStatusBySINResponseType() {
        return new RetrieveClientStatusBySINResponseType();
    }

    /**
     * Create an instance of {@link PublishBankAccountAppliedBySINAsyncResponseType }
     * 
     */
    public PublishBankAccountAppliedBySINAsyncResponseType createPublishBankAccountAppliedBySINAsyncResponseType() {
        return new PublishBankAccountAppliedBySINAsyncResponseType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINRequestType }
     * 
     */
    public RetrieveBankAccountBySINRequestType createRetrieveBankAccountBySINRequestType() {
        return new RetrieveBankAccountBySINRequestType();
    }

    /**
     * Create an instance of {@link RetrieveClientStatusBySINRequestDataAreaType }
     * 
     */
    public RetrieveClientStatusBySINRequestDataAreaType createRetrieveClientStatusBySINRequestDataAreaType() {
        return new RetrieveClientStatusBySINRequestDataAreaType();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINRequestDataAreaType }
     * 
     */
    public RetrieveBankAccountBySINRequestDataAreaType createRetrieveBankAccountBySINRequestDataAreaType() {
        return new RetrieveBankAccountBySINRequestDataAreaType();
    }

    /**
     * Create an instance of {@link PublishBankAccountAppliedBySINResponseDataAreaType }
     * 
     */
    public PublishBankAccountAppliedBySINResponseDataAreaType createPublishBankAccountAppliedBySINResponseDataAreaType() {
        return new PublishBankAccountAppliedBySINResponseDataAreaType();
    }

    /**
     * Create an instance of {@link RetrieveClientStatusBySINResponseDataAreaType }
     * 
     */
    public RetrieveClientStatusBySINResponseDataAreaType createRetrieveClientStatusBySINResponseDataAreaType() {
        return new RetrieveClientStatusBySINResponseDataAreaType();
    }

    /**
     * Create an instance of {@link PublishBankAccountAppliedBySINRequestDataAreaType }
     * 
     */
    public PublishBankAccountAppliedBySINRequestDataAreaType createPublishBankAccountAppliedBySINRequestDataAreaType() {
        return new PublishBankAccountAppliedBySINRequestDataAreaType();
    }

    /**
     * Create an instance of {@link PublishBankAccountBySINResponseDataAreaType }
     * 
     */
    public PublishBankAccountBySINResponseDataAreaType createPublishBankAccountBySINResponseDataAreaType() {
        return new PublishBankAccountBySINResponseDataAreaType();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINResponseDataAreaType }
     * 
     */
    public SetBankAccountBySINResponseDataAreaType createSetBankAccountBySINResponseDataAreaType() {
        return new SetBankAccountBySINResponseDataAreaType();
    }

    /**
     * Create an instance of {@link ProcessingStatus }
     * 
     */
    public ProcessingStatus createProcessingStatus() {
        return new ProcessingStatus();
    }

    /**
     * Create an instance of {@link MessageManifestTransactionalCT }
     * 
     */
    public MessageManifestTransactionalCT createMessageManifestTransactionalCT() {
        return new MessageManifestTransactionalCT();
    }

    /**
     * Create an instance of {@link Fault }
     * 
     */
    public Fault createFault() {
        return new Fault();
    }

    /**
     * Create an instance of {@link SystemIDCT }
     * 
     */
    public SystemIDCT createSystemIDCT() {
        return new SystemIDCT();
    }

    /**
     * Create an instance of {@link NotificationIDCT }
     * 
     */
    public NotificationIDCT createNotificationIDCT() {
        return new NotificationIDCT();
    }

    /**
     * Create an instance of {@link LanguageCodeCT }
     * 
     */
    public LanguageCodeCT createLanguageCodeCT() {
        return new LanguageCodeCT();
    }

    /**
     * Create an instance of {@link UUIDCT }
     * 
     */
    public UUIDCT createUUIDCT() {
        return new UUIDCT();
    }

    /**
     * Create an instance of {@link PublishBankAccountBySINRequestDataAreaType.BankAccount }
     * 
     */
    public PublishBankAccountBySINRequestDataAreaType.BankAccount createPublishBankAccountBySINRequestDataAreaTypeBankAccount() {
        return new PublishBankAccountBySINRequestDataAreaType.BankAccount();
    }

    /**
     * Create an instance of {@link RetrieveBankAccountBySINResponseDataAreaType.BankAccount }
     * 
     */
    public RetrieveBankAccountBySINResponseDataAreaType.BankAccount createRetrieveBankAccountBySINResponseDataAreaTypeBankAccount() {
        return new RetrieveBankAccountBySINResponseDataAreaType.BankAccount();
    }

    /**
     * Create an instance of {@link SetBankAccountBySINRequestDataAreaType.BankAccount }
     * 
     */
    public SetBankAccountBySINRequestDataAreaType.BankAccount createSetBankAccountBySINRequestDataAreaTypeBankAccount() {
        return new SetBankAccountBySINRequestDataAreaType.BankAccount();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "AccountNumber")
    public JAXBElement<String> createAccountNumber(String value) {
        return new JAXBElement<String>(_AccountNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "BirthDate")
    public JAXBElement<String> createBirthDate(String value) {
        return new JAXBElement<String>(_BirthDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "Institution")
    public JAXBElement<String> createInstitution(String value) {
        return new JAXBElement<String>(_Institution_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishBankAccountBySINResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "PublishBankAccountBySINResponse")
    public JAXBElement<PublishBankAccountBySINResponseType> createPublishBankAccountBySINResponse(PublishBankAccountBySINResponseType value) {
        return new JAXBElement<PublishBankAccountBySINResponseType>(_PublishBankAccountBySINResponse_QNAME, PublishBankAccountBySINResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetBankAccountBySINRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "SetBankAccountBySINRequest")
    public JAXBElement<SetBankAccountBySINRequestType> createSetBankAccountBySINRequest(SetBankAccountBySINRequestType value) {
        return new JAXBElement<SetBankAccountBySINRequestType>(_SetBankAccountBySINRequest_QNAME, SetBankAccountBySINRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "Transit")
    public JAXBElement<String> createTransit(String value) {
        return new JAXBElement<String>(_Transit_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "ClientStatus")
    public JAXBElement<String> createClientStatus(String value) {
        return new JAXBElement<String>(_ClientStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveClientStatusBySINAsyncResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveClientStatusBySINAsyncResponse")
    public JAXBElement<RetrieveClientStatusBySINAsyncResponseType> createRetrieveClientStatusBySINAsyncResponse(RetrieveClientStatusBySINAsyncResponseType value) {
        return new JAXBElement<RetrieveClientStatusBySINAsyncResponseType>(_RetrieveClientStatusBySINAsyncResponse_QNAME, RetrieveClientStatusBySINAsyncResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fault }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/core/1.0", name = "Fault")
    public JAXBElement<Fault> createFault(Fault value) {
        return new JAXBElement<Fault>(_Fault_QNAME, Fault.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishBankAccountAppliedBySINResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "PublishBankAccountAppliedBySINResponse")
    public JAXBElement<PublishBankAccountAppliedBySINResponseType> createPublishBankAccountAppliedBySINResponse(PublishBankAccountAppliedBySINResponseType value) {
        return new JAXBElement<PublishBankAccountAppliedBySINResponseType>(_PublishBankAccountAppliedBySINResponse_QNAME, PublishBankAccountAppliedBySINResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishBankAccountAppliedBySINRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "PublishBankAccountAppliedBySINRequest")
    public JAXBElement<PublishBankAccountAppliedBySINRequestType> createPublishBankAccountAppliedBySINRequest(PublishBankAccountAppliedBySINRequestType value) {
        return new JAXBElement<PublishBankAccountAppliedBySINRequestType>(_PublishBankAccountAppliedBySINRequest_QNAME, PublishBankAccountAppliedBySINRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RejectedCode")
    public JAXBElement<String> createRejectedCode(String value) {
        return new JAXBElement<String>(_RejectedCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "Surname")
    public JAXBElement<String> createSurname(String value) {
        return new JAXBElement<String>(_Surname_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "SocialInsuranceNumber")
    public JAXBElement<String> createSocialInsuranceNumber(String value) {
        return new JAXBElement<String>(_SocialInsuranceNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishBankAccountBySINRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "PublishBankAccountBySINRequest")
    public JAXBElement<PublishBankAccountBySINRequestType> createPublishBankAccountBySINRequest(PublishBankAccountBySINRequestType value) {
        return new JAXBElement<PublishBankAccountBySINRequestType>(_PublishBankAccountBySINRequest_QNAME, PublishBankAccountBySINRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "SharingAgreementID")
    public JAXBElement<String> createSharingAgreementID(String value) {
        return new JAXBElement<String>(_SharingAgreementID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBankAccountBySINResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveBankAccountBySINResponse")
    public JAXBElement<RetrieveBankAccountBySINResponseType> createRetrieveBankAccountBySINResponse(RetrieveBankAccountBySINResponseType value) {
        return new JAXBElement<RetrieveBankAccountBySINResponseType>(_RetrieveBankAccountBySINResponse_QNAME, RetrieveBankAccountBySINResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "Channel")
    public JAXBElement<String> createChannel(String value) {
        return new JAXBElement<String>(_Channel_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBankAccountBySINFromCPPResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveBankAccountBySINFromCPPResponse")
    public JAXBElement<RetrieveBankAccountBySINFromCPPResponseType> createRetrieveBankAccountBySINFromCPPResponse(RetrieveBankAccountBySINFromCPPResponseType value) {
        return new JAXBElement<RetrieveBankAccountBySINFromCPPResponseType>(_RetrieveBankAccountBySINFromCPPResponse_QNAME, RetrieveBankAccountBySINFromCPPResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageManifestTransactionalCT }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/core/1.0", name = "MessageManifest")
    public JAXBElement<MessageManifestTransactionalCT> createMessageManifest(MessageManifestTransactionalCT value) {
        return new JAXBElement<MessageManifestTransactionalCT>(_MessageManifest_QNAME, MessageManifestTransactionalCT.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBankAccountBySINAsyncResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveBankAccountBySINAsyncResponse")
    public JAXBElement<RetrieveBankAccountBySINAsyncResponseType> createRetrieveBankAccountBySINAsyncResponse(RetrieveBankAccountBySINAsyncResponseType value) {
        return new JAXBElement<RetrieveBankAccountBySINAsyncResponseType>(_RetrieveBankAccountBySINAsyncResponse_QNAME, RetrieveBankAccountBySINAsyncResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetBankAccountBySINAsyncResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "SetBankAccountBySINAsyncResponse")
    public JAXBElement<SetBankAccountBySINAsyncResponseType> createSetBankAccountBySINAsyncResponse(SetBankAccountBySINAsyncResponseType value) {
        return new JAXBElement<SetBankAccountBySINAsyncResponseType>(_SetBankAccountBySINAsyncResponse_QNAME, SetBankAccountBySINAsyncResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetBankAccountBySINResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "SetBankAccountBySINResponse")
    public JAXBElement<SetBankAccountBySINResponseType> createSetBankAccountBySINResponse(SetBankAccountBySINResponseType value) {
        return new JAXBElement<SetBankAccountBySINResponseType>(_SetBankAccountBySINResponse_QNAME, SetBankAccountBySINResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveClientStatusBySINRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveClientStatusBySINRequest")
    public JAXBElement<RetrieveClientStatusBySINRequestType> createRetrieveClientStatusBySINRequest(RetrieveClientStatusBySINRequestType value) {
        return new JAXBElement<RetrieveClientStatusBySINRequestType>(_RetrieveClientStatusBySINRequest_QNAME, RetrieveClientStatusBySINRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveClientStatusBySINResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveClientStatusBySINResponse")
    public JAXBElement<RetrieveClientStatusBySINResponseType> createRetrieveClientStatusBySINResponse(RetrieveClientStatusBySINResponseType value) {
        return new JAXBElement<RetrieveClientStatusBySINResponseType>(_RetrieveClientStatusBySINResponse_QNAME, RetrieveClientStatusBySINResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "Program")
    public JAXBElement<String> createProgram(String value) {
        return new JAXBElement<String>(_Program_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveBankAccountBySINRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "RetrieveBankAccountBySINRequest")
    public JAXBElement<RetrieveBankAccountBySINRequestType> createRetrieveBankAccountBySINRequest(RetrieveBankAccountBySINRequestType value) {
        return new JAXBElement<RetrieveBankAccountBySINRequestType>(_RetrieveBankAccountBySINRequest_QNAME, RetrieveBankAccountBySINRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PublishBankAccountAppliedBySINAsyncResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "PublishBankAccountAppliedBySINAsyncResponse")
    public JAXBElement<PublishBankAccountAppliedBySINAsyncResponseType> createPublishBankAccountAppliedBySINAsyncResponse(PublishBankAccountAppliedBySINAsyncResponseType value) {
        return new JAXBElement<PublishBankAccountAppliedBySINAsyncResponseType>(_PublishBankAccountAppliedBySINAsyncResponse_QNAME, PublishBankAccountAppliedBySINAsyncResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://interoperability.gc.ca/entity/citizenprofile/1.0", name = "ResultCode")
    public JAXBElement<String> createResultCode(String value) {
        return new JAXBElement<String>(_ResultCode_QNAME, String.class, null, value);
    }

}
