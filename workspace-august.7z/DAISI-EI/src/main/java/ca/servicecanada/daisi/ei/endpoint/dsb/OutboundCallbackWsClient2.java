package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.PortInfo;

import org.springframework.stereotype.Component;

import com.sun.xml.ws.client.ClientTransportException;

import ca.servicecanada.daisi.ei.channel.ws.SOAPLoggingHandler;
import ca.servicecanada.daisi.ei.channel.ws.WSAddressingSOAPHandler;
import ca.servicecanada.daisi.ei.channel.ws.WSSecuritySOAPHandler;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.ExecuteCallbackPtt;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.ExecuteCallbackPttBindingQSService;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.RetrieveBankAccountBySINResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.SetBankAccountBySINResponseType;

@Component
public class OutboundCallbackWsClient2 extends DsbWsClient {

	private String SERVICE_NAME = "execute_Callback_pttBindingQSService";
	private ExecuteCallbackPttBindingQSService callbackService;
	private ExecuteCallbackPtt port;

	private String ACTION_RETRIEVE = "RetrieveBankAccountBySINResponse";
	private String ACTION_SET = "SetBankAccountBySINResponse";

	@Resource
	private HttpExceptionFactory httpExceptionFactory;

	// DAISI outgoing - CPP pull from CRA
	public int callbackRetrieveBankAccountBySINAsyncResponse(RetrieveBankAccountBySINResponseType data, String replyTo,
			String relatesTo) {
		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		int responseCode = 0;

		if (requestsEnabled) {
			try {
				initSoapHeaders(replyTo, relatesTo, endpointCallback, ACTION_RETRIEVE);

				port.retrieveBankAccountBySINFromCPPCallback(data);

				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				LOGGER.error(e.getMessage());
				responseContext = ((BindingProvider) port).getResponseContext();
				httpExceptionFactory.throwException(responseContext, e);
			}

			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);

			if (responseCode < 200 || responseCode >= 400) {
				// throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		} else
			LOGGER.debug("DSB Not called. Disabled in configuration file");

		LOGGER.debug("sent!");
		return responseCode;

	}

	// DAISI outgoing - CPP pull from CRA
	public int callbackSetBankAccountBySINAsyncResponse(SetBankAccountBySINResponseType data, final String replyTo,
			final String relatesTo) {
		LOGGER.debug("calling back to " + replyTo);
		Map<String, Object> responseContext;
		int responseCode = 0;

		if (requestsEnabled) {
			try {
				initSoapHeaders(replyTo, relatesTo, endpointCallback, ACTION_SET);

				port.setBankAccountBySINInCPPCallback(data);
				responseContext = ((BindingProvider) port).getResponseContext();
			} catch (ClientTransportException e) {
				LOGGER.error(e.getMessage());
				responseContext = ((BindingProvider) port).getResponseContext();
				httpExceptionFactory.throwException(responseContext, e);

			}

			responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			if (responseCode < 200 || responseCode >= 400) {
				// throw new DaisiSystemException("HTTP code " + responseCode);
				httpExceptionFactory.throwException(responseContext, null);
			}
		} else
			LOGGER.debug("DSB Not called. Disabled in configuration file");

		LOGGER.debug("sent!");
		return responseCode;
	}

	void initSoapHeaders(final String replyTo, final String relatesTo, final String to, final String action) {
		initHandlerResolver(replyTo, relatesTo, endpointCallback, action);
		callbackService.setHandlerResolver(handlerResolver);
		port = callbackService.getExecuteCallbackPttBindingQSPort();
		setDsbEndpontAddress();
		setEndpointAddressingFromReplyTo(replyTo);

	}

	void initHandlerResolver(final String replyTo, final String relatesTo, final String to, final String action) {
		handlerResolver = new HandlerResolver() {
			@SuppressWarnings("rawtypes")
			@Override
			public List<Handler> getHandlerChain(final PortInfo portInfo) {
				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();

				///////////////////////////////////////////////////////////////
				// BE AWARE THAT in the handler-chain.xml /////////////////////
				// the handlers are loaded from the bottom up /////////////////
				// in JAVA, they are loaded as defined in sequence ////////////
				// ensure that logging is loaded first or last.    ////////////
				///////////////////////////////////////////////////////////////
//				handlerChain.add(new SOAPLoggingHandler());
				handlerChain.add(new WSSecuritySOAPHandler(user, password, "en-US;q=1.0, en;q=0.8"));
				handlerChain.add(new WSAddressingSOAPHandler(replyTo, relatesTo, to, action));
				handlerChain.add(new SOAPLoggingHandler());

				return handlerChain;
			}
		};
	}

	@Override
	void initPort() {
		try {
			qName = new QName(NS, SERVICE_NAME);
			callbackService = new ExecuteCallbackPttBindingQSService(SOASERVICE_WSDL_LOCATION, qName);
		} catch (javax.xml.ws.WebServiceException e) {
			throw new RuntimeException(e);
		}
	}

	void setDsbEndpontAddress() {
		BindingProvider bp = ((BindingProvider) port);
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointCallback);

		LOGGER.debug("DSB endpoint set to " + endpointCallback);
	}

	void setEndpointAddressingFromReplyTo(String replyTo) {
		BindingProvider bp = ((BindingProvider) port);
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, replyTo);

	}

	@Override
	URL initWsdl(URL baseUrl) throws MalformedURLException {
		URL url = new URL(baseUrl, wsdlCallback);
		return url;

	}

}
