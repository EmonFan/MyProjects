package ca.servicecanada.daisi.ei.endpoint.dsb;

import static org.apache.http.HttpStatus.SC_GATEWAY_TIMEOUT;
import static org.apache.http.HttpStatus.SC_SERVICE_UNAVAILABLE;

import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.handler.MessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.sun.xml.ws.client.ClientTransportException;

import ca.servicecanada.daisi.ei.exception.DaisiSystemException;
import ca.servicecanada.daisi.ei.exception.ServiceUnavailableException;

@Component
public class HttpExceptionFactory {

	private Logger LOGGER = LogManager.getLogger();

	private Map<Integer, Integer> httpCodeRetryableExceptionMap = new HashMap<Integer, Integer>();

	public HttpExceptionFactory() {
		initExceptionMap();
	}

	public void throwException(Map<String, Object> responseContext, ClientTransportException e) {
		logClientTransportException(responseContext, e);
		int responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);

		if (httpCodeRetryableExceptionMap.containsKey(responseCode)) {
			throw new ServiceUnavailableException(e);
		} else {
			throw new DaisiSystemException(e);
		}
	}

	protected void initExceptionMap() {
		httpCodeRetryableExceptionMap.put(SC_SERVICE_UNAVAILABLE, SC_SERVICE_UNAVAILABLE);
		httpCodeRetryableExceptionMap.put(SC_GATEWAY_TIMEOUT, SC_GATEWAY_TIMEOUT);
		httpCodeRetryableExceptionMap.put(0, 0);
	}

	private void logClientTransportException(Map<String, Object> responseContext, ClientTransportException e) {
		if (e != null) {

			LOGGER.error(e.getMessage());
			int responseCode = (int) responseContext.get(MessageContext.HTTP_RESPONSE_CODE);
			String endpoint = (String) responseContext.get("javax.xml.ws.service.endpoint.address");
			String operation = ((QName) responseContext.get("javax.xml.ws.wsdl.operation")).getLocalPart();
			StringBuilder b = new StringBuilder();
			b.append("Error HTTP ");
			b.append(responseCode);
			b.append(" while sending a SOAP request to endpoint ");
			b.append(endpoint);
			b.append(", operation ");
			b.append(operation);
			String tmp = b.toString();
			LOGGER.error(tmp);
		}

	}

}
