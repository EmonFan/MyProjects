package ca.servicecanada.daisi.ei.endpoint.dsb;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;

import ca.servicecanada.daisi.ei.channel.ws.SOAPLoggingHandler;
import ca.servicecanada.daisi.ei.channel.ws.WSSecuritySOAPHandler;

public abstract class DsbWsClient implements InitializingBean {

	protected Logger LOGGER = LogManager.getLogger();

	protected String NS = "http://interoperability.gc.ca/service/citizenprofile/1.0";

	@Value("${dsb.wsdl}")
	protected String wsdl;
	
	@Value("${dsb.wsdl.callback}")
	protected String wsdlCallback;

	@Value("${dsb.url}")
	protected String endpoint;
	
	@Value("${dsb.url.callback}")
	protected String endpointCallback;


	@Value("${dsb.user}")
	protected String user;
	// "ITRDS_UAT_Adm";

	@Value("${dsb.password}")
	protected String password;
	// "w3w3r3CS";

	@Value("${dsb.requests.enabled}")
	protected boolean requestsEnabled;

	protected URL SOASERVICE_WSDL_LOCATION;

	protected QName qName;// = new QName(NS, SERVICE_NAME);

	protected HandlerResolver handlerResolver;
	
	abstract URL initWsdl(URL baseUrl) throws MalformedURLException;

	void init() {
		URL url = null;
		try {
			URL baseUrl;
			baseUrl = OutboundWsCallsClient.class.getResource(".");
			url = initWsdl(baseUrl) ; //new URL(baseUrl, wsdl);

			System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
			System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump", "true");
			System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
			System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");

		} catch (MalformedURLException e) {
			LOGGER.warn("Failed to create URL for the wsdl Location: " + wsdl);
			LOGGER.error(e.getMessage());
			throw new RuntimeException(e);
		}

		SOASERVICE_WSDL_LOCATION = url;

		handlerResolver = new HandlerResolver() {
			@SuppressWarnings("rawtypes")
			@Override
			public List<Handler> getHandlerChain(final PortInfo portInfo) {
				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();
		        // handlers.add(new SOAPLoggingHandler());
				handlerChain.add(new WSSecuritySOAPHandler(user, password, "en-US;q=1.0, en;q=0.8"));
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}
		};

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		init();
		initPort();
	}

	abstract void initPort();


	public void setEndpoint(String endpoint) {
		LOGGER.debug("\n\n\n setEndpoint " + endpoint);
		this.endpoint = endpoint;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
