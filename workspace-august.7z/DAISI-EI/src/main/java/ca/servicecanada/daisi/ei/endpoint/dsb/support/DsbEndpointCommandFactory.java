package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

@Component
public class DsbEndpointCommandFactory {

	private Logger LOGGER = LogManager.getLogger();

	@Resource(name = "dsbEnpointCommandsMap")
	private Map<String, DsbEndpointCommand> dsbEnpointCommandsMap;

	public DsbEndpointCommand buildDsbEndpointCommand(String dsbModelClassName) {

		DsbEndpointCommand dsbEndpointCommand;

		if (dsbEnpointCommandsMap.containsKey(dsbModelClassName)) {
			dsbEndpointCommand = dsbEnpointCommandsMap.get(dsbModelClassName);
		} else {
			LOGGER.warn("can't find DsbEndpointCommand for dsbModelClassName = " + dsbModelClassName);
			throw new IllegalArgumentException(
					"can't find DsbEndpointCommand for dsbModelClassName = " + dsbModelClassName);
		}

		return dsbEndpointCommand;
	}

}
