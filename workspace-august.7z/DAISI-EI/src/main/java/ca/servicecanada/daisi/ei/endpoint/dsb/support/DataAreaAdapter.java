package ca.servicecanada.daisi.ei.endpoint.dsb.support;

public interface DataAreaAdapter {

	public String toConsentStatementType(String sharingAgreementID, String channel);

	public String toSharingAgreementID(String channel, String consentStatementType);

}
