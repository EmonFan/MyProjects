package ca.servicecanada.daisi.ei.endpoint.itrds;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.model.DirectDepositInfo;

public interface ITRDSClient {

	DirectDepositInfo retrieveDirectDeposit(String sin, String surname, String birthDate, String channelType, String consentCode, String businessTranscationId);
	public void updateDirectDeposit(BusinessTransaction data);

}
