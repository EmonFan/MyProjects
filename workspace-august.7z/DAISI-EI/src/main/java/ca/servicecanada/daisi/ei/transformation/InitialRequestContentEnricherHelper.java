package ca.servicecanada.daisi.ei.transformation;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

public class InitialRequestContentEnricherHelper {

	private Logger LOGGER = LogManager.getLogger();

	// values are set by Spring/Camel context from properties files
	private String actionType;
	private String organizationTypeTarget;
	private String programServiceTypeTarget;
	private String organizationTypeSource;
	private String programServiceTypeSource;
	private String infoType;

	DaisiExchangeRequest initRequest(DaisiExchangeRequest request) {
		request.setActionType(actionType);
		request.setInfoType(infoType);
		request.setOrganizationTypeSource(organizationTypeSource);
		request.setOrganizationTypeTarget(organizationTypeTarget);
		request.setProgramServiceTypeSource(programServiceTypeSource);
		request.setProgramServiceTypeTarget(programServiceTypeTarget);

		return request;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public void setOrganizationTypeTarget(String organizationTypeTarget) {
		this.organizationTypeTarget = organizationTypeTarget;
	}

	public void setProgramServiceTypeTarget(String programServiceTypeTarget) {
		this.programServiceTypeTarget = programServiceTypeTarget;
	}

	public void setOrganizationTypeSource(String organizationTypeSource) {
		this.organizationTypeSource = organizationTypeSource;
	}

	public void setProgramServiceTypeSource(String programServiceTypeSource) {
		this.programServiceTypeSource = programServiceTypeSource;
	}

	public void setInfoType(String infoType) {
		this.infoType = infoType;
	}

}
