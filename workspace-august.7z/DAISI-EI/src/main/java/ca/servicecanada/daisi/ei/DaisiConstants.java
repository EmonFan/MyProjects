package ca.servicecanada.daisi.ei;

public interface DaisiConstants {

	public static final String BUSINESS_TRANSACTION_ID = "BusinessTransactionID";

	public static final String JMS_MESSAGE_ID = "JMSMessageID";

	public static final String HTTP_RESPONSE_CODE = "HTTPResponseCode";

	public static final String EVENT_LOG_TYPE_ERROR = "ERR";
	public static final String EVENT_LOG_TYPE_SENT = "SNT";
	public static final String EVENT_LOG_TYPE_NEW = "NEW";
	public static final String EVENT_LOG_TYPE_INPROGRESS = "INP";
	public static final String EVENT_LOG_TYPE_COMPLETE = "CMP";
	public static final String EVENT_LOG_TYPE_INCOMPLETE = "INC";

	public static final String STATUS_TYPE = "StatusType";
	public static final String STATUS_TYPE_ACCEPTED = "ACP";
	public static final String STATUS_TYPE_REJECTED = "REJ";
	public static final String STATUS_TYPE_PENDING = "PND";
	public static final String STATUS_TYPE_INCOMPLETE = "INC";

	// private final static String ITRDS_STATUS_TYPE_ID_ACCEPTED = "ACP";
	// private final static String ITRDS_STATUS_TYPE_ID_REJECTED = "REJ";

	public static final String ORGANIZATION_TYPE = "OrganizationType";
	
	public static final String ORGANIZATION_TYPE_ESDC = "ESD";
	public static final String ORGANIZATION_TYPE_CRA = "CRA";

	// future enabling
	// public static final String ORGANIZATION_TYPE_EI = "EI";
	// public static final String ORGANIZATION_TYPE_OAS = "OAS";

	public static final String CONSENT_TYPE_DD_SEND_ONLINE = "SON";
	public static final String CONSENT_TYPE_DD_REQUEST_ONLINE = "RON";
	public static final String CONSENT_TYPE_DD_SEND_PHONE = "STL";
	public static final String CONSENT_TYPE_DD_REQUEST_PHONE = "RTL";
	public static final String CONSENT_TYPE_DD_SEND_FORM = "SFO";
	public static final String CONSENT_TYPE_DD_REQUEST_FORM = "UNDEFINED";

	public static final String DSB_CHANNEL_TYPE_ONLINE = "ONLINE";
	public static final String DSB_CHANNEL_TYPE_PHONE = "PHONE";
	public static final String DSB_CHANNEL_TYPE_FORM = "FORM";

	public static final String CHANNEL_TYPE_ONLINE = "ONL";
	public static final String CHANNEL_TYPE_PHONE = "TEL";
	public static final String CHANNEL_TYPE_FORM = "FRM";

	public static final String EVENT_LOG_TYPE = "EventLogType";

	public static final String SOAP_HEADER_REPLY_TO = "ReplyTo";
	public static final String SOAP_HEADER_RELATES_TO = "RelatesTo";

	public static final String FAULT_STRING = "FaultString";
	public static final String FAULT_DETAIL = "Detail";
	public static final String ERROR_FLAG = "ErrorFlag";

	public final static String CPP_RETRIEVE_DD_FROM_CRA = "CPP|REQ|DD|CRA";
	public final static String CPP_SEND_DD_TO_CRA = "CPP|SND|DD|CRA";

	public final static String CPP_CALLBACK_ON_RETRIEVE_DD = "CRA|RCV_REQ|DD|CPP";
	public final static String CPP_CALLBACK_ON_SEND_DD = "CRA|RCV|DD|CPP";

	public static final String CHANNEL = "Channel";
	public static final String SYSTEM_ID = "SystemID";
	public static final String ACCOUNT_NUMBER = "AccountNumber";
	public static final String INSTITUTION = "Institution";
	public static final String BIRTH_DATE = "BirthDate";

	public static final String FAULT = "Fault";

	public static final String REJECT_REASON_CODE = "RejectReasonCode";

	/** Accepted or Rejected */
	public static final String RESULT_CODE = "ResultCode";
	public static final String RESULT_CODE_ACCEPTED = "Accepted";
	public static final String RESULT_CODE_REJECTED = "Rejected";
	public final static String REJECT_REASON_TYPE_OTHER = "OTH";

}
