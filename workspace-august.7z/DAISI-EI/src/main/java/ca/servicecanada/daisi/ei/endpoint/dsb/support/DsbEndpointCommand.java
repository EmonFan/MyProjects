package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;

public interface DsbEndpointCommand {

	/** returns HTTP code */
	int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder);

}
