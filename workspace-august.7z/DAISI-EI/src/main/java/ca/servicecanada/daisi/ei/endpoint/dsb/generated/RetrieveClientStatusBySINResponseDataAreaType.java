
package ca.servicecanada.daisi.ei.endpoint.dsb.generated;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RetrieveClientStatusBySINResponseDataAreaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrieveClientStatusBySINResponseDataAreaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}ClientStatus"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveClientStatusBySINResponseDataAreaType", propOrder = {
    "clientStatus"
})
public class RetrieveClientStatusBySINResponseDataAreaType implements Serializable {

    @XmlElement(name = "ClientStatus", required = true)
    protected String clientStatus;

    /**
     * Gets the value of the clientStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientStatus() {
        return clientStatus;
    }

    /**
     * Sets the value of the clientStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientStatus(String value) {
        this.clientStatus = value;
    }

}
