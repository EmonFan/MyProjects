package ca.servicecanada.daisi.ei.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

public class SpringWebAppInitializer implements WebApplicationInitializer
{

  private final Logger LOGGER = LogManager.getLogger();

  @Override
  public void onStartup(final ServletContext servletContext) throws ServletException
  {
    final AnnotationConfigWebApplicationContext appContext =
        new AnnotationConfigWebApplicationContext();
    appContext.register(ApplicationContextConfig.class);

    // Dispatcher Servlet
    final ServletRegistration.Dynamic dispatcher =
        servletContext.addServlet("SpringDispatcher", new DispatcherServlet(appContext));
    dispatcher.setLoadOnStartup(1);
    dispatcher.addMapping("/");

    dispatcher.setInitParameter("contextClass", appContext.getClass().getName());

    //Let's configure SOAP debugging here. This needs to be done PRIOR to web service instantiation
    System.setProperty("com.sun.xml.ws.transport.http.client.HttpTransportPipe.dump", "true");
    System.setProperty("com.sun.xml.internal.ws.transport.http.client.HttpTransportPipe.dump",
        "true");
    System.setProperty("com.sun.xml.ws.transport.http.HttpAdapter.dump", "true");
    System.setProperty("com.sun.xml.internal.ws.transport.http.HttpAdapter.dump", "true");

    //Already defined in the applicationContext-config.xml file
    //		servletContext.addListener(new ContextLoaderListener(appContext));

    // UTF8 Character Filter.
    //		FilterRegistration.Dynamic fr = servletContext.addFilter("encodingFilter", CharacterEncodingFilter.class);
    //
    //		fr.setInitParameter("encoding", "UTF-8");
    //		fr.setInitParameter("forceEncoding", "true");
    //		fr.addMappingForUrlPatterns(null, true, "/*");		
  }

}