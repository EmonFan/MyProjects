package ca.servicecanada.daisi.ei.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

public class DaisiDateTimeUtils {

	private final static String DATE_FORMAT_YYYYMM = "yyyyMM";

	private final static String DATE_FORMAT_DSB = "yyyy-MM-dd";

	private final static SimpleDateFormat shortFormat = new SimpleDateFormat(DATE_FORMAT_YYYYMM);

	public static String itrdsBirthDateToDsbFormat(String input) {
		String dsbDate = "";
		try {
			Date d = shortFormat.parse(input);
			SimpleDateFormat dsbFormat = new SimpleDateFormat(DATE_FORMAT_DSB);
			dsbDate = dsbFormat.format(d);
		} catch (ParseException e) {
			throw new RuntimeException("Can't parse date [" + input + "] to required format " + DATE_FORMAT_DSB);
		}
		return dsbDate;

	}
	
	/*
     * Converts XMLGregorianCalendar to java.util.Date in Java
     */
    public static Date toDate(XMLGregorianCalendar calendar){
        if(calendar == null) {
            return null;
        }
        return calendar.toGregorianCalendar().getTime();
    }


}
