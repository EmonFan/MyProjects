package ca.servicecanada.daisi.ei.transformation;

import static ca.servicecanada.daisi.ei.DaisiConstants.BUSINESS_TRANSACTION_ID;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.transformation.support.BusinessTransactionStatusBuilder;
import weblogic.utils.StringUtils;

@Component(value = "businessTransactionEnricher")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class BusinessTransactionEnricher implements Processor {

	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDataServiceClient daisiDataService;

	// Failed transaction needs to be updated status
	@Autowired
	private BusinessTransactionStatusBuilder trxStatusBuilder;

	@Override
	public void process(Exchange exchange) throws Exception {
		String transId = (String) exchange.getIn().getHeader(BUSINESS_TRANSACTION_ID);
		String statusType = (String) exchange.getIn().getHeader(STATUS_TYPE);
		String rejectReasonCode = (String) exchange.getIn().getHeader(REJECT_REASON_CODE);

		LOGGER.debug("looking up for BusinessTransaction= " + transId);
		BusinessTransaction trx = daisiDataService.findBusinessTransactionByTransactionID(transId);

		trx = updateStatusType(trx, statusType, rejectReasonCode);
		trx = updateDDInfo(trx, exchange);
		
		exchange.getIn().setBody(trx);
	}

	private BusinessTransaction updateStatusType(BusinessTransaction trx, String statusType, String rejectReasonCode) {
		if (!StringUtils.isEmptyString(statusType)) {
			if (rejectReasonCode != null && !rejectReasonCode.isEmpty()){
				return trxStatusBuilder.buildBusinessTransactionStatus(trx, statusType, rejectReasonCode);
			} else {
				return trxStatusBuilder.buildBusinessTransactionStatus(trx, statusType);
			}
			
		} else {
			// do nothing
			return trx;
		}
	}

	private BusinessTransaction updateDDInfo(BusinessTransaction _trx, Exchange exchange) {		
		String accountNumber = null;
		String institutionNumber = null;
		String transitNumber = null;
		
		DDBusinessTransaction trx = (DDBusinessTransaction) _trx;
		
		if ((String) exchange.getIn().getHeader("accountNumber") != null){
			accountNumber = (String) exchange.getIn().getHeader("accountNumber");
			institutionNumber = (String) exchange.getIn().getHeader("institution");
			transitNumber = (String) exchange.getIn().getHeader("transitNumber");
		} else {
			accountNumber = ((DDBusinessTransaction) _trx).getAccountNumber();
			institutionNumber = ((DDBusinessTransaction) _trx).getInstitutionNumber();
			transitNumber = ((DDBusinessTransaction) _trx).getTransitNumber();
		}
		
		trx.setAccountNumber(accountNumber);
		trx.setInstitutionNumber(institutionNumber);
		trx.setTransitNumber(transitNumber);
		return trx;
	}

}
