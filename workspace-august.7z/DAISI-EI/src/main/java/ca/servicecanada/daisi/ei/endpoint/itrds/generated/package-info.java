@javax.xml.bind.annotation.XmlSchema(namespace = "http://isp.sdc.gc.ca/ws/cs/jaxws/impl")
package ca.servicecanada.daisi.ei.endpoint.itrds.generated;
