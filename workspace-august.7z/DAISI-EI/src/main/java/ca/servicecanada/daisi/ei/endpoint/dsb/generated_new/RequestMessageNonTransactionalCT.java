
package ca.servicecanada.daisi.ei.endpoint.dsb.generated_new;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RequestMessage-NonTransactional-CT complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RequestMessage-NonTransactional-CT">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RequestMessageManifest" type="{http://interoperability.gc.ca/core/1.0}MessageManifest-NonTransactional-CT"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestMessage-NonTransactional-CT", namespace = "http://interoperability.gc.ca/core/1.0", propOrder = {
    "requestMessageManifest"
})
public class RequestMessageNonTransactionalCT implements Serializable {

    @XmlElement(name = "RequestMessageManifest", required = true)
    protected MessageManifestNonTransactionalCT requestMessageManifest;

    /**
     * Gets the value of the requestMessageManifest property.
     * 
     * @return
     *     possible object is
     *     {@link MessageManifestNonTransactionalCT }
     *     
     */
    public MessageManifestNonTransactionalCT getRequestMessageManifest() {
        return requestMessageManifest;
    }

    /**
     * Sets the value of the requestMessageManifest property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageManifestNonTransactionalCT }
     *     
     */
    public void setRequestMessageManifest(MessageManifestNonTransactionalCT value) {
        this.requestMessageManifest = value;
    }

}
