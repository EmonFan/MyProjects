package ca.servicecanada.daisi.ei.system;

import static ca.servicecanada.daisi.ei.DaisiConstants.*;

import java.util.Date;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.ref.EventLogType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.EventLog;
import ca.gc.servicecanada.daisi.domain.trx.TechnicalTransaction;
import ca.servicecanada.daisi.ei.transformation.DaisiDataServiceClient;

@Component(value = "eventLogWireTapProcessor")
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class EventLogWireTapProcessor implements Processor {

	private Logger LOGGER = LogManager.getLogger();

	@Value("${db.audit.user.created}")
	private String userCreated;

	@Value("${db.audit.system.created}")
	private String systemCreated;

	@Resource
	private DaisiDataServiceClient daisiDataServiceClient;

	public void process(Exchange exchange) throws Exception {
		BusinessTransaction trx = null;
		String eventLogType = (String) exchange.getIn().getHeader(EVENT_LOG_TYPE);

		if (eventLogType == null) {
			LOGGER.debug("event log Type is null!  " + eventLogType);
		} else {
			String systemID = (String) exchange.getIn().getHeader("SystemID");

			if ("CMP".equalsIgnoreCase(eventLogType) && "CRA".equalsIgnoreCase(systemID)) {
				String businessTransactionID = (String) exchange.getIn().getHeader(BUSINESS_TRANSACTION_ID);
				trx = daisiDataServiceClient.findBusinessTransactionByTransactionID(businessTransactionID);
			} else if (("SNT".equalsIgnoreCase(eventLogType) && !"CRA".equalsIgnoreCase(systemID))){
				String businessTransactionID = (String) exchange.getIn().getHeader(BUSINESS_TRANSACTION_ID);
				trx = daisiDataServiceClient.findBusinessTransactionByTransactionID(businessTransactionID);
			} else {
				trx = (BusinessTransaction) exchange.getIn().getBody();
			}
		}

		createEventLogRecord(trx, eventLogType);
	}

	void createEventLogRecord(BusinessTransaction trx, String eventLogTypeCode) {
		EventLog event = new EventLog();
		Date dateCreated = new Date();

		event.setDateCreated(dateCreated);

		Date eventDate = null;

		if (eventLogTypeCode.equalsIgnoreCase(EVENT_LOG_TYPE_SENT) && trx.getBusinessTransactionDate() != null) {
			eventDate = trx.getBusinessTransactionDate();
		} else {
			eventDate = new Date();
		}

		event.setEventDate(eventDate);

		EventLogType eventLogType = eventLogTypeFactory(eventLogTypeCode);
		event.setEventLogType(eventLogType);

		event.setSystemCreated(systemCreated);
		event.setUserCreated(userCreated);

		TechnicalTransaction technicalTransaction = null;

		// FIXME: case when we have >1 technical transactions
		if (trx.getTechnicalTransactions() != null && trx.getTechnicalTransactions().size() > 0) {
			technicalTransaction = trx.getTechnicalTransactions().get(0);
		} else {
			LOGGER.error(
					"No TechnicalTransactions are found for BusinessTransactionID = " + trx.getBusinessTransactionID());
			technicalTransaction = null;
		}
		event.setTechnicalTransaction(technicalTransaction);
		daisiDataServiceClient.createEventLog(event);
	}

	private EventLogType eventLogTypeFactory(String eventLogTypeAbbr) {
		// LOGGER.debug("findEventLogTypeByAbrv: " + eventLogTypeAbbr);
		EventLogType eventLogType = daisiDataServiceClient.findEventLogTypeByAbrv(eventLogTypeAbbr);
		return eventLogType;
	}
}
