package ca.servicecanada.daisi.ei.endpoint.itrds.support;

import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.padWithZeros4Institution;
import static ca.servicecanada.daisi.ei.util.DaisiStringUtils.padWithZeros4Transit;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullRequest;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullServiceResponse;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiPushDDRequest;
import ca.servicecanada.daisi.ei.model.DirectDepositInfo;
import ca.servicecanada.daisi.ei.util.EiUtils;

public class DaisiITRDSMapper {

	private Logger LOGGER = LogManager.getLogger();

	private static DateFormat fromFormat = new SimpleDateFormat("dd-MM-yyyy");

	public static DaisiDDInfoPullRequest buildDaisiDDInfoPullRequest(String sin, String surname, String birthDate, String channelType, String consentCode, String businessTranscationId) {
		DaisiDDInfoPullRequest req = new DaisiDDInfoPullRequest();
		req.setSin(sin);
		req.setSurname(surname);
		req.setDOB(birthDate);
		req.setChannelType(channelType);
		req.setConsentCode(consentCode);
		req.setBusinessTranscationId(businessTranscationId);

		return req;
	}

	public static DirectDepositInfo mapDirectDepositInfo(DaisiDDInfoPullServiceResponse ddInfoResponse) {
		DirectDepositInfo directDepositInfo = new DirectDepositInfo();
		directDepositInfo.setAccountNumber(ddInfoResponse.getAccountNumber());
		directDepositInfo.setInstitutionNumber(ddInfoResponse.getInstitutionNumber());
		directDepositInfo.setTransitNumber(ddInfoResponse.getTransitNumber());
		return directDepositInfo;
	}

	public static DaisiPushDDRequest buildDaisiSetDDFromDAISIRequest(BusinessTransaction trx) {
		
		//FIXME: use factory 
		DDBusinessTransaction data  =(DDBusinessTransaction )trx;

		DaisiPushDDRequest req = new DaisiPushDDRequest();

		req.setSin(data.getSin());
		req.setSurname(data.getSurname());
		req.setDob(data.getBirthDate());
		req.setConsentCode(data.getConsentCode());
		req.setChannelType(data.getChannelType().getChannelTypeAbrvEn());
		//req.setConsentDate(fromFormat.format(data.getConsentStatementType().getDateCreated()));
		req.setBusinessTransactionId(data.getBusinessTransactionID());

		String institutionNumber = padWithZeros4Institution(data.getInstitutionNumber());
		String TransitNumber = padWithZeros4Transit(data.getTransitNumber());
		req.setInstitution(institutionNumber);
		req.setTransitNumber(TransitNumber);
		req.setAccountNumber(data.getAccountNumber());	
		
		return req;
	}

}
