
package ca.servicecanada.daisi.ei.endpoint.dsb.generated_new;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RetrieveBankAccountBySINRequestDataAreaType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RetrieveBankAccountBySINRequestDataAreaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}SocialInsuranceNumber"/>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}BirthDate" minOccurs="0"/>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Surname" minOccurs="0"/>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Channel" minOccurs="0"/>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}Program" minOccurs="0"/>
 *         &lt;element ref="{http://interoperability.gc.ca/entity/citizenprofile/1.0}SharingAgreementID" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RetrieveBankAccountBySINRequestDataAreaType", propOrder = {
    "socialInsuranceNumber",
    "birthDate",
    "surname",
    "channel",
    "program",
    "sharingAgreementID"
})
public class RetrieveBankAccountBySINRequestDataAreaType implements Serializable {

    @XmlElement(name = "SocialInsuranceNumber", required = true)
    protected String socialInsuranceNumber;
    @XmlElement(name = "BirthDate")
    protected String birthDate;
    @XmlElement(name = "Surname")
    protected String surname;
    @XmlElement(name = "Channel")
    protected String channel;
    @XmlElement(name = "Program")
    protected String program;
    @XmlElement(name = "SharingAgreementID")
    protected String sharingAgreementID;

    /**
     * Gets the value of the socialInsuranceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSocialInsuranceNumber() {
        return socialInsuranceNumber;
    }

    /**
     * Sets the value of the socialInsuranceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSocialInsuranceNumber(String value) {
        this.socialInsuranceNumber = value;
    }

    /**
     * Gets the value of the birthDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBirthDate() {
        return birthDate;
    }

    /**
     * Sets the value of the birthDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBirthDate(String value) {
        this.birthDate = value;
    }

    /**
     * Gets the value of the surname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the value of the surname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSurname(String value) {
        this.surname = value;
    }

    /**
     * Gets the value of the channel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Sets the value of the channel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Gets the value of the program property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProgram() {
        return program;
    }

    /**
     * Sets the value of the program property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProgram(String value) {
        this.program = value;
    }

    /**
     * Gets the value of the sharingAgreementID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSharingAgreementID() {
        return sharingAgreementID;
    }

    /**
     * Sets the value of the sharingAgreementID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSharingAgreementID(String value) {
        this.sharingAgreementID = value;
    }

}
