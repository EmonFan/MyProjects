package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.FAULT;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_REJECTED;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.Fault;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.MessageManifestTransactionalCT;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.ProcessingStatus;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINAsyncResponseType;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated.SetBankAccountBySINResponseDataAreaType;

/**
 * 
 * "CRA push to CPP", call back part (DAISI sends a response back to DSB
 * 
 * a) all is good - returns ProcessingStatus.resultCode = "Accepted"; b) all is
 * good by ITRDS rejected - returns ProcessingStatus.resultCode = "Rejected";
 * 
 * c) system failures / errors - returns Fault = "Rejected";
 * 
 * @XmlElement(name = "DataArea") protected
 *                  SetBankAccountBySINResponseDataAreaType dataArea;
 * @XmlElement(name = "Fault") protected Fault fault;
 * 
 * 
 */

@Component(value = "setBankAccountBySINAsyncResponseTranslator")
public class SetBankAccountBySINAsyncResponseTranslator extends AbstractDaisiDomainToDsbModelTranslator {

	private Logger LOGGER = LogManager.getLogger();

	@Override
	public DsbModelPlaceholder translate(BusinessTransaction trx, Map<String, String> context) {
		LOGGER.debug("to DSB for ID = " + trx.getBusinessTransactionID());

		SetBankAccountBySINAsyncResponseType dsbData = new SetBankAccountBySINAsyncResponseType();

		MessageManifestTransactionalCT mf = buildManifest(trx);
		mf = setTestIndicatr(mf);
		dsbData.setMessageManifest(mf);

		// TODO: move to parent
		if (context.containsKey(FAULT)) {
			String faultstring = context.get(FAULT);
			Fault fault = buildFault(faultstring);
			dsbData.setFault(fault);
		} else {
			SetBankAccountBySINResponseDataAreaType dataArea = buildDataArea(trx, context);
			dsbData.setDataArea(dataArea);
		}

		DsbModelPlaceholder placeholder = new DsbModelPlaceholder();
		placeholder.setDsb(dsbData);

		return placeholder;
	}

	SetBankAccountBySINResponseDataAreaType buildDataArea(BusinessTransaction trx, Map<String, String> context) {
		SetBankAccountBySINResponseDataAreaType d = new SetBankAccountBySINResponseDataAreaType();

		if (context.containsKey(REJECT_REASON_CODE)) {
			ProcessingStatus processingStatus = new ProcessingStatus();
			String rejectedCode = context.get(REJECT_REASON_CODE);
			processingStatus.setRejectedCode(rejectedCode);

			// <ResultCode>Rejected</ResultCode
			processingStatus.setResultCode(RESULT_CODE_REJECTED);
			d.setProcessingStatus(processingStatus);
		} else if (context.containsKey(RESULT_CODE)) {
			String resultCode = context.get(RESULT_CODE);
			ProcessingStatus processingStatus = new ProcessingStatus();
			processingStatus.setResultCode(resultCode);
			d.setProcessingStatus(processingStatus);

		} else {
			// shouldn'r be here
		}
		return d;
	}

}
