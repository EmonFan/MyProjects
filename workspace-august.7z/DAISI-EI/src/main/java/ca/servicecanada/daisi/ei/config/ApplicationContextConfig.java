package ca.servicecanada.daisi.ei.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
public class ApplicationContextConfig
{

  @Bean(name = "viewResolver")
  public InternalResourceViewResolver getViewResolver()

  {
    final InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
    System.out.println("Create Bean viewResolver");

    viewResolver.setPrefix("");
    viewResolver.setSuffix(".jsp");

    return viewResolver;
  }

}