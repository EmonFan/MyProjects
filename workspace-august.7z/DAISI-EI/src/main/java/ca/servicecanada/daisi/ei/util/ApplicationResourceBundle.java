package ca.servicecanada.daisi.ei.util;

import ca.gc.hrdc.isp.common.env.SecurityContext;
import ca.gc.hrdc.isp.common.util.ExtendedResourceBundle;
import ca.gc.hrdc.isp.common.util.OverridingResourceBundle;

import java.util.Locale;

/**
 * This is a sample of a convenience class defined for an application and used
 * to construct {@link OverridingResourceBundle} objects. This class implements
 * three versions of the getBundleAndOverrides static method. When a version of
 * this class is created for an application only the name of the package for
 * this class and the {@link #applicationName} needs to be customized for the
 * application. It is recommended that the version of this class created for an
 * application belong to one of the application packages.
 * <p>
 * The OverridingResourceBundle class can be used directly, but this would
 * require that the application name be provided in each call to the constructor
 * of OverridingResourceBundle.
 */
public class ApplicationResourceBundle {

	/**
	 * At least one of the constructors in {@link OverridingResourceBundle} must
	 * be provided by this class; this constructor is not functional, see
	 * {@link OverridingResourceBundle#OverridingResourceBundle()}
	 */
	private ApplicationResourceBundle() {
		super();
	}

	/**
	 * Holds the name of the application that will be used to distinguish
	 * overriding properties from one application to another. This name should
	 * not contain spaces or punctuation. Normally the application name is upper
	 * case. Override parameter names are case sensitive.
	 */
	private static String applicationName = "DAISI";

	/**
	 * returns a resource bundle with values from the bundle supplied by the
	 * properties file in the application archive file and with overriding
	 * values applied. See {@link OverridingResourceBundle} for a discussion
	 * about the override stategy. The default Locale and the classloader of the
	 * object that made this method are passed to the constructor.
	 */
	public static ExtendedResourceBundle getBundleAndOverrides(final String bundleName) {
		final Class[] classes = (new SecurityContext()).getClassStack();
		return OverridingResourceBundle.getCachedInstance(ApplicationResourceBundle.applicationName, bundleName,
				Locale.getDefault(), classes[2].getClassLoader());
	}

	/**
	 * returns a resource bundle with values from the bundle supplied by the
	 * properties file in the application archive file and with overriding
	 * values applied. See {@link OverridingResourceBundle} for a discussion
	 * about the override stategy. The classloader of the object that made this
	 * method are passed to the constructor.
	 */
	public static ExtendedResourceBundle getBundleAndOverrides(final String bundleName, final Locale locale) {
		final Class[] classes = (new SecurityContext()).getClassStack();
		return OverridingResourceBundle.getCachedInstance(ApplicationResourceBundle.applicationName, bundleName, locale,
				classes[2].getClassLoader());
	}

	/**
	 * returns a resource bundle with values from the bundle supplied by the
	 * properties file in the application archive file and with overriding
	 * values applied. See {@link OverridingResourceBundle} for a discussion
	 * about the override stategy.
	 */
	public static ExtendedResourceBundle getBundleAndOverrides(final String bundleName, final Locale locale,
			final ClassLoader classLoader) {
		return OverridingResourceBundle.getCachedInstance(ApplicationResourceBundle.applicationName, bundleName, locale,
				classLoader);
	}

}
