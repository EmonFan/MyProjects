package ca.servicecanada.daisi.ei.exception;

public class DataNotAvailableException extends RuntimeException {

	public DataNotAvailableException(String e) {
		super(e);
	}

	public DataNotAvailableException() {
		super();
	}

}
