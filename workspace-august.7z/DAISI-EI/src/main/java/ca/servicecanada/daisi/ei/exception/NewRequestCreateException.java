package ca.servicecanada.daisi.ei.exception;

public class NewRequestCreateException extends RuntimeException {
	public NewRequestCreateException() {
		super();
	}

	public NewRequestCreateException(String e) {
		super(e);
	}

	public NewRequestCreateException(Exception e) {
		super(e);
	}

}
