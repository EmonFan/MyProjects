package ca.servicecanada.daisi.ei.channel.ws;

import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WSAddressingSOAPHandler implements SOAPHandler<SOAPMessageContext> {

	private Logger LOGGER = LogManager.getLogger(getClass());
	// xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing
	//changed on 17/09 as per Damion
	public static final String WS_ADDRESSING_NAMESPACE = "http://www.w3.org/2005/08/addressing";

	public static final String WSA_PREFIX = "wsa";

	private String replyTo;
	private String relatesTo;
	private String to;
	private String action;

	public WSAddressingSOAPHandler(String replyTo, String relatesTo, String to, String action) {
		LOGGER.debug("$$$$$$$$$$$$$$$$$$$$$$$ constructor in addressing SOAP Handler $$$$$$$$$$$$$$$$$$$$$ replyTo = "
				+ replyTo);

		this.replyTo = replyTo;
		this.relatesTo = relatesTo;
		this.to = to;
		this.action = action;

	}

	@Override
	public boolean handleMessage(SOAPMessageContext context) {
		LOGGER.debug("$$$$$$$$$$$$$$$$$$$$$$$ in addressing SOAP Handler $$$$$$$$$$$$$$$$$$$$$");
		if ((Boolean) context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)) {
			// get the message
			SOAPMessage message = context.getMessage();

			try {
				// get the message header
				SOAPEnvelope envelope = message.getSOAPPart().getEnvelope();
				SOAPHeader header = envelope.getHeader();
				if (header == null) {
					header = envelope.addHeader();
				}

				createAddressingHeader(header);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
			}

		}
		return true;
	}

	SOAPElement createAddressingHeader(SOAPElement header) throws Exception {


		// SOAPElement addressingHeader = factory.createElement("Addressing",
		// WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
		try {
			SOAPFactory factory = SOAPFactory.newInstance();

			SOAPElement relatesToElement = factory.createElement("RelatesTo", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			relatesToElement.addTextNode(relatesTo);
			header.addChildElement(relatesToElement);

			SOAPElement toElement = factory.createElement("To", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			toElement.addTextNode(to);
			header.addChildElement(toElement);

			// <wsa:ReplyTo>
			// <wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address>
			// </wsa:ReplyTo>
			SOAPElement replyToElement = factory.createElement("ReplyTo", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			SOAPElement addressElement = factory.createElement("Address", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			addressElement.addTextNode(replyTo);
			replyToElement.addChildElement(addressElement);
			header.addChildElement(replyToElement);

			// <wsa:FaultTo>
			// <wsa:Address>http://www.w3.org/2005/08/addressing/anonymous</wsa:Address>
			// </wsa:FaultTo>

			SOAPElement faultToElement = factory.createElement("FaultTo", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			SOAPElement faultToAddressElement = factory.createElement("Address", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			faultToAddressElement.addTextNode(replyTo);
			faultToElement.addChildElement(faultToAddressElement);
			header.addChildElement(faultToElement);

			SOAPElement messageIDElement = factory.createElement("MessageID", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
			messageIDElement.addTextNode(relatesTo);
			header.addChildElement(messageIDElement);

//			SOAPElement actionElement = factory.createElement("Action", WSA_PREFIX, WS_ADDRESSING_NAMESPACE);
//			actionElement.addTextNode(action);
//			header.addChildElement(actionElement);

			return header;

		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
		return header;

	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void close(MessageContext context) {
		// TODO Auto-generated method stub

	}

	@Override
	public Set<QName> getHeaders() {
		// TODO Auto-generated method stub
		return null;
	}

}
