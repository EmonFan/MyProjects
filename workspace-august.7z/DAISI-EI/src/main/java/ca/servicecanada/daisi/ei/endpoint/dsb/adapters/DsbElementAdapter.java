package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

public interface DsbElementAdapter {

	String adaptToDsb(String originalValue);

	String adaptFromDsb(String originalValue);

}
