package ca.servicecanada.daisi.ei.endpoint.dsb;

import static ca.servicecanada.daisi.ei.DaisiConstants.*;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.support.DsbEndpointCommand;
import ca.servicecanada.daisi.ei.endpoint.dsb.support.DsbEndpointCommandFactory;

@Component
public class DSBOutboundProcessorHelper {

	@Resource
	private DsbEndpointCommandFactory dsbEndpointFactory;

	public String process(DsbModelPlaceholder dsbModelPlaceholder) throws Exception {
		
		String enentLogType = null;
		
		String dsbModelClassName = dsbModelPlaceholder.getDsb().getClass().getName();
		DsbEndpointCommand dsbEndpointCommand = dsbEndpointFactory.buildDsbEndpointCommand(dsbModelClassName);

		int httpResponseCode = dsbEndpointCommand.executeDsbCall(dsbModelPlaceholder);
		
		
		if ("RetrieveBankAccountBySINResponseType".equalsIgnoreCase(StringUtils.substringAfterLast(dsbModelClassName, "."))
				||"SetBankAccountBySINResponseType".equalsIgnoreCase(StringUtils.substringAfterLast(dsbModelClassName, "."))){
			
			if (httpResponseCode == 202){
				enentLogType = EVENT_LOG_TYPE_COMPLETE;
			}
			
			if (httpResponseCode < 200 || httpResponseCode >= 400){
				enentLogType = EVENT_LOG_TYPE_ERROR;
			}
			
		} else {
			enentLogType = EVENT_LOG_TYPE_SENT;
		}

		return enentLogType;
	}

}
