package ca.servicecanada.daisi.ei.exception;

import java.io.Serializable;

public interface DaisiRetryableException extends Serializable {
	
}
