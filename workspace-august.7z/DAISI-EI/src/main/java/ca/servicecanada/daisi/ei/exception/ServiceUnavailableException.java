package ca.servicecanada.daisi.ei.exception;

public class ServiceUnavailableException extends RuntimeException implements DaisiRetryableException {

	public ServiceUnavailableException() {
		super();
	}

	public ServiceUnavailableException(String err) {
		super(err);
	}

	public ServiceUnavailableException(Exception e) {
		super(e);
	}

}
