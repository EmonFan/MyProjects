package ca.servicecanada.daisi.ei.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class EiUtils {

	private static final DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	private static final String FIRST_DAY = "01";
	private static final String DASH= "-";

	public static XMLGregorianCalendar toXMLGregorianCalendar(String stringDate) {
		Date date;
		try {
			date = df.parse(stringDate);
		} catch (ParseException e1) {
			throw new RuntimeException(e1.getMessage());
		}
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		XMLGregorianCalendar dob;
		try {
			dob = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		return dob;
	}

	public static XMLGregorianCalendar toXMLGregorianCalendarTruncated(String stringDate) {

		String year = stringDate.substring(0, 4);
		String month = stringDate.substring(4, 6);
		StringBuilder b = new StringBuilder();
		b.append(FIRST_DAY);
		b.append(DASH);
		b.append(month);
		b.append(DASH);
		b.append(year);
		
		
		
		
		String tmp = b.toString();
		return toXMLGregorianCalendar(tmp);
	}

	public static XMLGregorianCalendar toXMLGregorianCalendar(Date date) {

		// TODO: move to util
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		XMLGregorianCalendar xmlDate = null;

		try {
			xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
		}
		return xmlDate;
	}

	public static String toDsbDateFormat(String daisiStringDate) {

		DateFormat fromFormat = new SimpleDateFormat("dd-MM-yyyy");
		fromFormat.setLenient(false);

		DateFormat toFormat = new SimpleDateFormat("yyyy-MM-dd");
		toFormat.setLenient(false);

		Date date = null;
		try {
			date = fromFormat.parse(daisiStringDate);
		} catch (ParseException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}

		return toFormat.format(date);

	}

	public static String cleanUpMessageID(String jmsMessageID) {
		//Sanitize the string on the way in.
		//activeMQ messageID has the following format
		//ID:N30003818-57819-1507061155203-18:3:1:1:1 LOCAL
		//ID:mlwb1827.intra.dev-40515-1507143342254-18:1:1 SERVER
		//So it looks like we have servername-xxxxx-xxxxxxxxxxxxx-xx:x:x:x
		//Let's look for the first dash and strip it and everything before it out.
		//See if the message ID contains "ID:", if it does not, that means we have already cleaned up the ID.
		//Don't do it again.
		if (jmsMessageID.contains("ID:"))
			return jmsMessageID = jmsMessageID.substring(jmsMessageID.indexOf('-')+1).replaceAll(":", "");
		else
			return jmsMessageID;
	}

}
