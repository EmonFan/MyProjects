package ca.servicecanada.daisi.ei.endpoint.itrds;

import ca.servicecanada.daisi.ei.DaisiConstants;
import static ca.servicecanada.daisi.ei.endpoint.itrds.support.DaisiITRDSMapper.buildDaisiDDInfoPullRequest;
import static ca.servicecanada.daisi.ei.endpoint.itrds.support.DaisiITRDSMapper.buildDaisiSetDDFromDAISIRequest;
import static ca.servicecanada.daisi.ei.endpoint.itrds.support.DaisiITRDSMapper.mapDirectDepositInfo;
import static org.springframework.util.StringUtils.isEmpty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.sun.xml.ws.client.ClientTransportException;

import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.channel.ws.SOAPLoggingHandler;
import ca.servicecanada.daisi.ei.endpoint.dsb.HttpExceptionFactory;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.CsSystemException_Exception;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullRequest;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullService;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullServiceResponse;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiDDInfoPullService_Service;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiPushDDRequest;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiPushDDService;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiPushDDServiceResponse;
import ca.servicecanada.daisi.ei.endpoint.itrds.generated.DaisiPushDDService_Service;
import ca.servicecanada.daisi.ei.exception.DataNotAvailableException;
import ca.servicecanada.daisi.ei.exception.DataSharingRejectException;
import ca.servicecanada.daisi.ei.model.DirectDepositInfo;
import ca.servicecanada.daisi.ei.transformation.DaisiDataServiceClient;

@Component
public class ITRDSSoapClient implements ITRDSClient, InitializingBean {
	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private HttpExceptionFactory httpExceptionFactory;
	
	@Resource
	private DaisiDataServiceClient daisiDataService;

	@Value("${itrds.ws.pull-dd.url}")
	protected String endpointPullDD;

	@Value("${itrds.ws.push-dd.url}")
	protected String endpointPushDD;

	@Value("${itrds.ws.user}")
	protected String user;

	@Value("${itrds.ws.password}")
	protected String password;

	@Value("${itrds.requests.enabled}")
	protected boolean requestsEnabled;
	
	protected HandlerResolver portPushDDHandlerResolver;
	protected HandlerResolver portPullDDHandlerResolver;

	private DaisiPushDDService portPushDD;
	private DaisiDDInfoPullService portPullDD;

	@Override
	public DirectDepositInfo retrieveDirectDeposit(String sin, String surname, String birthDate, String channelType, String consentCode, String businessTranscationId) {

		DaisiDDInfoPullRequest req = buildDaisiDDInfoPullRequest(sin, surname, birthDate, channelType, consentCode, businessTranscationId);

		DaisiDDInfoPullServiceResponse ddInfoResponse = null;
		Map<String, Object> responseContext;
		
		if (requestsEnabled) {
			try {
				ddInfoResponse = portPullDD.getDaisiDDInfo(req);
				responseContext = ((BindingProvider) portPullDD).getResponseContext();
			} catch (ClientTransportException x) {
				LOGGER.error(x.getMessage());
				responseContext = ((BindingProvider) portPullDD).getResponseContext();
				httpExceptionFactory.throwException(responseContext, x);
			} catch (CsSystemException_Exception e) {
				LOGGER.error(e.getMessage());
				throw new RuntimeException(e.getMessage());
			}
			validateDDInfo(ddInfoResponse);
		}
		else
			LOGGER.debug("ITRDS Not called. Disabled in configuration file");
		
		DirectDepositInfo mapDirectDepositInfo = mapDirectDepositInfo(ddInfoResponse);
		return mapDirectDepositInfo;
	}

	@Override
	public void updateDirectDeposit(BusinessTransaction data) {
		DaisiPushDDRequest req = buildDaisiSetDDFromDAISIRequest(data);
		DaisiPushDDServiceResponse ddPushResponse = null;
		Map<String, Object> responseContext;
		
		if (requestsEnabled) {
			try {
				ddPushResponse = portPushDD.setDDFromDAISI(req);
			} catch (ClientTransportException x) {
				LOGGER.error(x.getMessage());
				responseContext = ((BindingProvider) portPullDD).getResponseContext();
				httpExceptionFactory.throwException(responseContext, x);
			} catch (CsSystemException_Exception e) {
				LOGGER.error("Error occurs when update ITRDS DD" + e.getMessage());
				throw new RuntimeException(e.getMessage());
			}
			validateDDPush(ddPushResponse);
		}
		else
			LOGGER.debug("ITRDS Not called. Disabled in configuration file");
	}



	void validateDDPush(DaisiPushDDServiceResponse itrdsResponse) {
		if (!isEmpty(itrdsResponse.getRejectReasonCd())) {
			throw new DataSharingRejectException(itrdsResponse.getRejectReasonCd());
		}
		String statusTypeId = itrdsResponse.getStatusTypeCd();

		switch (statusTypeId) {
		case DaisiConstants.STATUS_TYPE_ACCEPTED:
			LOGGER.info("statusTypeId returned from ITRDS is ACCEPTED, we are good to go..");
			break;
		case DaisiConstants.STATUS_TYPE_REJECTED:
			LOGGER.warn("statusTypeId returned from ITRDS is REJECTED, throwing  DataSharingRejectException..");
			final String rejectReasonCd = itrdsResponse.getRejectReasonCd();
			 throw new DataSharingRejectException(rejectReasonCd);
		default:
			LOGGER.warn("Shouldn't be here, don't know what to do,  throwing  DataSharingRejectException..");
			throw new DataSharingRejectException(DaisiConstants.REJECT_REASON_TYPE_OTHER);
		}
	}

	void validateDDInfo(DaisiDDInfoPullServiceResponse ddInfoResponse) {

		if (!isEmpty(ddInfoResponse.getRejectReasonCd())) {			
			String rejectReasonCd = ddInfoResponse.getRejectReasonCd();
			throw new DataSharingRejectException(rejectReasonCd);
		} else if (isEmpty(ddInfoResponse.getAccountNumber())) {
			throw new DataNotAvailableException("Bank account info returned from ITRDS is empty ");
		} else if (isEmpty(ddInfoResponse.getInstitutionNumber())) {
			throw new DataNotAvailableException("Bank account info returned from ITRDS is empty ");
		} else if (isEmpty(ddInfoResponse.getTransitNumber())) {
			throw new DataNotAvailableException("Bank account info returned from ITRDS is empty ");
		} else {
			// we are good, do nothing
		}
	}

	void initEndpoints() {
		initPullDDEndpoint();
		initPushDDEndpoint();
	}

	void initPushDDEndpoint() {
		DaisiPushDDService_Service service = new DaisiPushDDService_Service();
		service.setHandlerResolver(portPushDDHandlerResolver);

		portPushDD = service.getDaisiPushDDServicePort();

		initEndpointAddress((BindingProvider) portPushDD, endpointPushDD);
	}

	void initPullDDEndpoint() {
		DaisiDDInfoPullService_Service service = new DaisiDDInfoPullService_Service();
		service.setHandlerResolver(portPullDDHandlerResolver);
		portPullDD = service.getDaisiDDInfoPullServicePort();

		initEndpointAddress((BindingProvider) portPullDD, endpointPullDD);
	}

	void initEndpointAddress(BindingProvider bp, String endpoint) {
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		initHandlerResolver();
		initEndpoints();

	}

	private void initHandlerResolver() {
		portPullDDHandlerResolver = new HandlerResolver() {
			@SuppressWarnings("rawtypes")
			@Override
			public List<Handler> getHandlerChain(final PortInfo portInfo) {
				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();
//				handlerChain.add(new SOAPLoggingHandler());
				handlerChain.add(new WSSClientDigestUsernameTokenHandler(user, password));
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}
		};

		portPushDDHandlerResolver = new HandlerResolver() {
			@SuppressWarnings("rawtypes")
			@Override
			public List<Handler> getHandlerChain(final PortInfo portInfo) {
				final ArrayList<Handler> handlerChain = new ArrayList<Handler>();
//				handlerChain.add(new SOAPLoggingHandler());
				handlerChain.add(new WSSClientDigestUsernameTokenHandler(user, password));
				handlerChain.add(new SOAPLoggingHandler());
				return handlerChain;
			}
		};

	}

}
