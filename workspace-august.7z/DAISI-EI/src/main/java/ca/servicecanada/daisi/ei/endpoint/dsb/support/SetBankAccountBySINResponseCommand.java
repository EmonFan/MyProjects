package ca.servicecanada.daisi.ei.endpoint.dsb.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.servicecanada.daisi.ei.endpoint.dsb.DsbModelPlaceholder;
import ca.servicecanada.daisi.ei.endpoint.dsb.OutboundCallbackWsClient2;
import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.SetBankAccountBySINResponseType;

@Component(value = "setBankAccountBySINResponseCommand")
public class SetBankAccountBySINResponseCommand implements DsbEndpointCommand {

	private Logger LOGGER = LogManager.getLogger();

	@Autowired
	private OutboundCallbackWsClient2 outboundCallbackWsClient;

	@Override
	public int executeDsbCall(DsbModelPlaceholder dsbModelPlaceholder) {
		SetBankAccountBySINResponseType dsbData = (SetBankAccountBySINResponseType) dsbModelPlaceholder.getDsb();
		int httpResponseCode = outboundCallbackWsClient.callbackSetBankAccountBySINAsyncResponse(dsbData, dsbModelPlaceholder.getReplyTo(), dsbModelPlaceholder.getRelatesTo());
		LOGGER.debug("Sent to DSB! httpResponseCode =" + httpResponseCode);
		
		return httpResponseCode;
	}

}
