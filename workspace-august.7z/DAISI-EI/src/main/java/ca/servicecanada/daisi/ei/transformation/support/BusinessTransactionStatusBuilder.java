package ca.servicecanada.daisi.ei.transformation.support;

import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_REJECTED;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.Resource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.transaction.Transactional;

import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;


import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.ref.StatusType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransactionStatus;
import ca.servicecanada.daisi.ei.transformation.DaisiDataServiceClient;

@Component
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class BusinessTransactionStatusBuilder {

	private Logger LOGGER = LogManager.getLogger();

	@Resource
	private DaisiDataServiceClient refSvs;

	public RejectReasonType lookupRejectReasonType(String rejectReasonCd) {
		RejectReasonType rejectReasonType = refSvs.findRejectReasonTypeByAbrv(rejectReasonCd);

		if (rejectReasonType != null) {
			LOGGER.debug("looked up for rejectReasonType " + rejectReasonType.getRejectReasonTypeNameEn());
		} else {
			LOGGER.error("Can't find rejectReasonType for rejectReasonCd=" + rejectReasonCd + " provided by ITRDS ..");
		}

		return rejectReasonType;
	}

	public BusinessTransaction buildBusinessTransactionStatusRejected(BusinessTransaction trx, String rejectReasonCd) {
		RejectReasonType rejectReasonType = lookupRejectReasonType(rejectReasonCd);
		trx = buildBusinessTransactionStatus(trx, STATUS_TYPE_REJECTED, rejectReasonType);
		return trx;
	}

	public BusinessTransaction buildBusinessTransactionStatus(BusinessTransaction trx, String statusTypeCode) {
		RejectReasonType rejectReasonType = null;
		return buildBusinessTransactionStatus(trx, statusTypeCode, rejectReasonType);
	}
	
	public BusinessTransaction buildBusinessTransactionStatus(BusinessTransaction trx, String statusTypeCode, String rejectReasonCode) {
		RejectReasonType rejectReasonType = refSvs.findRejectReasonTypeByextErnalCode(rejectReasonCode);
		return buildBusinessTransactionStatus(trx, statusTypeCode, rejectReasonType);
	}

	public BusinessTransaction buildBusinessTransactionStatus(BusinessTransaction trx, String statusTypeCode,
			RejectReasonType rejectReasonType) {

		Date effectiveDate = new Date();
		StatusType statusType = refSvs.findStatusTypeByAbrv(statusTypeCode);

		BusinessTransactionStatus businessTransactionStatus = new BusinessTransactionStatus();
		businessTransactionStatus.setRejectReasonType(rejectReasonType);

		businessTransactionStatus.setStatusType(statusType);
		businessTransactionStatus.setEffectiveDate(effectiveDate);

		Set<BusinessTransactionStatus> businessTransactionStatuses = new HashSet<BusinessTransactionStatus>();
		businessTransactionStatuses.add(businessTransactionStatus);
		trx.setBusinessTransactionStatuses(businessTransactionStatuses);

		return trx;
	}

}
