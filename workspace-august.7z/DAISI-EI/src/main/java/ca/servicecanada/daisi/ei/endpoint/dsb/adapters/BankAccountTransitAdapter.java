package ca.servicecanada.daisi.ei.endpoint.dsb.adapters;

import org.springframework.stereotype.Component;

@Component(value = "bankAccountTransitAdapter")
public class BankAccountTransitAdapter implements DsbElementAdapter {

	@Override
	public String adaptToDsb(String originalValue) {
		return originalValue;
	}

	@Override
	public String adaptFromDsb(String originalValue) {
		return originalValue;
	}

}
