package ca.servicecanada.daisi.ei.transformation;

import static ca.servicecanada.daisi.ei.DaisiConstants.BUSINESS_TRANSACTION_ID;
import static ca.servicecanada.daisi.ei.DaisiConstants.EVENT_LOG_TYPE;
import static ca.servicecanada.daisi.ei.DaisiConstants.EVENT_LOG_TYPE_ERROR;
import static ca.servicecanada.daisi.ei.DaisiConstants.EVENT_LOG_TYPE_INPROGRESS;
import static ca.servicecanada.daisi.ei.DaisiConstants.FAULT;
import static ca.servicecanada.daisi.ei.DaisiConstants.REJECT_REASON_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_ACCEPTED;
import static ca.servicecanada.daisi.ei.DaisiConstants.RESULT_CODE_REJECTED;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_ACCEPTED;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_INCOMPLETE;
import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_REJECTED;

import javax.annotation.Resource;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import ca.gc.servicecanada.daisi.domain.ref.RejectReasonType;
import ca.gc.servicecanada.daisi.domain.trx.BusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.DataAccessService;
import ca.servicecanada.daisi.ei.exception.DaisiSystemException;
import ca.servicecanada.daisi.ei.exception.DataNotAvailableException;
import ca.servicecanada.daisi.ei.exception.DataSharingRejectException;
import ca.servicecanada.daisi.ei.exception.ServiceUnavailableException;
import ca.servicecanada.daisi.ei.transformation.support.BusinessTransactionStatusBuilder;

public abstract class AbstractDataEnricher implements Processor {

	protected Logger LOGGER = LogManager.getLogger();

	@Autowired
	protected DataAccessService dataAccessService;
	
	@Resource
	private DaisiDataServiceClient daisiDataService;

	@Autowired
	protected BusinessTransactionStatusBuilder trxStatusBuilder;

	@Override
	public void process(Exchange exchange) throws Exception {
		LOGGER.debug("Getting the data from a program's system!!");
		String eventLogType = EVENT_LOG_TYPE_INPROGRESS;
		String statusType = STATUS_TYPE_INCOMPLETE;
		String resultCode = RESULT_CODE_REJECTED;

		BusinessTransaction trx = (BusinessTransaction) exchange.getIn().getBody();

		String rejectReasonCode = null;
		String rejectReasonExternalCode = null;
		String faultDetails = null;

		try {
			execute(trx);
			eventLogType = EVENT_LOG_TYPE_INPROGRESS;
			statusType = STATUS_TYPE_ACCEPTED;
			exchange.getIn().setHeader(STATUS_TYPE, statusType);
			LOGGER.debug("\n\n $$$$$$$$$$$ set statusType  = ACCPETED $$$$$$$$$$$$ \n");
			resultCode = RESULT_CODE_ACCEPTED;
		} catch (DataNotAvailableException ae) {
			faultDetails = ae.getMessage();
		} catch (DataSharingRejectException se) {
			rejectReasonCode = se.getRejectReasonCode();
			LOGGER.warn("DataSharingRejectException for ID " + trx.getBusinessTransactionID() + ", rejectReasonCode "
					+ rejectReasonCode);
			trx = handleRejectReason(trx, rejectReasonCode);
			statusType = STATUS_TYPE_REJECTED;
		} catch (DaisiSystemException se) {
			trx = handleSystemFailure(trx);
			faultDetails = se.getMessage();
		} catch (ServiceUnavailableException u) {
			LOGGER.error(u.getMessage());
			trx = handleSystemFailure(trx);
			faultDetails = u.getMessage();
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			trx = handleSystemFailure(trx);
			faultDetails = e.getMessage();
		}

		// DataSharingRejectException
		exchange.getIn().setBody(trx);
		exchange.getIn().setHeader("ID", trx.getId());
		exchange.getIn().setHeader(BUSINESS_TRANSACTION_ID, trx.getBusinessTransactionID());
		exchange.getIn().setHeader(EVENT_LOG_TYPE, eventLogType);
		exchange.getIn().setHeader(STATUS_TYPE, statusType);
		exchange.getIn().setHeader(RESULT_CODE, resultCode);

		if (!StringUtils.isEmpty(faultDetails)) {
			exchange.getIn().setHeader(FAULT, faultDetails);
		}
		if (!StringUtils.isEmpty(rejectReasonCode)) {
			//we need to translate rejectReansonCode to the external format
			try {
				RejectReasonType rejectReasonType = daisiDataService.findRejectReasonTypeByAbrv(rejectReasonCode);
				rejectReasonExternalCode = rejectReasonType.getExternalCode();
					
			} catch (Exception e){
				LOGGER.error("unable to find external code for " + rejectReasonCode + ". " + e.getMessage());
			}
			exchange.getIn().setHeader(REJECT_REASON_CODE, rejectReasonExternalCode);
		}

	}

	BusinessTransaction handleRejectReason(BusinessTransaction trx, String rejectReasonCd) {
		trx = trxStatusBuilder.buildBusinessTransactionStatusRejected(trx, rejectReasonCd);
		return trx;

	}

	BusinessTransaction handleSystemFailure(BusinessTransaction trx) {
		trx = trxStatusBuilder.buildBusinessTransactionStatus(trx, STATUS_TYPE_INCOMPLETE);
		return trx;

	}

	protected abstract void execute(BusinessTransaction trx);

}
