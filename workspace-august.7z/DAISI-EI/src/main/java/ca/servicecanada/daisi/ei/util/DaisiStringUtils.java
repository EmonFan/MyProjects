package ca.servicecanada.daisi.ei.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DaisiStringUtils {

	private static final int TARGET_LENGTH_Institution = 3;
	
	private static final int TARGET_LENGTH_Transit = 5;
	
	private static final int MAX_LENGTH_AccountNumber = 12;
	
	private static final int MIN_LENGTH_AccountNumber = 5;
	

	// some of ITRDS account number contain "-" need to be removed
	public static String removeDashCharacter(String input) {
		return input.replaceAll("[-]", "");
	}

	public static String padWithZeros4Institution(String input) {
		if (input.length() > TARGET_LENGTH_Institution) {
			throw new RuntimeException("InstitutionNumber format is wrong!");
		}
		return String.format("%04d", Integer.parseInt(input));
	}
	
	public static String padWithZeros4Transit(String input) {
		if (input.length() > TARGET_LENGTH_Transit) {
			throw new RuntimeException("Transit format is wrong!");
		}
		return String.format("%05d", Integer.parseInt(input));
	}
	
	public static String padWithZeros4AccountNumber(String input) {
		return String.format("%05d", Integer.parseInt(input));
	}

	public static String truncateLeadingZeros4Institution(String input) {
		String out = null;

		if (input.length() > TARGET_LENGTH_Institution) {
			// First we need to make sure not to truncate any none zero digit.
			// We throw the exception if the char to be truncated is non zero
			Pattern pattern = Pattern.compile("[1-9]+");
			Matcher matcher = pattern.matcher(input.substring(0, input.length() - TARGET_LENGTH_Institution));
			if (matcher.find()) {
				throw new RuntimeException("InstitutionNumber format is wrong!");
			}

			out = input.substring(input.length() - TARGET_LENGTH_Institution, input.length());
		} else {
			out = String.format("%03d", Integer.parseInt(input));
		}

		return out;
	}
	
	public static String truncateLeadingZeros4AccountNumber(String input) {
		String out = null;

		if (input.length() > MAX_LENGTH_AccountNumber) {
			// First we need to make sure not to truncate any none zero digit.
			// We throw the exception if the char to be truncated is non zero
			Pattern pattern = Pattern.compile("[1-9]+");
			Matcher matcher = pattern.matcher(input.substring(0, input.length() - MAX_LENGTH_AccountNumber));
			if (matcher.find()) {
				throw new RuntimeException("Account Number format is wrong!");
			}

			out = input.substring(input.length() - MAX_LENGTH_AccountNumber, input.length());
		} else {
			out = String.format("%012d", Integer.parseInt(input));
		}

		return out;
	}

}
