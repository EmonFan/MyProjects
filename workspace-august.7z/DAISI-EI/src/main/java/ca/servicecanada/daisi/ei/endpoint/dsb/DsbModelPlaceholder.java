package ca.servicecanada.daisi.ei.endpoint.dsb;

import static ca.servicecanada.daisi.ei.DaisiConstants.STATUS_TYPE_INCOMPLETE;

import java.io.Serializable;

public class DsbModelPlaceholder implements Serializable {

	private static final long serialVersionUID = 1L;

	private Object dsb;

	private String replyTo;
	private String relatesTo;

	private String statusType;
	private String faultDetails;
	private String rejectReasonCode;
	private String resultCode;

	public Object getDsb() {
		return dsb;
	}

	public void setDsb(Object dsb) {
		this.dsb = dsb;
	}

	public String getReplyTo() {
		return replyTo;
	}

	public void setReplyTo(String replyTo) {
		this.replyTo = replyTo;
	}

	public String getStatusType() {
		return statusType;
	}

	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}

	public String getFaultDetails() {
		return faultDetails;
	}

	public void setFaultDetails(String faultDetails) {
		this.faultDetails = faultDetails;
	}

	public String getRejectReasonCode() {
		return rejectReasonCode;
	}

	public void setRejectReasonCode(String rejectReasonCode) {
		this.rejectReasonCode = rejectReasonCode;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getRelatesTo() {
		return relatesTo;
	}

	public void setRelatesTo(String relatesTo) {
		this.relatesTo = relatesTo;
	}

	public boolean isFailed() {
		if (statusType != null && statusType.equalsIgnoreCase(STATUS_TYPE_INCOMPLETE)) {
			return true;
		} else {
			return false;
		}

	}

}
