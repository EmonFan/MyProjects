package ca.gc.hrdc.isp.common.util;

import ca.gc.hrdc.isp.common.util.LogPath;

import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;

import java.io.IOException;

/**
 * This class represents an appender to a rolling file (file constantly updated).
 */
public class LogPathDailyRollingFileAppender extends DailyRollingFileAppender
{
  /**
   * This default constructor simply calls
   * {@link DailyRollingFileAppender#DailyRollingFileAppender()}. Object's created by this
   * constructor must have {@link FileAppender#setFile(String, boolean, boolean, int)} and
   * {@link DailyRollingFileAppender#setDatePattern(String)} called on it.
   */
  public LogPathDailyRollingFileAppender()
  {
    super();
  }

  /**
   * Constructor. Instantiate a {@link DailyRollingFileAppender} and open the file designated by
   * <VAR>filename</VAR>. The opened file will become the ouput destination for this appender.
   * 
   * @param layout Layout to use.
   * @param filename Name of file to write to.
   * @param datePattern Date pattern used to designate when new files will be created.
   */
  public LogPathDailyRollingFileAppender(final Layout layout, final String filename,
      final String datePattern) throws IOException
  {
    super(layout, LogPath.getLogPath(filename), datePattern);
  }

  /**
   * Constructor. Instantiate a {@link DailyRollingFileAppender} and open the file designated by
   * <VAR>filename</VAR>. The opened file will become the ouput destination for this appender.
   * Default date pattern is '.'yyyy-MM-dd
   * 
   * @param layout Layout to use.
   * @param filename Name of file to write to append to.
   */
  public LogPathDailyRollingFileAppender(final Layout layout, final String filename)
      throws IOException
  {
    super(layout, LogPath.getLogPath(filename), "'.'yyyy-MM-dd");
  }

  /**
   * Set the file that the object is to write to <VAR>filename</VAR>. If <VAR>filename</VAR> does
   * not start with the application's log path, then it is added to <VAR>filename</VAR>. This method
   * must be called when the file is created.
   * 
   * @param filename Name of file to write to.
   * @param append true if the file designated by <VAR>filename</VAR> is to be appended to, false if
   *          it is to be overwritten.
   * @param bufferedIO true if output is to be buffered, false if not.
   * @param bufferSize The size of the output buffer.
   */
  @Override
  public synchronized void setFile(String fileName, final boolean append, final boolean bufferedIO,
      final int bufferSize) throws IOException
  {
    if (!fileName.startsWith(LogPath.getLogPath("")))
    {
      fileName = LogPath.getLogPath(fileName);
    }
    super.setFile(fileName, append, bufferedIO, bufferSize);
  }
}
