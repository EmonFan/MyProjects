package ca.gc.hrdc.isp.common.util;

import ca.servicecanada.daisi.ei.util.ApplicationResourceBundle;

import java.io.InputStream;
import java.io.Serializable;
import java.util.MissingResourceException;
import java.util.Properties;

public class DaisiUtil implements Serializable {
	private static final long serialVersionUID = 1L;
	private static Properties configProperties = new Properties();

	// private static ExtendedResourceBundle daisiResourceBundle =
	// DaisiUtil.getResourceBundle("daisi.properties");

	private static final String DAISI_CONFIG_BUNDLE = "daisi";
	private static ExtendedResourceBundle daisiResourceBundle = null;

	static {
		DaisiUtil.loadProperties();
	}

	public DaisiUtil() {
		/*
		 * try {
		 *
		 * final InputStream inputStream =
		 * this.getClass().getClassLoader().getResourceAsStream(
		 * "daisi.properties"); DaisiUtil.configProperties.load(inputStream); }
		 * catch (final Exception e) {
		 * System.out.println("Could not load the file"); e.printStackTrace(); }
		 */
	}

	private static void loadProperties() {
		try {

			// final InputStream inputStream =
			// DaisiUtil.class.getClassLoader().getResourceAsStream("daisi.properties");
			final InputStream inputStream2 = DaisiUtil.class.getClassLoader().getResourceAsStream("version.properties");
			// DaisiUtil.configProperties.load(inputStream);
			DaisiUtil.configProperties.load(inputStream2);
		} catch (final Exception e) {
			System.out.println("Could not load the file(s) - daisi and/or version .properties");
			e.printStackTrace();
		}
	}

	public static String getBuild() {
		return DaisiUtil.configProperties.getProperty("build.name");
	}

	public static String getItrdsPushDDURL() {
		return DaisiUtil.getString("itrds.ws.push-dd.url");
	}

	public static String getItrdsPullDDURL() {
		return DaisiUtil.getString("itrds.ws.pull-dd.url");
	}

	public static String getDSBURL() {
		return DaisiUtil.getString("dsb.url");
	}

	public static String getDSBUserID() {
		return DaisiUtil.getString("dsb.user");
	}

	public static String getDSBUrlCallback() {
		return DaisiUtil.getString("dsb.url.callback");

	}

	public static String getDSBWsdlCallback() {
		return DaisiUtil.getString("dsb.wsdl.callback");

	}

	public static String getWsUsername() {
		return DaisiUtil.getString("ws.username");

	}

	public static String getWsPassword() {
		return DaisiUtil.getString("ws.password");

	}

	public static String getITRDWsSUser() {
		return DaisiUtil.getString("itrds.ws.user");

	}

	public static String getITRDSWsPassword() {
		return DaisiUtil.getString("itrds.ws.password");

	}

	public static String getDSBTestInd() {
		return DaisiUtil.getString("dsb.testIndicator");

	}

	public static String getDSBRequestsEnable() {
		return DaisiUtil.getString("dsb.requests.enabled");

	}

	public static String getITRDSRequestsEnable() {
		return DaisiUtil.getString("itrds.requests.enabled");

	}

	public static ExtendedResourceBundle getResourceBundle(final String propertyName) {
		ExtendedResourceBundle bundle = null;
		bundle = ApplicationResourceBundle.getBundleAndOverrides(propertyName);
		return bundle;
	}

	public static ExtendedResourceBundle getResourceBundle() {
		if (DaisiUtil.daisiResourceBundle == null) {
			DaisiUtil.daisiResourceBundle = ApplicationResourceBundle
					.getBundleAndOverrides(DaisiUtil.DAISI_CONFIG_BUNDLE);
		}
		return DaisiUtil.daisiResourceBundle;
	}

	public static String getString(final String key) {

		try {
			return (String) DaisiUtil.getResourceBundle().getObject(key);
		} catch (final MissingResourceException mrex) {
			// throw new RuntimeException("RBSUtil - BuildVersion is not Found
			// in Resource File : " + ConnectionPoolMgr.PRIME_CONN_MGR);
			return "daisi.properties - Not Found : " + key;
		}

	}

	public static String getQueueTimeout() {
		return DaisiUtil.configProperties.getProperty("message.queue.timeout");
	}
}