package ca.servicecanada.daisi.ei.util;
/*
import static org.junit.Assert.*;

import javax.xml.datatype.XMLGregorianCalendar;

import org.junit.Test;

public class DaisiDatesUtilTest {

	//@Test
	public void testToDsbDateFormat() {
		
		String daisiStringDate = "07-07-2017";
		
		String result = EiUtils.toDsbDateFormat(daisiStringDate);
		
		System.out.println(result);
		
	}
	
	@Test
	public void testToXMLGregorianCalendarTruncated() {
		
		String stringDate = "193302";
		
		XMLGregorianCalendar dob;
		
		dob = EiUtils.toXMLGregorianCalendarTruncated(stringDate);
		
		System.out.println(dob);
		
	}

}
*/