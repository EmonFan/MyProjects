package ca.servicecanada.daisi.ei.transformation;
/*
import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.domain.trx.*;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;
import ca.servicecanada.daisi.ei.transformation.JsonToCanonicalFormTranslator;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration(locations = { "classpath:test-camel-outgoingCppPushDDRoute.xml" })
public class JsonToCanonicalFormTranslatorTest {

	// {"sin":"800000002","birthDate":"193302","surname":"BEACO","channelTypeID":3,"consentStatementTypeID":3}

	@Resource
	JsonToCanonicalFormTranslator translator;
	
	String birthDate = "12/12/2017";
	String surname = "BEACO";
	String sin= "800000002";

	@Test
	public void test() {
		String json = "{\"sin\":\"800000002\",\"surname\":\"BEACO\",\"birthDate\":\"12/12/2017\",\"channelType\":\"ONL\",\"consentStatementType\":\"OPH\"}";

		DaisiExchangeRequest req = translator.transform(json);
		assertNotNull(req);
		
		assertEquals(req.getBirthDate(), birthDate);
		assertEquals(req.getSin(), sin);
	}

}
*/