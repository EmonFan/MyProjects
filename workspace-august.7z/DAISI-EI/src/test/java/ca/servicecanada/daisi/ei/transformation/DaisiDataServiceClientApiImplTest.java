package ca.servicecanada.daisi.ei.transformation;

/*
import static org.junit.Assert.fail;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.config.DaisiDataSourceConfiguration;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration//(locations = { "classpath:services-context.xml" })
@Import(DaisiDataSourceConfiguration.class)
@Transactional
public class DaisiDataServiceClientApiImplTest {

	@Autowired
	DaisiDataServiceClientApiImpl dataService;

	DaisiExchangeRequest request;

	String organizationTypeTarget = "CRA";
	String programServiceTypeTarget = "CRA";
	String organizationTypeSource = "ESD";
	String programServiceTypeSource = "CPP";

	String actionType = "SND";
	String infoType = "DD";
	String transactionType = "1";

	String consentStatementType = "1";
	String channelType = "ONL";

	@Before
	public void init() {
		request = new DaisiExchangeRequest();
		request.setChannelType(channelType);
		request.setConsentStatementType(consentStatementType);

		request.setActionType(actionType);
		request.setInfoType(infoType);
		
		request.setOrganizationTypeSource(organizationTypeSource);
		request.setOrganizationTypeTarget(organizationTypeTarget);
		request.setProgramServiceTypeSource(programServiceTypeSource);
		request.setProgramServiceTypeTarget(programServiceTypeTarget);

		// request.setSin(value);
		// request.setSurname(value);
		// request.setBirthDate(value);
	}

	@Test
	public void getChannelType() {
		dataService.getChannelType(request);
	}

	@Test
	public void getConsentStatementType() {
		dataService.getConsentStatementType(request);
	}

	@Test
	public void getTransactionType() {
		dataService.getTransactionType(request);
	}

	@Test
	public void getProgramServiceTypeSource() {
		dataService.getProgramServiceTypeSource(request);
	}

	@Test
	public void getProgramServiceTypeTarget() {
		dataService.getProgramServiceTypeTarget(request);
	}

	@Test
	public void getOrganizationTypeSource() {
		dataService.getOrganizationTypeSource(request);
	}

	@Test
	public void getOrganizationTypeTarget() {
		dataService.getOrganizationTypeTarget(request);
	}

	@Test
	public void testEnrich() {
		fail("Not yet implemented");
	}
	
	
	
	  @Configuration
	  @PropertySource("classpath:test.properties")
	  @ImportResource({"classpath:test-camel-outgoingRoute.xml" })
	  public static class MyContextConfiguration{

	  }

}
*/