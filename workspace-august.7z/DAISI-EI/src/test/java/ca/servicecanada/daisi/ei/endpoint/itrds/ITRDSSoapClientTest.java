package ca.servicecanada.daisi.ei.endpoint.itrds;

/*
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

import ca.gc.servicecanada.daisi.domain.ref.ConsentStatementType;
import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.endpoint.itrds.ITRDSSoapClient;
import ca.servicecanada.daisi.ei.model.DirectDepositInfo;

public class ITRDSSoapClientTest {

	ITRDSSoapClient client = new ITRDSSoapClient();

	@Test
	public void testRetrieveDirectDeposit() {

		// DDBusinessTransaction data = new DDBusinessTransaction();
		String sin = "800000002";
		String surname = "Smith";
		String birthDate = "06-07-2017";
		String channelType = "";
		String consentCode = "";
		String businessTranscationId = "";

		DirectDepositInfo DDInfo = null;

		try {
			DDInfo = client.retrieveDirectDeposit(sin, surname, birthDate, channelType, consentCode, businessTranscationId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(DDInfo);

		System.out.println("AccountNumber: " + DDInfo.getAccountNumber() + ", InstitutionNumber: "
				+ DDInfo.getInstitutionNumber() + ", " + DDInfo.getTransitNumber());

	}

	//@Test
	public void testUpdateDirectDeposit() {

		DDBusinessTransaction data = new DDBusinessTransaction();
		data.setSin("800557274");
		data.setBirthDate("12-12-1958");
		data.setBusinessTransactionID("12345678");
		data.setAccountNumber("111");
		data.setInstitutionNumber("222");
		data.setTransitNumber("333");

		ConsentStatementType consentStatementType = new ConsentStatementType();
		consentStatementType.setConsentStatementTypeAbrvEn("consentAbrvEn");
		consentStatementType.setDateCreated(new Date());

		data.setConsentStatementType(consentStatementType);

		try {
			client.updateDirectDeposit(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
*/