package ca.servicecanada.daisi.ei.endpoint.dsb;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import ca.servicecanada.daisi.ei.endpoint.dsb.generated_new.RetrieveBankAccountBySINResponseType;
import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration
public class OutboundCallbackWsClient2Test {
	
	@Autowired
	OutboundCallbackWsClient2 ws  = new OutboundCallbackWsClient2();

	@Test
	public void testCallbackRetrieveBankAccountBySINAsyncResponse() {
		try {
			ws.afterPropertiesSet();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String replyTo="https://qafab.dev.service.gc.ca/UAT12C1/INST1/CPFL/Async/Response/ClientProfile?clientCallbackUrl=aHR0cDovL3VhdDEyY2FiLmJyei5kZXY6NzAyMC9zb2EtaW5mcmEvc2VydmljZXMvZGVmYXVsdC9DUEZMQWRhcHRlciEyLjAuNS1DT1JFMjEzKnNvYV9iNGI2YmY3OC0zZDZmLTQxZmEtOTg5MC1kNjIzYzYzNjI5MWMvQ1BQQ2xpZW50UHJvZmlsZVNlcnZpY2VzJTIzUmV0cmlldmVCYW5rQWNjb3VudEJ5U0lOL0NQUENsaWVudFByb2ZpbGVTZXJ2aWNlcw==";
		String relatesTo="222";
		RetrieveBankAccountBySINResponseType data = new RetrieveBankAccountBySINResponseType();
		System.out.println("sending");
		
		ws.callbackRetrieveBankAccountBySINAsyncResponse(data, replyTo, relatesTo);
	}

	//@Test
	public void testCallbackSetBankAccountBySINAsyncResponse() {
		fail("Not yet implemented");
	}

	
	@Configuration
	@PropertySource("classpath:test.properties")
	@ImportResource({ "classpath:test-endpoint-dsb.xml" })
	public static class MyContextConfiguration {

	}
}
