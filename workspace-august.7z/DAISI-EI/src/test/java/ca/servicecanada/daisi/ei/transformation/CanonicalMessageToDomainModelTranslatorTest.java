package ca.servicecanada.daisi.ei.transformation;

/*
import static org.junit.Assert.*;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import ca.gc.servicecanada.daisi.domain.trx.DDBusinessTransaction;
import ca.servicecanada.daisi.ei.model.DaisiExchangeRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ActiveProfiles("eclipse")
@ContextConfiguration
public class CanonicalMessageToDomainModelTranslatorTest {
	@Resource
	CanonicalMessageToDomainModelTranslator translator;

	DDBusinessTransaction trx;
	DaisiExchangeRequest request;


	@Test
	public void enrichUserInput() {
		translator.enrichUserInput(request, trx);
		assertEquals(trx.getBirthDate(), request.getBirthDate());
		assertEquals(trx.getSin(), request.getSin());
		assertEquals(trx.getSurname(), request.getSurname());
		
	}

	@Test
	public void enrichTransactionInfo() {
		translator.enrichTransactionInfo(request, trx);
		assertNotNull(trx.getBusinessTransactionID());
		
	}

	@Test
	public void enrichAuditInfo() {
		translator.enrichAuditInfo(request, trx);
		assertNotNull(trx.getDateCreated());
		assertNotNull(trx.getUserCreated());

	}

	@Test
	public void enrichRefData() {
		translator.enrichRefData(request, trx);
		assertNotNull(trx.getChannelType());
		assertNotNull(trx.getConsentStatementType());
		assertNotNull(trx.getOrganizationTypeSource());
		assertNotNull(trx.getOrganizationTypeTarget());
		assertNotNull(trx.getProgramServiceTypeSource());
		assertNotNull(trx.getProgramServiceTypeTarget());
		assertNotNull(trx.getTransactionType());

		
	}

	//@Test
	public void testTransform() {
		fail("Not yet implemented");
	}

	@Configuration
	@PropertySource("classpath:test.properties")
	@ImportResource({ "classpath:test-camel-outgoingRoute.xml" })
	public static class MyContextConfiguration {

	}

	
	String organizationTypeTarget = "CRA";
	String programServiceTypeTarget = "CRA";
	String organizationTypeSource = "ESD";
	String programServiceTypeSource = "CPP";

	String actionType = "SND";
	String infoType = "DD";
	String transactionType = "1";

	String consentStatementType = "1";
	String channelType = "ONL";
	
	String surname = "Smith";
	String sin = "111";
	String birthDate = "11/12/1995";


	@Before
	public void initTrx() {
		trx= new DDBusinessTransaction();
	}

	@Before
	public void initReq() {
		request = new DaisiExchangeRequest();
		request.setChannelType(channelType);
		request.setConsentStatementType(consentStatementType);

		request.setActionType(actionType);
		request.setInfoType(infoType);
		
		request.setOrganizationTypeSource(organizationTypeSource);
		request.setOrganizationTypeTarget(organizationTypeTarget);
		request.setProgramServiceTypeSource(programServiceTypeSource);
		request.setProgramServiceTypeTarget(programServiceTypeTarget);

		 request.setSin(sin);
		 request.setSurname(surname);
		 request.setBirthDate(birthDate);
		 
		 request .setId("ID.11111.222");
	}
}
*/
