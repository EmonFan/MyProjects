package ca.servicecanada.daisi.ei.util;
/*
import static org.junit.Assert.*;

import org.junit.Test;

public class DaisiDateTimeUtilsTest {

	// DoB � YYYYMM, we cut off days since CRA can�t guarantee days for DOB
	@Test
	public void testItrdsBirthDateToDsbFormat() {
		String input;
		String dsbDate;

		input = "194805";
		dsbDate = DaisiDateTimeUtils.itrdsBirthDateToDsbFormat(input);
		assertEquals("1948-05", dsbDate);
	}

}
*/